Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

     
        'set up query
        Dim sql As String = "select nama_penulis from penulis_tb"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(sql, conn)

            'menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader

            'perulangan yang melalui result set
            While rdr.Read
                Console.WriteLine(rdr(0))
            End While

            'menutup data reader
            rdr.Close()

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
