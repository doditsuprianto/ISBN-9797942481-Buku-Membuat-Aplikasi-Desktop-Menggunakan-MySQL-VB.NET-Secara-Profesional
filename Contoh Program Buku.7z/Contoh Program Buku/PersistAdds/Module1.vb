Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim sql As String = "select * from penerbit_tb;"

        'set up DML
        Dim ins As String
        ins = "insert into penerbit_tb "
        ins &= "(kode_penerbit, nama_penerbit, alamat, kota,  "
        ins &= "kode_pos, telp, email, website) "
        ins &= "values (@kode_penerbit, @nama_penerbit, @alamat, @kota, "
        ins &= "@kode_pos, @telp, @email, @website);"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dan mengisi dataset
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "penerbit_tb")

            'mendapatkan referensi table
            Dim dt As DataTable = ds.Tables("penerbit_tb")

            'menambah baris
            Dim newRow As DataRow = dt.NewRow()
            newRow("kode_penerbit") = "0000000008"
            newRow("nama_penerbit") = "Penerbit Baru"
            newRow("alamat") = "Jl. Sartono Sh 4"
            newRow("kota") = "Malang"
            newRow("kode_pos") = "65118"
            newRow("telp") = "(0341) 356781"
            newRow("email") = "d0dit@yahoo.com"
            newRow("website") = "www.newpenerbit.com"
            dt.Rows.Add(newRow)

            'Menampilkan baris dari data table
            For Each row As DataRow In dt.Rows
                Console.WriteLine("{0} {1} {2}", _
                row("kode_penerbit").ToString().PadRight(10), _
                row("nama_penerbit").ToString().PadLeft(30), _
                row("alamat"), row("kota"))
            Next

            'menambahkan penerbit
            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(ins, conn)
            '
            'memetakan parameter
            '
            cmd.Parameters.Add("@kode_penerbit", MySqlDbType.VarChar, 10, "kode_penerbit")
            cmd.Parameters.Add("@nama_penerbit", MySqlDbType.VarChar, 30, "nama_penerbit")
            cmd.Parameters.Add("@alamat", MySqlDbType.VarChar, 50, "alamat")
            cmd.Parameters.Add("@kota", MySqlDbType.VarChar, 25, "kota")
            cmd.Parameters.Add("@kode_pos", MySqlDbType.VarChar, 6, "kode_pos")
            cmd.Parameters.Add("@telp", MySqlDbType.VarChar, 15, "telp")
            cmd.Parameters.Add("@email", MySqlDbType.TinyText, 100, "email")
            cmd.Parameters.Add("@website", MySqlDbType.TinyText, 100, "website")

            'Update database
            da.InsertCommand = cmd
            da.Update(ds, "penerbit_tb")
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
