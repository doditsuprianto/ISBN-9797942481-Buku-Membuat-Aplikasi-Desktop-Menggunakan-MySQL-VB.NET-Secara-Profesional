Imports MySQL.Data.MySQLClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()
            Console.WriteLine("Koneksi database terbuka.")
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try

    End Sub


End Module
