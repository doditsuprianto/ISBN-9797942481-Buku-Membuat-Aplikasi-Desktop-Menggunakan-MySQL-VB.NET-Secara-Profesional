Public Class frmLogin

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Judul Form
        Me.Text = "Login User"

        'memosisikan teks di tengah kiri
        btnLogin.TextAlign = ContentAlignment.MiddleLeft
        btnBatal.TextAlign = ContentAlignment.MiddleLeft

        'memosisikan ikon di tengah kanan
        btnLogin.ImageAlign = ContentAlignment.MiddleRight
        btnBatal.ImageAlign = ContentAlignment.MiddleRight

        'me-masking password dengan karakter *
        txtPassword.PasswordChar = "*"
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim CN As New MySqlConnection 'Deklarasi variable object Connection ke MySQl
        Dim db, user, pwd, myConnectionString As String
        Try
            db = txtDatabase.Text
            user = txtUser.Text
            pwd = txtPassword.Text
            If db.ToString <> "" And user.ToString <> "" Then
                myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
                CN = New MySqlConnection(myConnectionString)
                CN.Open()
                'lakukan sesuatu disini, seperti membuka form MDI.
                'frmMDI.Show()
                MessageBox.Show("User memiliki hak akses", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Data harus diisi lengkap!", "Inputan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If

        Catch ex As Exception
            CN.Dispose()
            CN = Nothing
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        'keluar dari form login
        Me.Close()
    End Sub
End Class
