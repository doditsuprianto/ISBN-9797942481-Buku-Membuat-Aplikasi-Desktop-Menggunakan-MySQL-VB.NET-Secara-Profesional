<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLaporan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnLaporanBuku = New System.Windows.Forms.Button
        Me.rdPenulis = New System.Windows.Forms.RadioButton
        Me.rdPenerbit = New System.Windows.Forms.RadioButton
        Me.rdJenis = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btnLaporanTanggal = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.dtJual2 = New System.Windows.Forms.DateTimePicker
        Me.dtJual1 = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnLaporanNota = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtNota2 = New System.Windows.Forms.TextBox
        Me.txtNota1 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnLaporanBuku)
        Me.GroupBox1.Controls.Add(Me.rdPenulis)
        Me.GroupBox1.Controls.Add(Me.rdPenerbit)
        Me.GroupBox1.Controls.Add(Me.rdJenis)
        Me.GroupBox1.Location = New System.Drawing.Point(9, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(499, 53)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'btnLaporanBuku
        '
        Me.btnLaporanBuku.Location = New System.Drawing.Point(413, 19)
        Me.btnLaporanBuku.Name = "btnLaporanBuku"
        Me.btnLaporanBuku.Size = New System.Drawing.Size(75, 24)
        Me.btnLaporanBuku.TabIndex = 3
        Me.btnLaporanBuku.Text = "Cetak"
        Me.btnLaporanBuku.UseVisualStyleBackColor = True
        '
        'rdPenulis
        '
        Me.rdPenulis.AutoSize = True
        Me.rdPenulis.Location = New System.Drawing.Point(177, 21)
        Me.rdPenulis.Name = "rdPenulis"
        Me.rdPenulis.Size = New System.Drawing.Size(59, 17)
        Me.rdPenulis.TabIndex = 2
        Me.rdPenulis.TabStop = True
        Me.rdPenulis.Text = "Penulis"
        Me.rdPenulis.UseVisualStyleBackColor = True
        '
        'rdPenerbit
        '
        Me.rdPenerbit.AutoSize = True
        Me.rdPenerbit.Location = New System.Drawing.Point(107, 21)
        Me.rdPenerbit.Name = "rdPenerbit"
        Me.rdPenerbit.Size = New System.Drawing.Size(64, 17)
        Me.rdPenerbit.TabIndex = 1
        Me.rdPenerbit.TabStop = True
        Me.rdPenerbit.Text = "Penerbit"
        Me.rdPenerbit.UseVisualStyleBackColor = True
        '
        'rdJenis
        '
        Me.rdJenis.AutoSize = True
        Me.rdJenis.Location = New System.Drawing.Point(9, 21)
        Me.rdJenis.Name = "rdJenis"
        Me.rdJenis.Size = New System.Drawing.Size(92, 17)
        Me.rdJenis.TabIndex = 0
        Me.rdJenis.TabStop = True
        Me.rdJenis.Text = "Kategori Buku"
        Me.rdJenis.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnLaporanTanggal)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.dtJual2)
        Me.GroupBox2.Controls.Add(Me.dtJual1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.btnLaporanNota)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtNota2)
        Me.GroupBox2.Controls.Add(Me.txtNota1)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 71)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(499, 94)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GroupBox2"
        '
        'btnLaporanTanggal
        '
        Me.btnLaporanTanggal.Location = New System.Drawing.Point(413, 59)
        Me.btnLaporanTanggal.Name = "btnLaporanTanggal"
        Me.btnLaporanTanggal.Size = New System.Drawing.Size(75, 23)
        Me.btnLaporanTanggal.TabIndex = 9
        Me.btnLaporanTanggal.Text = "Cetak"
        Me.btnLaporanTanggal.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(248, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(23, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "s/d"
        '
        'dtJual2
        '
        Me.dtJual2.Location = New System.Drawing.Point(277, 60)
        Me.dtJual2.Name = "dtJual2"
        Me.dtJual2.Size = New System.Drawing.Size(130, 20)
        Me.dtJual2.TabIndex = 7
        '
        'dtJual1
        '
        Me.dtJual1.Location = New System.Drawing.Point(112, 60)
        Me.dtJual1.Name = "dtJual1"
        Me.dtJual1.Size = New System.Drawing.Size(130, 20)
        Me.dtJual1.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Penjualan Tanggal"
        '
        'btnLaporanNota
        '
        Me.btnLaporanNota.Location = New System.Drawing.Point(413, 26)
        Me.btnLaporanNota.Name = "btnLaporanNota"
        Me.btnLaporanNota.Size = New System.Drawing.Size(75, 23)
        Me.btnLaporanNota.TabIndex = 4
        Me.btnLaporanNota.Text = "Cetak"
        Me.btnLaporanNota.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(248, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "s/d"
        '
        'txtNota2
        '
        Me.txtNota2.Location = New System.Drawing.Point(277, 27)
        Me.txtNota2.Name = "txtNota2"
        Me.txtNota2.Size = New System.Drawing.Size(130, 20)
        Me.txtNota2.TabIndex = 2
        '
        'txtNota1
        '
        Me.txtNota1.Location = New System.Drawing.Point(112, 28)
        Me.txtNota1.Name = "txtNota1"
        Me.txtNota1.Size = New System.Drawing.Size(130, 20)
        Me.txtNota1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Penjualan No. Nota"
        '
        'frmLaporan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(517, 171)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmLaporan"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdPenulis As System.Windows.Forms.RadioButton
    Friend WithEvents rdPenerbit As System.Windows.Forms.RadioButton
    Friend WithEvents rdJenis As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtJual2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtJual1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnLaporanNota As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNota2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNota1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnLaporanBuku As System.Windows.Forms.Button
    Friend WithEvents btnLaporanTanggal As System.Windows.Forms.Button

End Class
