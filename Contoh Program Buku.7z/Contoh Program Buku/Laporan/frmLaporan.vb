Imports System.Globalization

Public Class frmLaporan
    Private MyDataSet As DataSet = New DataSet()
    Private MyAdapter As New MySqlDataAdapter()
    Private CMD As New MySqlCommand
    Private CN As New MySqlConnection
    Private SQL As String

    Private Sub frmLaporan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Laporan"
        GroupBox1.Text = "Laporan Buku"
        GroupBox2.Text = "Laporan Penjualan"
    End Sub

    Private Sub btnLaporanBuku_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaporanBuku.Click
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        If rdJenis.Checked = True Then
            MyDataSet.Clear()
            SQL = "SELECT * FROM RPT_BUKU_VW;"

            Try
                CMD = New MySqlCommand(SQL, CN)
                MyAdapter.SelectCommand = CMD
                MyAdapter.Fill(MyDataSet, "RPT_BUKU_VW")

                Dim MyReport As New rptJenisBuku
                MyReport.SetDataSource(MyDataSet)
                Dim frmVL As ViewLaporan = ViewLaporan
                'menghidupkan displaygroupdirectory
                frmVL.CrystalReportViewer1.DisplayGroupTree = True
                frmVL.CrystalReportViewer1.ReportSource = MyReport
                frmVL.Show()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CN.Close()
                CN = Nothing
            End Try
        End If

        If rdPenerbit.Checked = True Then
            MyDataSet.Clear()
            SQL = "SELECT * FROM RPT_BUKU_VW;"
            Try
                CMD = New MySqlCommand(SQL, CN)
                MyAdapter.SelectCommand = CMD
                MyAdapter.Fill(MyDataSet, "RPT_BUKU_VW")

                Dim MyReport As New rptPenerbitBuku
                MyReport.SetDataSource(MyDataSet)
                Dim frmVL As ViewLaporan = ViewLaporan
                'menghidupkan displaygroupdirectory
                frmVL.CrystalReportViewer1.DisplayGroupTree = True
                frmVL.CrystalReportViewer1.ReportSource = MyReport
                frmVL.Show()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CN.Close()
                CN = Nothing
            End Try
        End If

        If rdPenulis.Checked = True Then
            MyDataSet.Clear()
            SQL = "SELECT * FROM RPT_BUKU_VW;"
            Try
                CMD = New MySqlCommand(SQL, CN)
                MyAdapter.SelectCommand = CMD
                MyAdapter.Fill(MyDataSet, "RPT_BUKU_VW")

                Dim MyReport As New rptPenulisBuku
                MyReport.SetDataSource(MyDataSet)
                Dim frmVL As ViewLaporan = ViewLaporan
                'menghidupkan displaygroupdirectory
                frmVL.CrystalReportViewer1.DisplayGroupTree = True
                frmVL.CrystalReportViewer1.ReportSource = MyReport
                frmVL.Show()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub btnLaporanNota_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaporanNota.Click
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()
        Try
            MyDataSet.Clear()
            SQL = "SELECT * FROM RPT_PENJUALAN_VW "
            SQL &= "WHERE nota_jual BETWEEN @Nota1 AND @Nota2"
            CMD = New MySqlCommand(SQL, CN)
            CMD.Parameters.Add("@Nota1", MySqlDbType.VarChar, 10).Value = txtNota1.Text
            CMD.Parameters.Add("@Nota2", MySqlDbType.VarChar, 10).Value = txtNota2.Text
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataSet, "RPT_PENJUALAN_VW")

            Dim MyReport As New rptPenjualanPerNota
            MyReport.SetDataSource(MyDataSet)
            Dim frmVL As ViewLaporan = ViewLaporan
            frmVL.CrystalReportViewer1.ReportSource = MyReport
            frmVL.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub btnLaporanTanggal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaporanTanggal.Click
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()
        Try
            MyDataSet.Clear()
            SQL = "SELECT * FROM RPT_PENJUALAN_PERTGL_VW "
            SQL &= "WHERE tgl_jual BETWEEN @tgl1 AND @tgl2;"
            CMD = New MySqlCommand(SQL, CN)
            CMD.Parameters.Add("@tgl1", MySqlDbType.Date).Value = dtJual1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            CMD.Parameters.Add("@tgl2", MySqlDbType.Date).Value = dtJual2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataSet, "RPT_PENJUALAN_PERTGL_VW")

            Dim MyReport As New rptPenjualanPerTgl
            MyReport.SetDataSource(MyDataSet)
            Dim frmVL As ViewLaporan = ViewLaporan
            'menghidupkan displaygroupdirectory
            frmVL.CrystalReportViewer1.DisplayGroupTree = False
            frmVL.CrystalReportViewer1.ReportSource = MyReport
            frmVL.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub
End Class
