Imports MySql.Data.MySqlClient

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim cmd As MySqlCommand = conn.CreateCommand
        cmd.CommandType = CommandType.Text
        'Sengaja pernyataan di bawah ini ditutup, untuk melihat kesalahannya
        'cmd.CommandText = "CALL BROWSE_SP ('PENULIS', '', 'Dodit')"


        Try
            ' Open connection
            conn.Open()

            ' menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader()
            ' Access nonexistent column
            Dim str As String = rdr.GetValue(20).ToString()

            ' menutup data reader
            rdr.Close()

        Catch salah As MySqlException
            Dim str As String = "Sumber: " & salah.Source
            str &= ControlChars.NewLine
            str &= "Pesan Exception: " & salah.Message
            MessageBox.Show(str, "Database Exception")

        Catch ex As System.Exception
            Dim str As String = "Sumber: " & ex.Source
            str &= ControlChars.NewLine
            str &= "Pesan Exception: " & ex.Message
            MessageBox.Show(str, "Selain Database Exception")

        Finally
            If conn.State = ConnectionState.Open Then
                MessageBox.Show("Blok akhir penutupan connection ", "Akhir")
                conn.Close()
            End If
        End Try
        
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim cmd As MySqlCommand = conn.CreateCommand
        cmd.CommandType = CommandType.Text
        'Sengaja pernyataan di bawah ini ditutup, untuk melihat kesalahannya
        cmd.CommandText = "CALL BROWSE_SP1 ('PENULIS', '', 'Dodit')"

        Try
            ' Open connection
            conn.Open()

            ' menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader()
            'mengakses kolom yang tidak ada
            'Dim str As String = rdr.GetValue(20).ToString()

            ' menutup data reader
            rdr.Close()

        Catch ex As System.InvalidOperationException
            Dim str As String = "Source: " & ex.Source
            str &= ControlChars.NewLine
            str &= "Message: " & ex.Message
            str &= ControlChars.NewLine & ControlChars.NewLine
            str &= "Stack Trace: " & ex.StackTrace
            MessageBox.Show(str, "Specific Exception")

        Catch ex As MySqlException
            Dim str As String = "Sumber: " & ex.Source
            str &= ControlChars.NewLine
            str &= "Pesan Exception: " & ex.Message
            MessageBox.Show(str, "Database Exception")

        Catch ex As Exception
            Dim str As String = "Sumber: " & ex.Source
            str &= ControlChars.NewLine
            str &= "Pesan Exception: " & ex.Message
            MessageBox.Show(str, "Selain Database Exception")

        Finally
            If conn.State = ConnectionState.Open Then
                MessageBox.Show("Blok akhir penutupan connection ", "Akhir")
                conn.Close()
            End If
        End Try
    End Sub
End Class
