Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'menciptakan string query
        Dim SqlQry As String = "select count(*) from penulis_tb"

        'menciptakan pernyataan insert
        Dim SqlIns As String
        SqlIns = "insert into penulis_tb(kode_penulis, nama_penulis) "
        SqlIns = SqlIns & "values('0000000016', 'Rony Sianturi')"

        'menciptakan pernyataan delete
        Dim SqlDel As String
        SqlDel = "delete from penulis_tb where "
        SqlDel = SqlDel & "kode_penulis='0000000016' "
        SqlDel = SqlDel & "and nama_penulis='Rony Sianturi'"

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim CmdQry As MySqlCommand = New MySqlCommand(SqlQry, conn)
        Dim CmdNon As MySqlCommand = New MySqlCommand(SqlIns, conn)
        Console.WriteLine("Command telah tercipta dan terkoneksi.")

        Try
            'membuka connection
            conn.Open()

            'eksekusi query untuk mendapatkan jumlah penulis
            Console.WriteLine("Sebelum INSERT: Jumlah penulis = " & CmdQry.ExecuteScalar)

            'eksekusi nonquery untuk memasukkan penulis baru
            Console.WriteLine("Eksekusi pernyataan = " & CmdNon.CommandText)
            CmdNon.ExecuteNonQuery()
            Console.WriteLine("Setelah INSERT: Jumlah penulis = " & CmdQry.ExecuteScalar)

            'eksekusi nonquery untuk menghapus penulis
            CmdNon.CommandText = SqlDel
            Console.WriteLine("Eksekusi pernyataan " & CmdNon.CommandText)
            CmdNon.ExecuteNonQuery()
            Console.WriteLine("Setelah DELETE: Jumlah penulis = " & CmdQry.ExecuteScalar)

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try

    End Sub

End Module
