Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd


        'set up query
        Dim sql As String
        sql = "select judul, harga_jual, tahun_terbit, jumlah_halaman "
        sql = sql & "from buku_tb "

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(sql, conn)

            'menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader

            'perulangan melalui result set
            While rdr.Read
                Console.WriteLine("{0}   {1}   {2}   {3}", _
                rdr.GetString(0).PadRight(50), _
                rdr.GetDouble(1), _
                rdr.GetInt16(2), _
                rdr.GetInt32(3))
            End While

                'menutup data reader
                rdr.Close()

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
