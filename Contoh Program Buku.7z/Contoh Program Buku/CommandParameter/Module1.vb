Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'isi variable sebagai data mentah
        Dim Kode As String = "0000000016"
        Dim Penulis As String = "Rony Sianturi"

        'menciptakan string query
        Dim SqlQry As String = "select count(*) from penulis_tb"

        'menciptakan pernyataan insert
        Dim SqlIns As String
        SqlIns = "insert into penulis_tb(kode_penulis, nama_penulis) "
        SqlIns = SqlIns & "values('@kode', '@penulis')"

        'menciptakan pernyataan delete
        Dim SqlDel As String
        SqlDel = "delete from penulis_tb where "
        SqlDel = SqlDel & "kode_penulis='@kode' "
        SqlDel = SqlDel & "and nama_penulis='@penulis'"

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim CmdQry As MySqlCommand = New MySqlCommand(SqlQry, conn)
        Dim CmdNon As MySqlCommand = New MySqlCommand(SqlIns, conn)
        Console.WriteLine("Command telah tercipta dan terkoneksi.")

        'menambahkan parameter ke command untuk pengeksekusian pernyataan
        CmdNon.Parameters.Add("@kode", MySqlDbType.String, 10)
        CmdNon.Parameters.Add("@penulis", MySqlDbType.VarChar, 30)

        Try
            'membuka connection
            conn.Open()

            'eksekusi query untuk mendapatkan jumlah penulis
            Console.WriteLine("Sebelum INSERT: Jumlah penulis = " & CmdQry.ExecuteScalar)

            'eksekusi nonquery untuk memasukkan penulis baru
            CmdNon.Parameters("@kode").Value = Kode
            CmdNon.Parameters("@penulis").Value = Penulis

            Console.WriteLine("Eksekusi pernyataan = " & CmdNon.CommandText)
            CmdNon.ExecuteNonQuery()
            Console.WriteLine("Setelah INSERT: Jumlah penulis = " & CmdQry.ExecuteScalar)

            'eksekusi nonquery untuk menghapus penulis
            CmdNon.CommandText = SqlDel
            Console.WriteLine("Eksekusi pernyataan " & CmdNon.CommandText)
            CmdNon.ExecuteNonQuery()
            Console.WriteLine("Setelah DELETE: Jumlah penulis = " & CmdQry.ExecuteScalar)

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try
    End Sub

End Module
