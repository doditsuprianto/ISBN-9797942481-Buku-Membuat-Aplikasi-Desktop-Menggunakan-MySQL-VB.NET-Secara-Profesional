'namespace penanggalan
Imports System.Globalization

Public Class frmValidasi

    Private Sub frmValidasi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Input Validasi"
    End Sub

    Private Sub txtEmail_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtEmail.Leave
        '------------------------------------------------
        'memastikan bahwa inputan mengikuti format email
        '------------------------------------------------
        Email_Valid(txtEmail.Text, txtEmail)
    End Sub

    Private Sub txtWebsite_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtWebsite.Leave
        '------------------------------------------------
        'memastikan bahwa inputan mengikuti format website
        '------------------------------------------------
        Web_Valid(txtWebsite.Text, txtWebsite)
    End Sub

    Private Sub txtNumerik_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNumerik.Leave
        '--------------------------------------
        'memastikan bahwa inputan berupa angka
        '--------------------------------------
        Numerik_Valid(txtNumerik.Text, txtNumerik)
    End Sub

    Private Sub txtHuruf_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHuruf.Leave
        '--------------------------------------
        'memastikan bahwa inputan berupa angka
        '--------------------------------------
        Alphabet_Valid(txtHuruf.Text, txtHuruf)
    End Sub

    Private Sub btnTanggal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTanggal.Click
        Dim Pesan As String
        Pesan = "Tanggal Valid sesuai format database adalah: " & dtTanggal.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
        MessageBox.Show(Pesan, "Tanggal Valid", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
