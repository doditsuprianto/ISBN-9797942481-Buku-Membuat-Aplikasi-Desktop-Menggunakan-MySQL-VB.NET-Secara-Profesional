Imports System.Text.RegularExpressions

Module ModValidasi
    Public Sub Alphabet_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input alphabet saja
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim alphabetPattern As String = "^[a-zA-Z]+$"

        If Regex.IsMatch(Karakter.ToString, alphabetPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Web_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input email
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim webPattern As String = "^https?://([\w-]+\.)+[\w-]+(/ [\w-./?%=]*)?$"

        If Regex.IsMatch(Karakter.ToString, webPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Email_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input email
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim emailPattern As String = "^([0-9a-zA-Z]+[-._+&])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$"

        If Regex.IsMatch(Karakter.ToString, emailPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Numerik_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input numerik
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim numDouble As String = "[-+]?([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?"

        If Regex.IsMatch(Karakter.ToString, numDouble) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub
End Module
