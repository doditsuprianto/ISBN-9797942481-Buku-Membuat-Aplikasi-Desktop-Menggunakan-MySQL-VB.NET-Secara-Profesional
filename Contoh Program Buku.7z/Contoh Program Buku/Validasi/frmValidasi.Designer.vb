<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmValidasi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtEmail = New System.Windows.Forms.TextBox
        Me.txtWebsite = New System.Windows.Forms.TextBox
        Me.txtNumerik = New System.Windows.Forms.TextBox
        Me.txtHuruf = New System.Windows.Forms.TextBox
        Me.dtTanggal = New System.Windows.Forms.DateTimePicker
        Me.btnTanggal = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Email:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Website:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 71)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Masukkan Angka:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 97)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Masukkan Huruf:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 122)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(169, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Tanggal Dengan DateTimePicker:"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(187, 12)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(200, 20)
        Me.txtEmail.TabIndex = 5
        '
        'txtWebsite
        '
        Me.txtWebsite.Location = New System.Drawing.Point(187, 38)
        Me.txtWebsite.Name = "txtWebsite"
        Me.txtWebsite.Size = New System.Drawing.Size(200, 20)
        Me.txtWebsite.TabIndex = 6
        '
        'txtNumerik
        '
        Me.txtNumerik.Location = New System.Drawing.Point(187, 64)
        Me.txtNumerik.Name = "txtNumerik"
        Me.txtNumerik.Size = New System.Drawing.Size(200, 20)
        Me.txtNumerik.TabIndex = 7
        '
        'txtHuruf
        '
        Me.txtHuruf.Location = New System.Drawing.Point(187, 90)
        Me.txtHuruf.Name = "txtHuruf"
        Me.txtHuruf.Size = New System.Drawing.Size(200, 20)
        Me.txtHuruf.TabIndex = 8
        '
        'dtTanggal
        '
        Me.dtTanggal.Location = New System.Drawing.Point(187, 116)
        Me.dtTanggal.Name = "dtTanggal"
        Me.dtTanggal.Size = New System.Drawing.Size(200, 20)
        Me.dtTanggal.TabIndex = 9
        '
        'btnTanggal
        '
        Me.btnTanggal.Location = New System.Drawing.Point(251, 142)
        Me.btnTanggal.Name = "btnTanggal"
        Me.btnTanggal.Size = New System.Drawing.Size(136, 36)
        Me.btnTanggal.TabIndex = 10
        Me.btnTanggal.Text = "Cek Format Tanggal"
        Me.btnTanggal.UseVisualStyleBackColor = True
        '
        'frmValidasi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 185)
        Me.Controls.Add(Me.btnTanggal)
        Me.Controls.Add(Me.dtTanggal)
        Me.Controls.Add(Me.txtHuruf)
        Me.Controls.Add(Me.txtNumerik)
        Me.Controls.Add(Me.txtWebsite)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmValidasi"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtWebsite As System.Windows.Forms.TextBox
    Friend WithEvents txtNumerik As System.Windows.Forms.TextBox
    Friend WithEvents txtHuruf As System.Windows.Forms.TextBox
    Friend WithEvents dtTanggal As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnTanggal As System.Windows.Forms.Button

End Class
