Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim sql As String = "select * from penerbit_tb;"

        'set up DML
        Dim del As String
        del = "delete from penerbit_tb "
        del &= "where kode_penerbit = @kode_penerbit;"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dan mengisi dataset
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "penerbit_tb")

            'mendapatkan referensi table
            Dim dt As DataTable = ds.Tables("penerbit_tb")

            'menghapus penerbit_tb
            '
            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(del, conn)

            'memetakan parameter
            cmd.Parameters.Add("@kode_penerbit", MySqlDbType.VarChar, 10, "kode_penerbit")
         
            'memilih penerbit_tb untuk dihapus
            Dim filt As String = "kode_penerbit = '0000000008' " _
            & "and nama_penerbit = 'Penerbit Baru' "
            '
            'menghapus penerbit_tb dari data table
            For Each row As DataRow In dt.Select(filt)
                row.Delete()
            Next

            'Update database
            da.DeleteCommand = cmd
            da.Update(ds, "penerbit_tb")

            'menampilkan data table
            For Each row As DataRow In dt.Rows
                Console.WriteLine("{0} {1} {2}", _
                row("kode_penerbit").ToString().PadRight(10), _
                row("nama_penerbit").ToString().PadLeft(30), _
                row("alamat"))
            Next
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
