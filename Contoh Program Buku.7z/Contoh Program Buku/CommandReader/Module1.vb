Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'menciptakan string query
        Dim SQL As String = "select kode_penulis, nama_penulis from penulis_tb"

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim CMD As MySqlCommand = New MySqlCommand(SQL, conn)
        Console.WriteLine("Command telah tercipta dan telah terhubung.")

        Try
            'membuka connection
            conn.Open()

            'eksekusi query
            Dim rdr As MySqlDataReader = CMD.ExecuteReader
            While rdr.Read
                Console.WriteLine("Kode: {0} Penulis: {1}", rdr.GetValue(0), rdr.GetValue(1))
            End While
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try

    End Sub

End Module
