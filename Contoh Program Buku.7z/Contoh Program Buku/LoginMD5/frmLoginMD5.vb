Imports System
Imports System.Security.Cryptography
Imports System.Text

Public Class frmLoginMD5
    'Deklarasi variable object Connection ke MySQl
    Private CN As New MySqlConnection

    Function getMd5Hash(ByVal input As String) As String
        'Menciptakan instan object MD5
        Dim md5Hasher As MD5 = MD5.Create()

        'Mengkonversi input string ke array byte dan menghitung hash
        Dim data As Byte() = md5Hasher.ComputeHash(Encoding.Default.GetBytes(input))

        ' Create a new Stringbuilder to collect the bytes
        ' and create a string.
        Dim sBuilder As New StringBuilder()

        ' Perulangan setiap byte data yang ter-hash 
        ' dan memformatnya menjadi string heksadesimal
        Dim i As Integer
        For i = 0 To data.Length - 1
            sBuilder.Append(data(i).ToString("x2"))
        Next i

        'mengembalikan nilai heksadesimal
        Return sBuilder.ToString()
    End Function

    Function verifyMd5Hash(ByVal input As String, ByVal hash As String) As Boolean
        Dim hashOfInput As String = getMd5Hash(input)

        'Perbandingan string
        Dim comparer As StringComparer = StringComparer.OrdinalIgnoreCase
        If 0 = comparer.Compare(hashOfInput, hash) Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim myConnectionString As String
        myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim DataReader As MySqlDataReader = Nothing
        Dim CMDTampilData As MySqlCommand = CN.CreateCommand()
        Try
            Dim strSQL As String = "SELECT * FROM login_tb WHERE user=@user AND password=@password"
            CMDTampilData.Parameters.Add("@user", MySqlDbType.VarChar, 30).Value = txtUser.Text
            CMDTampilData.Parameters.Add("@password", MySqlDbType.VarChar, 32).Value = getMd5Hash(txtPassword.Text)
            CMDTampilData.CommandText = strSQL
            DataReader = CMDTampilData.ExecuteReader()

            If DataReader.Read() Then
                'Lakukan sesuatu di sini, seperti masuk ke proses selanjutnya
                'Biasanya adalah ke Form MDI atau ke kea palikasi yang lebih dalam
                MessageBox.Show("User Anda: " & DataReader("user").ToString & vbCrLf & "Password Asli Anda: " & txtPassword.Text & vbCrLf & "User Tersandikan : " & DataReader("password").ToString & vbCrLf & "telah sesuai dan terdaftar di database", "Konfirmasi Password", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("User tidak terdaftar", "Konfirmasi Password", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
            DataReader.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDTampilData.Dispose()
            CN.Close()
            CN = Nothing
        End Try        
    End Sub

    Private Sub frmLoginMD5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Login Table MD5"
        txtPassword.PasswordChar = Chr(12)
    End Sub

    Private Sub btnUserBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUserBaru.Click
        Dim myConnectionString As String
        myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim CMDLogin As MySqlCommand = CN.CreateCommand
        Try
            Dim strSQL As String = "INSERT INTO login_tb (user, password) VALUES (@user, @password)"
            With CMDLogin
                .CommandText = strSQL
                .Connection = CN
                .Parameters.Add("@user", MySqlDbType.VarChar, 30).Value = txtUser.Text
                .Parameters.Add("@password", MySqlDbType.VarChar, 32).Value = getMd5Hash(txtPassword.Text)
                .ExecuteNonQuery()
            End With
            txtUser.Text = ""
            txtPassword.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDLogin.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Me.Close()
    End Sub
End Class
