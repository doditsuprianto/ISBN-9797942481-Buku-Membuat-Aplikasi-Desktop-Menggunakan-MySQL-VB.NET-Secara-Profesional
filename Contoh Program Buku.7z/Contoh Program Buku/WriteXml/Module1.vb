Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim qry As String = "select * from penerbit_tb limit 0,3;"


        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(qry, conn)

            'menciptakan dan mengisi dataset
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "penerbit")

            'menguraikan dataset ke file XML
            ds.WriteXml("d:\penerbit\VB_MySQL\penerbit.xml")
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
