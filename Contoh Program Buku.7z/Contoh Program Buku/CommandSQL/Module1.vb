Imports MySQL.Data.MySQLClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim CMD As MySqlCommand = New MySqlCommand()
        Console.WriteLine("Command telah tercipta.")

        Try
            'membuka connection
            conn.Open()

            'mengubungkan command ke connection
            CMD.Connection = conn
            Console.WriteLine("Command telah terhubung dengan Connection")

            'menghubungkan SQL dengan command
            CMD.CommandText = "select count(*) from buku_tb"
            Console.WriteLine("SQL siap untuk dieksekusi: " & CMD.CommandText)

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try

    End Sub

End Module
