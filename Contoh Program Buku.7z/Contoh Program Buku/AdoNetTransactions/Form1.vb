Imports MySql.Data.MySqlClient

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'pernyataan INSERT
        Dim sqlins As String
        sqlins = "insert into penulis_tb "
        sqlins &= "(kode_penulis, nama_penulis) "
        sqlins &= "values (@kd_baru, @nm_baru)"

        'pernyataan DELETE
        Dim sqldel As String
        sqldel = "delete from penulis_tb "
        sqldel &= "where kode_penulis = @kd_lama"

        'membuka connection
        conn.Open()

        'awal transaction
        Dim sqltrans As MySqlTransaction = conn.BeginTransaction()

        Try
            'menciptakan command insert
            Dim cmdins As MySqlCommand = conn.CreateCommand()
            cmdins.CommandText = sqlins
            cmdins.Transaction = sqltrans
            cmdins.Parameters.Add("@kd_baru", MySqlDbType.VarChar, 10)
            cmdins.Parameters.Add("@nm_baru", MySqlDbType.VarChar, 30)

            'menciptakan command delete
            Dim cmddel As MySqlCommand = conn.CreateCommand()
            cmddel.CommandText = sqldel
            cmddel.Transaction = sqltrans
            cmddel.Parameters.Add("@kd_lama", MySqlDbType.VarChar, 10)

            'Menambahkan penulis
            cmdins.Parameters("@kd_baru").Value = TextBox1.Text
            cmdins.Parameters("@nm_baru").Value = TextBox2.Text
            cmdins.ExecuteNonQuery()

            'Menghapus penulis
            cmddel.Parameters("@kd_lama").Value = TextBox3.Text
            cmddel.ExecuteNonQuery()

            'Commit transaction
            sqltrans.Commit()

            'Tidak ada exception, 
            'transaction committed (terupdate permanen)
            MessageBox.Show("Transaction committed")

        Catch ex As MySqlException
            ' Roll back transaction
            sqltrans.Rollback()
            MessageBox.Show("Transaction rolled back: " + ex.Message, "Rollback Transaction")

        Catch ex As Exception
            MessageBox.Show("System Error: " + ex.Message, "Error")

        Finally
            'Menutup connection
            conn.Close()
        End Try
    End Sub
End Class
