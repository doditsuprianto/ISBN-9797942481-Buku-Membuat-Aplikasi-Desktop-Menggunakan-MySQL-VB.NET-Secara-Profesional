Imports MySql.Data.MySqlClient

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim sql As String = "select * from penulis_tb"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan data adapter
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

        'menciptakan dataset
        Dim ds As DataSet = New DataSet
        da.Fill(ds, "penulis_tb")

        'Bind kolom kode_penulis dari table penulis_tb ke TextBox1
        TextBox1.DataBindings.Add("text", ds, "penulis_tb.kode_penulis")
        'Bind kolom nama_penulis dari table penulis_tb ke TextBox2
        TextBox2.DataBindings.Add("text", ds, "penulis_tb.nama_penulis")
    End Sub

End Class
