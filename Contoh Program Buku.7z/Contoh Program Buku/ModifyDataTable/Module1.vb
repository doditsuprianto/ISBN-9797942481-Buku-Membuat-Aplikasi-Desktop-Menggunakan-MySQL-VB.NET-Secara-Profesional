Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim sql As String
        sql = "select kode_penerbit, nama_penerbit, alamat, "
        sql &= "kota, kode_pos, telp, email, website from penerbit_tb "

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dan mengisi dataset
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "penerbit_tb")

            'mendapatkan referensi table
            Dim dt As DataTable = ds.Tables("penerbit_tb")

            'perubahan schema, kolom nama_penulis boleh null
            dt.Columns("nama_penerbit").AllowDBNull = True

            'memodifikasi email pada baris pertama
            dt.Rows(0)("nama_penerbit") = "New Penerbit"

            'menambahkan baris
            Dim newRow As DataRow = dt.NewRow()
            newRow("nama_penerbit") = "Joe Satriani"
            newRow("alamat") = "Sartono SH 4"
            newRow("kota") = "Malang"
            newRow("kode_pos") = "65118"
            newRow("telp") = "0341-356781"
            newRow("email") = "joe@yahoo.com"
            newRow("website") = "www.joes.com"
            dt.Rows.Add(newRow)

            'menampilkan baris di dalam data table
            For Each row As DataRow In dt.Rows
                Console.WriteLine( _
                "{0} {1} {2}", _
                row("nama_penerbit").ToString().PadRight(21), _
                row("alamat").ToString().PadRight(40), _
                row("kota"))
            Next

            '
            'kode untuk mengubahnya ke database berada disini
            '
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
