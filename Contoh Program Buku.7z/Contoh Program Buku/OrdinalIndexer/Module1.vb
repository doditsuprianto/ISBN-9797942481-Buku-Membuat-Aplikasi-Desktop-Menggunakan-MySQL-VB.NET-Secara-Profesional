Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd


        'set up query
        Dim sql As String
        sql = "select kode_penulis, nama_penulis from penulis_tb "
        sql = sql & "where nama_penulis like 'B%'"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(sql, conn)

            'menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader

            'cetak heading
            Console.WriteLine("  {0}   {1}", "Kode".PadRight(10), "Nama Penulis".PadRight(30))
            Console.WriteLine("  {0}   {1}", "----------".PadRight(10), "----------".PadRight(30))

            'perulangan melalui result set
            While rdr.Read
                Console.WriteLine("  {0} | {1}", rdr("kode_penulis").ToString.PadRight(10), rdr("nama_penulis").ToString.PadRight(30))
            End While

            'menutup data reader
            rdr.Close()

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
