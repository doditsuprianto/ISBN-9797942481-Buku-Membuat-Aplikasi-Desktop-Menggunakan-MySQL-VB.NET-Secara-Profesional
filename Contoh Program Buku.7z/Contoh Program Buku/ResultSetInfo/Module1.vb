Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd


        'set up query
        Dim sql As String
        sql = "select kode_penulis, nama_penulis "
        sql = sql & "from penulis_tb "
        'sql = sql & "where nama_penulis = 'B%'"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(sql, conn)

            'menciptakan data reader
            Dim rdr As MySqlDataReader = cmd.ExecuteReader


            'mendapatkan nama kolom
            Console.WriteLine("Nama Kolom: {0}     {1}", _
            rdr.GetName(0).PadRight(10), _
            rdr.GetName(1))

            'mendapatkan tipe data kolom
            Console.WriteLine("Tipe Data: {0}     {1}", _
            rdr.GetDataTypeName(0).PadRight(10), _
            rdr.GetDataTypeName(1))

            Console.WriteLine()

            'perulangan melalui result set
            While rdr.Read
                Console.WriteLine("           {0}     {1}", _
                rdr.GetString(0).PadRight(10), _
                rdr.GetString(1))
            End While

            'mendapatkan jumlah kolom
            Console.WriteLine()
            Console.WriteLine("Jumlah kolom pada setiap baris: {0}", _
            rdr.FieldCount)

            'mendapatkan informasi setiap kolom
            Console.WriteLine("'{0}' berada di index {1} dan bertipe {2}", _
            rdr.GetName(0), _
            rdr.GetOrdinal("kode_penulis"), _
            rdr.GetFieldType(0))

            Console.WriteLine("'{0}' berada di index {1} dan bertipe {2}", _
            rdr.GetName(1), _
            rdr.GetOrdinal("nama_penulis"), _
            rdr.GetFieldType(1))

            'menutup data reader
            rdr.Close()

        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
