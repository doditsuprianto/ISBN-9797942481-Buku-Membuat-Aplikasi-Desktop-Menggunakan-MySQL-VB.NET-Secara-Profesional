Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbpenjualanbukuDataSet.buku_tb' table. You can move, or remove it, as needed.
        Me.Buku_tbTableAdapter.Fill(Me.DbpenjualanbukuDataSet.buku_tb)

    End Sub
End Class
