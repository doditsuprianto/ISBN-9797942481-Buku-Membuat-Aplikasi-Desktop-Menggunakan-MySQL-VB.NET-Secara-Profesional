<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.KodebukuDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IsbnDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.JudulDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.KodepenulisDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.KodepenerbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.KodekelompokDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.HargajualDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SinopsisDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TahunterbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.JumlahhalamanDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FotoDataGridViewImageColumn = New System.Windows.Forms.DataGridViewImageColumn
        Me.NamafotoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.BukutbBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DbpenjualanbukuDataSet = New ComplexBinding.dbpenjualanbukuDataSet
        Me.Buku_tbTableAdapter = New ComplexBinding.dbpenjualanbukuDataSetTableAdapters.buku_tbTableAdapter
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BukutbBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DbpenjualanbukuDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.KodebukuDataGridViewTextBoxColumn, Me.IsbnDataGridViewTextBoxColumn, Me.JudulDataGridViewTextBoxColumn, Me.KodepenulisDataGridViewTextBoxColumn, Me.KodepenerbitDataGridViewTextBoxColumn, Me.KodekelompokDataGridViewTextBoxColumn, Me.HargajualDataGridViewTextBoxColumn, Me.SinopsisDataGridViewTextBoxColumn, Me.TahunterbitDataGridViewTextBoxColumn, Me.JumlahhalamanDataGridViewTextBoxColumn, Me.FotoDataGridViewImageColumn, Me.NamafotoDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BukutbBindingSource
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(556, 339)
        Me.DataGridView1.TabIndex = 0
        '
        'KodebukuDataGridViewTextBoxColumn
        '
        Me.KodebukuDataGridViewTextBoxColumn.DataPropertyName = "kode_buku"
        Me.KodebukuDataGridViewTextBoxColumn.HeaderText = "kode_buku"
        Me.KodebukuDataGridViewTextBoxColumn.Name = "KodebukuDataGridViewTextBoxColumn"
        '
        'IsbnDataGridViewTextBoxColumn
        '
        Me.IsbnDataGridViewTextBoxColumn.DataPropertyName = "isbn"
        Me.IsbnDataGridViewTextBoxColumn.HeaderText = "isbn"
        Me.IsbnDataGridViewTextBoxColumn.Name = "IsbnDataGridViewTextBoxColumn"
        '
        'JudulDataGridViewTextBoxColumn
        '
        Me.JudulDataGridViewTextBoxColumn.DataPropertyName = "judul"
        Me.JudulDataGridViewTextBoxColumn.HeaderText = "judul"
        Me.JudulDataGridViewTextBoxColumn.Name = "JudulDataGridViewTextBoxColumn"
        '
        'KodepenulisDataGridViewTextBoxColumn
        '
        Me.KodepenulisDataGridViewTextBoxColumn.DataPropertyName = "kode_penulis"
        Me.KodepenulisDataGridViewTextBoxColumn.HeaderText = "kode_penulis"
        Me.KodepenulisDataGridViewTextBoxColumn.Name = "KodepenulisDataGridViewTextBoxColumn"
        '
        'KodepenerbitDataGridViewTextBoxColumn
        '
        Me.KodepenerbitDataGridViewTextBoxColumn.DataPropertyName = "kode_penerbit"
        Me.KodepenerbitDataGridViewTextBoxColumn.HeaderText = "kode_penerbit"
        Me.KodepenerbitDataGridViewTextBoxColumn.Name = "KodepenerbitDataGridViewTextBoxColumn"
        '
        'KodekelompokDataGridViewTextBoxColumn
        '
        Me.KodekelompokDataGridViewTextBoxColumn.DataPropertyName = "kode_kelompok"
        Me.KodekelompokDataGridViewTextBoxColumn.HeaderText = "kode_kelompok"
        Me.KodekelompokDataGridViewTextBoxColumn.Name = "KodekelompokDataGridViewTextBoxColumn"
        '
        'HargajualDataGridViewTextBoxColumn
        '
        Me.HargajualDataGridViewTextBoxColumn.DataPropertyName = "harga_jual"
        Me.HargajualDataGridViewTextBoxColumn.HeaderText = "harga_jual"
        Me.HargajualDataGridViewTextBoxColumn.Name = "HargajualDataGridViewTextBoxColumn"
        '
        'SinopsisDataGridViewTextBoxColumn
        '
        Me.SinopsisDataGridViewTextBoxColumn.DataPropertyName = "sinopsis"
        Me.SinopsisDataGridViewTextBoxColumn.HeaderText = "sinopsis"
        Me.SinopsisDataGridViewTextBoxColumn.Name = "SinopsisDataGridViewTextBoxColumn"
        '
        'TahunterbitDataGridViewTextBoxColumn
        '
        Me.TahunterbitDataGridViewTextBoxColumn.DataPropertyName = "tahun_terbit"
        Me.TahunterbitDataGridViewTextBoxColumn.HeaderText = "tahun_terbit"
        Me.TahunterbitDataGridViewTextBoxColumn.Name = "TahunterbitDataGridViewTextBoxColumn"
        '
        'JumlahhalamanDataGridViewTextBoxColumn
        '
        Me.JumlahhalamanDataGridViewTextBoxColumn.DataPropertyName = "jumlah_halaman"
        Me.JumlahhalamanDataGridViewTextBoxColumn.HeaderText = "jumlah_halaman"
        Me.JumlahhalamanDataGridViewTextBoxColumn.Name = "JumlahhalamanDataGridViewTextBoxColumn"
        '
        'FotoDataGridViewImageColumn
        '
        Me.FotoDataGridViewImageColumn.DataPropertyName = "foto"
        Me.FotoDataGridViewImageColumn.HeaderText = "foto"
        Me.FotoDataGridViewImageColumn.Name = "FotoDataGridViewImageColumn"
        '
        'NamafotoDataGridViewTextBoxColumn
        '
        Me.NamafotoDataGridViewTextBoxColumn.DataPropertyName = "nama_foto"
        Me.NamafotoDataGridViewTextBoxColumn.HeaderText = "nama_foto"
        Me.NamafotoDataGridViewTextBoxColumn.Name = "NamafotoDataGridViewTextBoxColumn"
        '
        'BukutbBindingSource
        '
        Me.BukutbBindingSource.DataMember = "buku_tb"
        Me.BukutbBindingSource.DataSource = Me.DbpenjualanbukuDataSet
        '
        'DbpenjualanbukuDataSet
        '
        Me.DbpenjualanbukuDataSet.DataSetName = "dbpenjualanbukuDataSet"
        Me.DbpenjualanbukuDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Buku_tbTableAdapter
        '
        Me.Buku_tbTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 339)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form1"
        Me.Text = "Complex Binding"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BukutbBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DbpenjualanbukuDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DbpenjualanbukuDataSet As ComplexBinding.dbpenjualanbukuDataSet
    Friend WithEvents BukutbBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Buku_tbTableAdapter As ComplexBinding.dbpenjualanbukuDataSetTableAdapters.buku_tbTableAdapter
    Friend WithEvents KodebukuDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IsbnDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents JudulDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KodepenulisDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KodepenerbitDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KodekelompokDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HargajualDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SinopsisDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TahunterbitDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents JumlahhalamanDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FotoDataGridViewImageColumn As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents NamafotoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
