'Namespace yang berhubungan dengan gambar
Imports System.IO
Imports System.Drawing.Bitmap

Public Class frmFotoBLOB

    Private strImgName As String
    Private imageBytes As Byte = Nothing
    Private FileSize As UInt32
    Private rawData() As Byte
    Private fs As FileStream
    'Deklarasi variable object Connection ke MySQl
    Private CN As New MySqlConnection

    Private Sub frmFotoBLOB_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtKode.AllowDrop = True
        GroupBox1.Text = "Foto"
        Me.Text = "Menyimpan Data Dan Foto Ke Table"
    End Sub

    Private Sub Insert_Foto()
        '-----------------------------------------------------------------
        'mengkonversi file image yang diperoleh dari OpenDialog
        'menjadi file bertipe Binary atau BLOB untuk disimpan di database
        '-----------------------------------------------------------------
        fs = New FileStream(strImgName, FileMode.Open, FileAccess.Read)
        FileSize = fs.Length
        rawData = New Byte(FileSize) {}
        fs.Read(rawData, 0, FileSize)
        fs.Close()
    End Sub

    Private Sub ClearForm()
        txtKode.Text = ""
        txtJudul.Text = ""
        txtPengarang.Text = ""
        txtPenerbit.Text = ""
        PictureBox1.Image = Nothing

        '-------------------------------------------
        'Menempatkan cursor keyboard ke txtKodeBuku
        '-------------------------------------------
        txtKode.Focus()

        btnSimpan.Enabled = True
        btnUbah.Enabled = True
        btnHapus.Enabled = True
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()
        '-------------------------------
        'memanggil method Insert_Foto()
        '-------------------------------
        Insert_Foto()
        '---------------------------
        'Deklarasi object command
        '---------------------------
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        If txtKode.Text <> "" Then
            Try
                Dim Sql As String = "INSERT INTO foto_tb (kode_buku, judul, pengarang, penerbit, foto) "
                Sql &= "VALUES (@kode_buku, @judul, @pengarang, @penerbit, @foto);"
                With CMDInsert
                    .CommandText = Sql
                    .Connection = CN
                    '------------------------------------------------------------------------
                    'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                    '------------------------------------------------------------------------                    
                    .Parameters.Add("@kode_buku", MySqlDbType.String, 10).Value = txtKode.Text
                    .Parameters.Add("@judul", MySqlDbType.TinyText).Value = txtJudul.Text
                    .Parameters.Add("@pengarang", MySqlDbType.VarChar, 30).Value = txtPengarang.Text
                    .Parameters.Add("@penerbit", MySqlDbType.VarChar, 30).Value = txtPenerbit.Text
                    .Parameters.Add("@foto", MySqlDbType.Blob).Value = rawData
                    '----------------------------
                    'Mengeksekusi Query dia atas
                    '----------------------------
                    .ExecuteNonQuery()
                End With
                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()
            Catch ex As MySqlException
                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CMDInsert.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub btnUbah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUbah.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()
        '-------------------------------
        'memanggil method Insert_Foto()
        '-------------------------------
        Insert_Foto()
        '---------------------------
        'Deklarasi object command
        '---------------------------
        Dim CMDUbah As MySqlCommand = CN.CreateCommand
        If txtKode.Text <> "" Then
            Try
                Dim Sql As String = "UPDATE foto_tb SET judul=@judul, pengarang=@pengarang, "
                Sql &= "penerbit=@penerbit, foto=@foto WHERE kode_buku=@kode_buku;"

                With CMDUbah
                    .CommandText = Sql
                    .Connection = CN
                    '------------------------------------------------------------------------
                    'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                    '------------------------------------------------------------------------                    
                    .Parameters.Add("@kode_buku", MySqlDbType.String, 10).Value = txtKode.Text
                    .Parameters.Add("@judul", MySqlDbType.TinyText).Value = txtJudul.Text
                    .Parameters.Add("@pengarang", MySqlDbType.VarChar, 30).Value = txtPengarang.Text
                    .Parameters.Add("@penerbit", MySqlDbType.VarChar, 30).Value = txtPenerbit.Text
                    .Parameters.Add("@foto", MySqlDbType.Blob).Value = rawData
                    '----------------------------
                    'Mengeksekusi Query dia atas
                    '----------------------------
                    .ExecuteNonQuery()
                End With

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()
            Catch ex As MySqlException
                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CMDUbah.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-------------------------------
        'memanggil method Insert_Foto()
        '-------------------------------
        Insert_Foto()

        '---------------------------
        'Deklarasi object command
        '---------------------------
        Dim CMDDelete As MySqlCommand = CN.CreateCommand

        If txtKode.Text <> "" Then
            If MessageBox.Show("Anda yakin data buku dengan kode " & txtKode.Text & " akan dihapus?", "Peringatan!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                Try
                    Dim Sql As String = "DELETE FROM foto_tb "
                    Sql &= "WHERE kode_buku=@kode_buku;"
                    With CMDDelete
                        .CommandText = Sql
                        .Parameters.Add("@kode_buku", MySqlDbType.String, 10).Value = txtKode.Text
                        .ExecuteNonQuery()
                    End With
                    '-----------------------------------------------------
                    'memanggil method ClearForm() untuk membersihkan Form
                    '-----------------------------------------------------
                    ClearForm()
                Catch ex As MySqlException
                    MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    CMDDelete.Dispose()
                    CN.Close()
                    CN = Nothing
                End Try
            End If
        End If
    End Sub

    Private Sub TampilData()
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim DataReader As MySqlDataReader = Nothing
        Dim CMDTampilData As MySqlCommand = CN.CreateCommand()
        Try
            If txtKode.Text <> "" Then
                '-------------------------------------------------------------
                'menampilkan data saat cursor keyboard keluar dari txtKode
                '-------------------------------------------------------------
                Dim Sql As String = "SELECT * FROM foto_tb WHERE kode_buku=@kode_buku"
                CMDTampilData.Parameters.Add("@kode_buku", MySqlDbType.String, 10).Value = txtKode.Text
                CMDTampilData.CommandText = Sql
                DataReader = CMDTampilData.ExecuteReader()

                If DataReader.Read() Then
                    txtKode.Text = DataReader("kode_buku").ToString
                    txtJudul.Text = DataReader("judul").ToString
                    txtPengarang.Text = DataReader("pengarang").ToString
                    txtPenerbit.Text = DataReader("penerbit").ToString

                    '-------------------------------------------------------
                    'pengecekan apakah data foto tersedia.
                    'jika ada, maka data dikonversi dari BLOB menjadi image
                    'untuk ditampilkan pada object PictureBox1
                    '-------------------------------------------------------
                    If DataReader("foto") IsNot DBNull.Value Then
                        Dim imageBytes() As Byte = Nothing
                        imageBytes = CType(DataReader("foto"), Byte())
                        Dim ms As New MemoryStream(imageBytes)
                        Dim bmap As New Bitmap(ms)
                        PictureBox1.Image = CType(bmap, Image)
                        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
                    End If
                    btnSimpan.Enabled = False
                    btnUbah.Enabled = True
                    btnHapus.Enabled = True
                Else
                    btnSimpan.Enabled = True
                    btnUbah.Enabled = False
                    btnHapus.Enabled = False
                End If
            End If

        Catch ex As MySqlException
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            '-----------------------------------------------
            'membebaskan semua resource yang telah terpakai
            '-----------------------------------------------            
            CMDTampilData.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub txtKode_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtKode.Leave
        TampilData()
    End Sub

    Private Sub btnCariFoto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariFoto.Click
        '-----------------------------------------------------
        'method yang terjadi saat button btn_Loadfoto di klik
        '-----------------------------------------------------
        Dim dlgFile As OpenFileDialog
        PictureBox1.Image = Nothing

        '--------------------------------------------------------------------------
        'OpenDialog yang mencari file image dengan extension yang telah ditentukan
        '--------------------------------------------------------------------------
        Try
            dlgFile = New OpenFileDialog
            dlgFile.Filter = "JPEG Images (*.jpg,*.jpeg)|*.jpg;*.jpeg|GIF Images (*.gif)|*.gif|Bitmaps (*.bmp)|*.bmp"
            dlgFile.FilterIndex = 1 'file extension yang ditampilkan pertama adalah .jpg
            PictureBox1.Visible = True
            If dlgFile.ShowDialog = Windows.Forms.DialogResult.OK Then
                strImgName = dlgFile.FileName
                PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
                PictureBox1.Image = Image.FromFile(strImgName)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnBersih_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBersih.Click
        ClearForm()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        Dim fb As frmBrowse = New frmBrowse
        fb.Show()
    End Sub

    Private Sub txtKode_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtKode.DragDrop
        txtKode.Text = e.Data.GetData(DataFormats.Text)
        TampilData()
    End Sub

    Private Sub txtKode_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtKode.DragEnter
        If (e.Data.GetDataPresent(DataFormats.Text)) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub
End Class
