<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBrowse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rdJudul = New System.Windows.Forms.RadioButton
        Me.rdPengarang = New System.Windows.Forms.RadioButton
        Me.rdPenerbit = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnCari = New System.Windows.Forms.Button
        Me.txtCari = New System.Windows.Forms.TextBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'rdJudul
        '
        Me.rdJudul.AutoSize = True
        Me.rdJudul.Location = New System.Drawing.Point(6, 19)
        Me.rdJudul.Name = "rdJudul"
        Me.rdJudul.Size = New System.Drawing.Size(78, 17)
        Me.rdJudul.TabIndex = 0
        Me.rdJudul.TabStop = True
        Me.rdJudul.Text = "Judul Buku"
        Me.rdJudul.UseVisualStyleBackColor = True
        '
        'rdPengarang
        '
        Me.rdPengarang.AutoSize = True
        Me.rdPengarang.Location = New System.Drawing.Point(90, 19)
        Me.rdPengarang.Name = "rdPengarang"
        Me.rdPengarang.Size = New System.Drawing.Size(77, 17)
        Me.rdPengarang.TabIndex = 1
        Me.rdPengarang.TabStop = True
        Me.rdPengarang.Text = "Pengarang"
        Me.rdPengarang.UseVisualStyleBackColor = True
        '
        'rdPenerbit
        '
        Me.rdPenerbit.AutoSize = True
        Me.rdPenerbit.Location = New System.Drawing.Point(173, 19)
        Me.rdPenerbit.Name = "rdPenerbit"
        Me.rdPenerbit.Size = New System.Drawing.Size(64, 17)
        Me.rdPenerbit.TabIndex = 2
        Me.rdPenerbit.TabStop = True
        Me.rdPenerbit.Text = "Penerbit"
        Me.rdPenerbit.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnCari)
        Me.GroupBox1.Controls.Add(Me.txtCari)
        Me.GroupBox1.Controls.Add(Me.rdJudul)
        Me.GroupBox1.Controls.Add(Me.rdPenerbit)
        Me.GroupBox1.Controls.Add(Me.rdPengarang)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(350, 74)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'btnCari
        '
        Me.btnCari.Location = New System.Drawing.Point(243, 37)
        Me.btnCari.Name = "btnCari"
        Me.btnCari.Size = New System.Drawing.Size(52, 27)
        Me.btnCari.TabIndex = 4
        Me.btnCari.Text = "Browse"
        Me.btnCari.UseVisualStyleBackColor = True
        '
        'txtCari
        '
        Me.txtCari.Location = New System.Drawing.Point(6, 42)
        Me.txtCari.Name = "txtCari"
        Me.txtCari.Size = New System.Drawing.Size(231, 20)
        Me.txtCari.TabIndex = 3
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(350, 96)
        Me.DataGridView1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(377, 82)
        Me.Panel1.TabIndex = 4
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Location = New System.Drawing.Point(12, 100)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(377, 106)
        Me.Panel2.TabIndex = 5
        '
        'frmBrowse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(398, 216)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmBrowse"
        Me.Text = "frmBrowse"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCari As System.Windows.Forms.Button
    Friend WithEvents txtCari As System.Windows.Forms.TextBox
    Friend WithEvents rdJudul As System.Windows.Forms.RadioButton
    Friend WithEvents rdPenerbit As System.Windows.Forms.RadioButton
    Friend WithEvents rdPengarang As System.Windows.Forms.RadioButton
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
