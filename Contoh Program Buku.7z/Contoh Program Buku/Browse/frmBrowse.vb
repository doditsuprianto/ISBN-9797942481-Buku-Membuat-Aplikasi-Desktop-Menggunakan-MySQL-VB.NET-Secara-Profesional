Public Class frmBrowse

    Private MouseIsDown As Boolean = False
    'Deklarasi variable object adapter reader
    Private MyAdapter As New MySqlDataAdapter()
    'Deklarasi variable object dataset
    Private MyDataset As New DataSet()
    'Deklarasi variable object Connection ke MySQl
    Private CN As New MySqlConnection

    Private Sub frmBrowse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Pencarian Buku"
        Panel1.Dock = DockStyle.Top
        Panel2.Dock = DockStyle.Fill
        GroupBox1.Text = "Dasar Pencarian"
        GroupBox1.Dock = DockStyle.Fill
        DataGridView1.Dock = DockStyle.Fill
        DataGridView1.ReadOnly = True
    End Sub

    Private Sub btnCari_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCari.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim CMDCariBuku As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            Dim StrSQL As String = ""

            If rdJudul.Checked = True Then StrSQL = "CALL BROWSE_FOTO_SP('JUDUL', @CARI)"
            If rdPengarang.Checked = True Then StrSQL = "CALL BROWSE_FOTO_SP('PENGARANG', @CARI)"
            If rdPenerbit.Checked = True Then StrSQL = "CALL BROWSE_FOTO_SP('PENERBIT', @CARI)"

            CMDCariBuku.CommandText = StrSQL
            CMDCariBuku.Parameters.Add("@CARI", MySqlDbType.VarChar).Value = txtCari.Text
            MyAdapter.SelectCommand = CMDCariBuku
            MyAdapter.Fill(MyDataset, "foto_tb")
            DataGridView1.DataSource = MyDataset
            DataGridView1.DataMember = "foto_tb"
            'Lebar kolom Judul 
            DataGridView1.Columns(1).Width = 250
            'Lebar kolom Pengarang
            DataGridView1.Columns(2).Width = 250
            'Lebar kolom Penerbit
            DataGridView1.Columns(3).Width = 250
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariBuku.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub DataGridView1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub DataGridView1_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseMove
        If MouseIsDown Then
            DataGridView1.DoDragDrop(DataGridView1.Item(0, DataGridView1.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub
End Class