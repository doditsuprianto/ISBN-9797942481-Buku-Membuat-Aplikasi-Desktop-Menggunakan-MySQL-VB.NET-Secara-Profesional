Imports System.Globalization

Public Class frmOneToMany

    Private ds As DataSet = New DataSet
    Private CN As New MySqlConnection

    Private Sub frmOneToMany_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel1.Dock = DockStyle.Top
        Panel2.Dock = DockStyle.Bottom
        DataGridView1.Dock = DockStyle.Fill
        DataGridView1.BorderStyle = BorderStyle.None
        Me.Text = "Form Onte To Many"
        ClearForm()
    End Sub

    Private Sub ClearForm()
        '--------------------------------------
        ' Membersihkan nilai yang masih ada 
        ' pada object form dengan string kosong
        '--------------------------------------
        txtNota.Text = ""
        dtTanggal.Value = Now
        ds.Clear()
        '---------------------------------------
        ' Menempatkan cursor keyboard ke txtNota
        '---------------------------------------
        txtNota.Focus()
    End Sub

    Private Sub btnBersih_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBersih.Click
        '-----------------------------
        'memanggil method ClearForm()
        '-----------------------------
        ClearForm()

        '------------------------------------------------
        'mengaktifkan Button btnSimpan, btnUbah, btnHapus
        '------------------------------------------------
        btnSimpan.Enabled = True
        btnUbah.Enabled = True
        btnHapus.Enabled = True
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        If txtNota.Text <> "" Then
            Try
                With CMDInsert
                    Dim Detil As String = ""
                    Dim Baris, TotBaris As Integer
                    TotBaris = DataGridView1.RowCount - 2
                    Detil = ""
                    'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                    'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                    'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                    'pada kolomnya masing-masing pada table penjualan_detil_tb
                    For Baris = 0 To TotBaris
                        Detil &= DataGridView1.Item(0, Baris).Value.ToString & Chr(21) & DataGridView1.Item(5, Baris).Value.ToString & Chr(21) & DataGridView1.Item(6, Baris).Value.ToString & Chr(21)
                    Next

                    'pemanggilan PENJUALAN_SP sekaligus memasukkan nilai-nilai parameternya
                    Dim SQLD As String = "CALL DEMO_PENJUALAN_SP ('INSERT', @no_nota, @tgl_jual, @detil); "
                    .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txtNota.Text
                    .Parameters.Add("@tgl_jual", MySqlDbType.Date).Value = dtTanggal.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                    .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                    .CommandText = SQLD
                    .Transaction = SQLTrans
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()

            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDInsert.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub btnUbah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUbah.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDUpdate As MySqlCommand = CN.CreateCommand

        If txtnota.Text <> "" Then
            Try
                With CMDUpdate
                    Dim Detil As String = ""
                    Dim Baris, TotBaris As Integer
                    TotBaris = DataGridView1.RowCount - 2
                    Detil = ""
                    'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                    'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                    'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                    'pada kolomnya masing-masing pada table penjualan_detil_tb
                    For Baris = 0 To TotBaris
                        Detil &= DataGridView1.Item(0, Baris).Value.ToString & Chr(21) & DataGridView1.Item(5, Baris).Value.ToString & Chr(21) & DataGridView1.Item(6, Baris).Value.ToString & Chr(21)
                    Next

                    'pemanggilan PENJUALAN_SP sekaligus memasukkan nilai-nilai parameternya
                    Dim SQLD As String = "CALL DEMO_PENJUALAN_SP ('UPDATE', @no_nota, @tgl_jual, @detil); "
                    .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txtNota.Text
                    .Parameters.Add("@tgl_jual", MySqlDbType.Date).Value = dtTanggal.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                    .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                    .CommandText = SQLD
                    .Transaction = SQLTrans
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()
            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDUpdate.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDDelete As MySqlCommand = CN.CreateCommand

        If txtNota.Text <> "" Then
            If MessageBox.Show("Anda yakin data penjualan dengan no nota: " & txtNota.Text & " akan dihapus?", "Peringatan!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                Try
                    With CMDDelete
                        Dim Detil As String = ""
                        Dim Baris, TotBaris As Integer
                        TotBaris = DataGridView1.RowCount - 2
                        Detil = ""
                        'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                        'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                        'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                        'pada kolomnya masing-masing di table penjualan_detil_tb
                        For Baris = 0 To TotBaris
                            Detil &= DataGridView1.Item(0, Baris).Value.ToString & Chr(21) & DataGridView1.Item(5, Baris).Value.ToString & Chr(21) & DataGridView1.Item(6, Baris).Value.ToString & Chr(21)
                        Next

                        'pemanggilan PENJUALAN_SP sekaligus memasukkan nilai-nilai parameternya
                        Dim SQLD As String = "CALL DEMO_PENJUALAN_SP ('DELETE', @no_nota, @tgl_jual, @detil); "
                        .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txtNota.Text
                        .Parameters.Add("@tgl_jual", MySqlDbType.Date).Value = dtTanggal.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                        .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                        .CommandText = SQLD
                        .Transaction = SQLTrans
                        .ExecuteNonQuery()
                    End With

                    '---------------------------------------------------------
                    'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                    'melalui perintah COMMIT transaction
                    '---------------------------------------------------------
                    SQLTrans.Commit()
                    ClearForm()
                Catch ex As MySqlException
                    '-------------------------------------------------
                    'Jika terjadi kegagalan, maka eksekusi dibatalkan
                    'melalui perintah ROLLBACK transaction
                    '-------------------------------------------------
                    SQLTrans.Rollback()
                    MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    SQLTrans.Dispose()
                    CMDDelete.Dispose()
                    CN.Close()
                    CN = Nothing
                End Try
            End If
        Else
            MessageBox.Show("No Nota belum terisi!")
        End If
    End Sub

    Private Sub TampilDetil()
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDTampil As MySqlCommand = CN.CreateCommand

        If txtNota.Text <> "" Then
            Try
                CMDTampil.CommandText = "select * from tampil_jual_vw where nota_jual = @nota_jual"
                CMDTampil.Parameters.Add("@nota_jual", MySqlDbType.VarChar, 10).Value = txtNota.Text

                Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDTampil)

                ds.Clear()
                daTampil.Fill(ds, "tampil_jual_vw")
                Dim dtTampil As DataTable = ds.Tables("tampil_jual_vw")

                If dtTampil.Rows.Count > 0 Then
                    dtTanggal.Value = dtTampil.Rows(0).ItemArray(9)
                    btnSimpan.Enabled = False
                    btnUbah.Enabled = True
                    btnHapus.Enabled = True
                Else
                    btnSimpan.Enabled = True
                    btnUbah.Enabled = False
                    btnHapus.Enabled = False
                End If

                With DataGridView1
                    .DataSource = ds
                    .DataMember = "tampil_jual_vw"
                    'bagian ini mengubah atribut datagridview
                    'Lebar kolom Judul Buku
                    .Columns("Judul Buku").Width = 240
                    'kolom judul buku hanya dapat dibaca
                    .Columns("Judul Buku").ReadOnly = True
                    'Kolom kode sampai judul buku dihentikan saat scroll
                    .Columns("Judul Buku").Frozen = True
                    'kolom penerbit hanya dapat dibaca
                    .Columns("Penerbit").ReadOnly = True
                    .Columns("Penerbit").Width = 120
                    'kolom penulis hanya dapat dibaca
                    .Columns("Penulis").ReadOnly = True
                    .Columns("Penulis").Width = 120
                    'kolom kelompok hanya dapat dibaca
                    .Columns("Kelompok").ReadOnly = True
                    .Columns("Kelompok").Width = 120
                    'Format Angka
                    .Columns("Harga").DefaultCellStyle.Format = "N"
                    .Columns("Harga").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Harga").Width = 100
                    .Columns("Jumlah").DefaultCellStyle.Format = "N"
                    .Columns("Jumlah").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Jumlah").Width = 70
                    .Columns("Sub Total").DefaultCellStyle.Format = "N"
                    .Columns("Sub Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Sub Total").DefaultCellStyle.ForeColor = Color.Black
                    .Columns("Sub Total").DefaultCellStyle.BackColor = Color.Yellow
                    'kolom sub total hanya dapat dibaca
                    .Columns("Sub Total").ReadOnly = True
                    'Menyembunyikan kolom nota jual
                    .Columns("nota_jual").Visible = False
                    'Menyembunyikan kolom tanggal jual
                    .Columns("tgl_jual").Visible = False
                    Dim font As New Font(.DefaultCellStyle.Font.FontFamily, 9, FontStyle.Bold)
                    Try
                        'mengubah atribut font kolom ke-7 (sub total)
                        .Columns("Sub Total").DefaultCellStyle.Font = font
                        .ColumnHeadersDefaultCellStyle.Font = font
                    Finally
                        font.Dispose()
                    End Try
                End With
                '---------------------------
                'menampilkan penjualan total
                '---------------------------
                HitungTotal()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                CMDTampil.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub txtNota_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNota.Leave
        TampilDetil()
    End Sub

    Private Sub HitungTotal()
        '-------------------------------------------------------------------
        'Menghitung nilai total, yang diperoleh dari sub total (kolom ke-7).
        'Kolom sub total diperoleh dari perkalian kolom harga dan jumlah.
        '-------------------------------------------------------------------
        Dim i As Integer
        Dim total As Double
        total = 0
        For i = 0 To DataGridView1.RowCount - 1
            total += DataGridView1.Item(7, i).Value
        Next
        '-----------------------------------------------------
        'melimpahkan nilai total ke label lblTotal,
        'sekaligus mem-format-nya ke tipe mata uang (Currency)
        '-----------------------------------------------------
        lblTotal.Text = "TOTAL : " & Format(total, "C")
    End Sub

    Private Sub DataGridView1_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        Dim myConnectionString = "Database=dbpenjualanbuku;Data Source=localhost;User Id=root;Password="
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Try
            Select Case DataGridView1.CurrentCell.ColumnIndex 'pilihan cell yang sedang di-edit
                Case 0
                    Dim CMDItemBuku As MySqlCommand = CN.CreateCommand
                    Dim Sql = "SELECT * FROM TAMPIL_ITEM_BUKU_VW WHERE kode_buku = @KodeBuku;"
                    CMDItemBuku.Parameters.Add("@KodeBuku", MySqlDbType.VarChar, 13).Value = DataGridView1.CurrentCell.Value
                    CMDItemBuku.CommandText = Sql

                    'menampilkan semua data dimana kode buku = cell kolom ke-0
                    'dari baris yang terpilih saat ini
                    Dim dr As MySqlDataReader = CMDItemBuku.ExecuteReader
                    If dr.Read Then
                        With DataGridView1.CurrentRow
                            .Cells(1).Value = dr.GetString("judul")
                            .Cells(2).Value = dr.GetString("nama_penerbit")
                            .Cells(3).Value = dr.GetString("nama_penulis")
                            .Cells(4).Value = dr.GetString("nama_kelompok")
                            .Cells(5).Value = dr.GetDouble("harga_jual")
                        End With
                    End If
                    dr.Close()
                Case 5
                    With DataGridView1.CurrentRow
                        'jika harga jual atau jumlah masih kosong,
                        'maka kolom harga jual dan jumlah diisi nilai 0
                        If IsDBNull(.Cells(5).Value) Then .Cells(5).Value = 0
                        If IsDBNull(.Cells(6).Value) Then .Cells(6).Value = 0

                        'mencari nilai sub total, 
                        'perkalian antara harga jual dan jumlah
                        .Cells(7).Value = .Cells(5).Value * .Cells(6).Value
                    End With
                    HitungTotal()
                Case 6
                    With DataGridView1.CurrentRow
                        'jika harga jual atau jumlah masih kosong,
                        'maka kolom harga jual dan jumlah diisi nilai 0
                        If IsDBNull(.Cells(5).Value) Then .Cells(5).Value = 0
                        If IsDBNull(.Cells(6).Value) Then .Cells(6).Value = 0

                        'mencari nilai sub total,
                        'perkalian antara harga jual dan jumlah
                        .Cells(7).Value = .Cells(5).Value * .Cells(6).Value
                    End With
                    HitungTotal()
            End Select

        Catch ex As Exception
            '----------------------------------------------------
            'Pesan kesalahan ditampilkan melalui MessageBox.Show
            '----------------------------------------------------
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub
End Class
