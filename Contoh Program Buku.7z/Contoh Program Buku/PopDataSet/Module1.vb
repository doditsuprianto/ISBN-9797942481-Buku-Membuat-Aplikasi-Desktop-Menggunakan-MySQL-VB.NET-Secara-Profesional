Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd


        'set up query
        Dim sql As String
        sql = "select judul, harga_jual as 'Harga' "
        sql = sql & "from buku_tb "
        sql = sql & "where harga_jual < 35000"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dataset
            Dim ds As DataSet = New DataSet()

            'mengisi dataset
            da.Fill(ds, "buku_tb")

            'Memperoleh data table
            Dim dt As DataTable = ds.Tables("buku_tb")

            'mengulang isi data table
            For Each baris As DataRow In dt.Rows
                For Each kolom As DataColumn In dt.Columns
                    Console.WriteLine(baris(kolom))
                Next
                Console.WriteLine("".PadLeft(50, "="))
            Next
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
