Public Class frmMDI

    Private Sub frmMDI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Menjadikan frmMDI full screen
        Me.WindowState = FormWindowState.Maximized
        'Form berlaku sebagai MDI (form parent)
        Me.IsMdiContainer = True
        'Judul form
        Me.Text = "Demo Form MDI"
        'Mengaktifkan tanggal dan waktu
        Me.Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'Status label index ke-0 tanggal dan waktu
        Me.StatusStrip1.Items(0).Text = Now()
    End Sub

    Private Sub Form2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Form2ToolStripMenuItem.Click
        'Pemanggilan form anak frmAnak.vb dari form MDI
        Dim fAnak As frmAnak = New frmAnak
        fAnak.MdiParent = Me
        fAnak.Show()
    End Sub
End Class
