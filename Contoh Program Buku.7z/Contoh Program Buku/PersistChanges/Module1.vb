Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query
        Dim sql As String = "select * from penerbit_tb;"

        'set up DML
        Dim upd As String
        upd = "update penerbit_tb set website = @website "
        upd &= "where kode_penerbit = @kode_penerbit;"

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dan mengisi dataset
            Dim ds As DataSet = New DataSet()
            da.Fill(ds, "penerbit_tb")

            'mendapatkan referensi table
            Dim dt As DataTable = ds.Tables("penerbit_tb")

            'memodifikasi kolom website di baris kedua
            dt.Rows(1)("website") = "www.oasemedia.com"

            'menampilkan baris-baris di dalam data table
            For Each row As DataRow In dt.Rows
                Console.WriteLine("{0} {1} {2}", _
                row("kode_penerbit").ToString().PadRight(10), _
                row("nama_penerbit").ToString().PadLeft(30), _
                row("website"))
            Next

            'Update penerbit_tb di data source
            '
            'menciptakan command
            Dim cmd As MySqlCommand = New MySqlCommand(upd, conn)
            '
            'memetakan parameter
            '
            'Website
            cmd.Parameters.Add("@website", MySqlDbType.TinyText, 100, "website")
            '
            'kode_penerbit
            Dim parm As MySqlParameter = cmd.Parameters.Add("@kode_penerbit", _
            MySqlDbType.VarChar, 10, "kode_penerbit")
            parm.SourceVersion = DataRowVersion.Original
            '
            'Update database
            da.UpdateCommand = cmd
            da.Update(ds, "penerbit_tb")
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
