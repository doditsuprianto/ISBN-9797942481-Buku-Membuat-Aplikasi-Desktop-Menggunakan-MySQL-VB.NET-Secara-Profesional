Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'menciptakan string query
        Dim SQL As String = "select count(*) from buku_tb"

        'menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        'menciptakan command
        Dim CMD As MySqlCommand = New MySqlCommand(SQL, conn)
        Console.WriteLine("Command telah tercipta.")

        Try
            'membuka connection
            conn.Open()

            Dim jumlah As Integer
            'eksekusi query
            jumlah = CType(CMD.ExecuteScalar, Integer)
            Console.WriteLine("Jumlah buku: " & jumlah)
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
            Console.WriteLine("Koneksi ditutup")
        End Try

    End Sub

End Module
