Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query pertama
        Dim sql1 As String = "select * from buku_tb; "

        'set up query kedua
        Dim sql2 As String = "select * from penulis_tb where nama_penulis like 'B%'; "

        'kombinasi query
        Dim sql As String = sql1 & sql2

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dataset
            Dim ds As DataSet = New DataSet()
            'mengisi dataset
            da.Fill(ds, "buku_tb")

            'mendapatkan data tables collection
            Dim dtc As DataTableCollection = ds.Tables

            'menampilkan data dari table pertama
            'menampilkan header
            Console.WriteLine("Hasil dari table buku_tb:")
            Console.WriteLine("Judul".PadRight(50) & "Harga".PadLeft(6))

            'atur penyaringan data
            Dim fl As String = "harga_jual <= 30000"

            'atur pengurutan
            Dim srt As String = "judul desc"
            '
            'tampilkan data yang sudah tersaring dan terurut
            For Each row As DataRow In dtc("buku_tb").Select(fl, srt)
                Console.WriteLine("{0} {1}", row("judul").ToString().PadRight(50), _
                row("harga_jual"))
            Next

            'tampilkan data dari table kedua
            '
            'tampilkan header
            Console.WriteLine("---------------------------------------------------------")
            Console.WriteLine("Hasil dari table penulis_tb:")
            Console.WriteLine("Kode Penulis".PadRight(15) & "Nama Penulis")
            '
            ' Display data
            For Each row As DataRow In dtc("buku_tb1").Rows
                Console.WriteLine("{0} {1}", row("kode_penulis").ToString().PadRight(15), _
                row("nama_penulis"))
            Next
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
