Imports MySql.Data.MySqlClient

Module Module1

    Sub Main()
        Dim connString, db, user, pwd As String

        db = "dbpenjualanbuku" 'database
        user = "root" 'user default
        pwd = "" 'password kosong
        connString = "Database=" & db & ";Data Source=localhost;User Id=" & user & ";Password=" & pwd

        'set up query pertama
        Dim sql As String = "select kode_buku, judul, harga_jual from buku_tb; "

        'Menciptakan connection
        Dim conn As MySqlConnection = New MySqlConnection(connString)

        Try
            'membuka connection
            conn.Open()

            'menciptakan data adapter
            Dim da As MySqlDataAdapter = New MySqlDataAdapter(sql, conn)

            'menciptakan dataset
            Dim ds As DataSet = New DataSet()
            'mengisi dataset
            da.Fill(ds, "buku_tb")

            'mendapatkan rujukan ke data table
            Dim dt As DataTable = ds.Tables("buku_tb")

            'menciptakan data view
            Dim dv As DataView = New DataView(dt, "harga_jual < 30000", _
            "judul desc", DataViewRowState.CurrentRows)

            'menampilkan data dari data view
            For Each drv As DataRowView In dv
                'For i As Integer = 0 To dv.Table.Columns.Count - 1
                'Console.Write(drv(i).ToString().PadRight(30))
                'Next
                Console.WriteLine("{0}{1}{2}", drv(0).ToString().PadRight(15), drv(1).ToString().PadRight(50), drv(2))
                'Console.Write(drv(0).ToString().PadRight(15))
                'Console.Write(drv(1).ToString().PadRight(50))
                'Console.Write(drv(2))
                'Console.WriteLine()
            Next
        Catch ex As Exception
            'menampilkan pesan kesalahan
            Console.WriteLine("Error: " & ex.ToString)
        Finally
            'menutup connection
            conn.Close()
        End Try

    End Sub

End Module
