<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMDI
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.KelompokBukuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator
        Me.MasterPenulisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MasterPenerbitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator
        Me.MasterSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransaksiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransaksiPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransaksiReturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripSeparator
        Me.PosisiStokToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StokAwalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InputkanStokAwalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LaporanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LaporanMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator
        Me.LaporanPenjualanToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LaporanPembelianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LaporanReturToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 348)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(581, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.TransaksiToolStripMenuItem, Me.LaporanToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(581, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterBukuToolStripMenuItem, Me.ToolStripMenuItem1, Me.KelompokBukuToolStripMenuItem, Me.ToolStripMenuItem2, Me.MasterPenulisToolStripMenuItem, Me.MasterPenerbitToolStripMenuItem, Me.ToolStripMenuItem3, Me.MasterSupplierToolStripMenuItem})
        Me.FileToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._451
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'MasterBukuToolStripMenuItem
        '
        Me.MasterBukuToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._17
        Me.MasterBukuToolStripMenuItem.Name = "MasterBukuToolStripMenuItem"
        Me.MasterBukuToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.MasterBukuToolStripMenuItem.Text = "Master Buku"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(155, 6)
        '
        'KelompokBukuToolStripMenuItem
        '
        Me.KelompokBukuToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._46
        Me.KelompokBukuToolStripMenuItem.Name = "KelompokBukuToolStripMenuItem"
        Me.KelompokBukuToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.KelompokBukuToolStripMenuItem.Text = "Kelompok Buku"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(155, 6)
        '
        'MasterPenulisToolStripMenuItem
        '
        Me.MasterPenulisToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._06
        Me.MasterPenulisToolStripMenuItem.Name = "MasterPenulisToolStripMenuItem"
        Me.MasterPenulisToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.MasterPenulisToolStripMenuItem.Text = "Master Penulis"
        '
        'MasterPenerbitToolStripMenuItem
        '
        Me.MasterPenerbitToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._122
        Me.MasterPenerbitToolStripMenuItem.Name = "MasterPenerbitToolStripMenuItem"
        Me.MasterPenerbitToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.MasterPenerbitToolStripMenuItem.Text = "Master Penerbit"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(155, 6)
        '
        'MasterSupplierToolStripMenuItem
        '
        Me.MasterSupplierToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._10
        Me.MasterSupplierToolStripMenuItem.Name = "MasterSupplierToolStripMenuItem"
        Me.MasterSupplierToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.MasterSupplierToolStripMenuItem.Text = "Master Supplier"
        '
        'TransaksiToolStripMenuItem
        '
        Me.TransaksiToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PenjualanToolStripMenuItem, Me.TransaksiPembelianToolStripMenuItem, Me.TransaksiReturToolStripMenuItem, Me.ToolStripMenuItem6, Me.PosisiStokToolStripMenuItem, Me.StokAwalToolStripMenuItem, Me.InputkanStokAwalToolStripMenuItem})
        Me.TransaksiToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._011
        Me.TransaksiToolStripMenuItem.Name = "TransaksiToolStripMenuItem"
        Me.TransaksiToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.TransaksiToolStripMenuItem.Text = "&Transaksi"
        '
        'PenjualanToolStripMenuItem
        '
        Me.PenjualanToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._02
        Me.PenjualanToolStripMenuItem.Name = "PenjualanToolStripMenuItem"
        Me.PenjualanToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.PenjualanToolStripMenuItem.Text = "Transaksi Penjualan"
        '
        'TransaksiPembelianToolStripMenuItem
        '
        Me.TransaksiPembelianToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._26
        Me.TransaksiPembelianToolStripMenuItem.Name = "TransaksiPembelianToolStripMenuItem"
        Me.TransaksiPembelianToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.TransaksiPembelianToolStripMenuItem.Text = "Transaksi Pembelian"
        '
        'TransaksiReturToolStripMenuItem
        '
        Me.TransaksiReturToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._181
        Me.TransaksiReturToolStripMenuItem.Name = "TransaksiReturToolStripMenuItem"
        Me.TransaksiReturToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.TransaksiReturToolStripMenuItem.Text = "Transaksi Retur"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(229, 6)
        '
        'PosisiStokToolStripMenuItem
        '
        Me.PosisiStokToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._463
        Me.PosisiStokToolStripMenuItem.Name = "PosisiStokToolStripMenuItem"
        Me.PosisiStokToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.PosisiStokToolStripMenuItem.Text = "Posisi Stok"
        '
        'StokAwalToolStripMenuItem
        '
        Me.StokAwalToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._182
        Me.StokAwalToolStripMenuItem.Name = "StokAwalToolStripMenuItem"
        Me.StokAwalToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.StokAwalToolStripMenuItem.Text = "Buat Stok Awal && Pindah Stok"
        '
        'InputkanStokAwalToolStripMenuItem
        '
        Me.InputkanStokAwalToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._371
        Me.InputkanStokAwalToolStripMenuItem.Name = "InputkanStokAwalToolStripMenuItem"
        Me.InputkanStokAwalToolStripMenuItem.Size = New System.Drawing.Size(232, 22)
        Me.InputkanStokAwalToolStripMenuItem.Text = "Inputkan Stok Awal"
        '
        'LaporanToolStripMenuItem
        '
        Me.LaporanToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LaporanMasterToolStripMenuItem, Me.ToolStripMenuItem4, Me.LaporanPenjualanToolStripMenuItem, Me.LaporanPembelianToolStripMenuItem, Me.LaporanReturToolStripMenuItem})
        Me.LaporanToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._12
        Me.LaporanToolStripMenuItem.Name = "LaporanToolStripMenuItem"
        Me.LaporanToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.LaporanToolStripMenuItem.Text = "&Laporan"
        '
        'LaporanMasterToolStripMenuItem
        '
        Me.LaporanMasterToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._11
        Me.LaporanMasterToolStripMenuItem.Name = "LaporanMasterToolStripMenuItem"
        Me.LaporanMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.LaporanMasterToolStripMenuItem.Text = "Laporan Master"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(173, 6)
        '
        'LaporanPenjualanToolStripMenuItem
        '
        Me.LaporanPenjualanToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._121
        Me.LaporanPenjualanToolStripMenuItem.Name = "LaporanPenjualanToolStripMenuItem"
        Me.LaporanPenjualanToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.LaporanPenjualanToolStripMenuItem.Text = "Laporan Penjualan"
        '
        'LaporanPembelianToolStripMenuItem
        '
        Me.LaporanPembelianToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._13
        Me.LaporanPembelianToolStripMenuItem.Name = "LaporanPembelianToolStripMenuItem"
        Me.LaporanPembelianToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.LaporanPembelianToolStripMenuItem.Text = "Laporan Pembelian"
        '
        'LaporanReturToolStripMenuItem
        '
        Me.LaporanReturToolStripMenuItem.Image = Global.PenjualanBuku.My.Resources.Resources._14
        Me.LaporanReturToolStripMenuItem.Name = "LaporanReturToolStripMenuItem"
        Me.LaporanReturToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.LaporanReturToolStripMenuItem.Text = "Laporan Retur"
        '
        'Timer1
        '
        '
        'frmMDI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 370)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMDI"
        Me.Text = "Program Penjualan Buku"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterBukuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents KelompokBukuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MasterPenulisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MasterPenerbitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MasterSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransaksiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransaksiPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransaksiReturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanPenjualanToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanPembelianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaporanReturToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents LaporanMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PosisiStokToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StokAwalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InputkanStokAwalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
