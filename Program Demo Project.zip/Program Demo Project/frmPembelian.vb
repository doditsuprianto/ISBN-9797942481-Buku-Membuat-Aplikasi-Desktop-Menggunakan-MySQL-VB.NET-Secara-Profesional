'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Imports System.Globalization

Public Class frmPembelian
    Private ds As DataSet = New DataSet

    Private Sub ts_first_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_first.MouseMove
        '---------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_first 
        'saat mouse mendekati icon ts_first pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi paling awal"
    End Sub

    Private Sub ts_prev_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_prev.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_prev 
        'saat mouse mendekati icon ts_prev pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi sebelumnya"
    End Sub

    Private Sub ts_next_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_next.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_next 
        'saat mouse mendekati icon ts_next pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi setelahnya"
    End Sub

    Private Sub ts_last_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_last.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_last 
        'saat mouse mendekati icon ts_last pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi paling akhir"
    End Sub

    Private Sub ts_first_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_first.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_first pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_prev_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles ts_prev.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_prev pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_next_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_next.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_next pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_last_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_last.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_last pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_addnew_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_addnew.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_addnew pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_addnew_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_addnew.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_addnew 
        'saat mouse mendekati icon ts_addnew pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menambahkan data buku baru"
    End Sub

    Private Sub ts_save_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_save.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_save pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_save_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_save.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_save 
        'saat mouse mendekati icon ts_save pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menyimpan data buku baru"
    End Sub

    Private Sub ts_update_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_update.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_update pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_update_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_update.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_update 
        'saat mouse mendekati icon ts_update pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Mengubah data buku yang sudah ada"
    End Sub

    Private Sub ts_delete_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_delete.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_delete pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_delete_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_delete.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_delete 
        'saat mouse mendekati icon ts_delete pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menghapus data buku yang sudah ada"
    End Sub

    Private Sub ts_print_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_print.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_print pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_print_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_print.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_print 
        'saat mouse mendekati icon ts_print pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Fasilitas pelaporan yang berhubungan dengan data buku"
    End Sub

    Private Sub ts_browse_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_browse.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_browse pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_browse_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_browse.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_browse 
        'saat mouse mendekati icon ts_browse pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Mencari data dengan fasilitas browsing data grid"
    End Sub

    Private Sub ts_addnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_addnew.Click
        '-----------------------------
        'memanggil method ClearForm()
        '-----------------------------
        ClearForm()

        '------------------------------------------------
        'mengaktifkan icon ts_save, ts_update, ts_delete
        'dan label lbl_Save, lbl_Update, lbl_Delete
        '------------------------------------------------
        ts_save.Enabled = True
        ts_update.Enabled = True
        ts_delete.Enabled = True
        lbl_Save.Enabled = True
        lbl_Update.Enabled = True
        lbl_Delete.Enabled = True
    End Sub

    Private Sub ClearForm()
        '------------------------------------------------------
        'Membersihkan nilai yang masih ada pada object form
        'dengan string kosong dan image picture di set nothing
        '------------------------------------------------------
        txt_nonota.Text = ""
        dt_tglbeli.Value = Now
        txt_KdSupplier.Text = ""
        txt_NamaSupplier.Text = ""
        ds.Clear()

        '-------------------------------------------
        'Menempatkan cursor keyboard ke txt_nonota
        '-------------------------------------------
        txt_nonota.Focus()
    End Sub

    Private Sub ts_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_save.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        If txt_nonota.Text <> "" Then
            Try
                With CMDInsert
                    Dim Detil As String = ""
                    Dim Baris, TotBaris As Integer
                    TotBaris = dgv_beli.RowCount - 2
                    Detil = ""
                    'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                    'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                    'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                    'pada kolomnya masing-masing table penjualan_detil_tb
                    For Baris = 0 To TotBaris
                        Detil &= dgv_beli.Item(0, Baris).Value.ToString & Chr(21) & dgv_beli.Item(5, Baris).Value.ToString & Chr(21) & dgv_beli.Item(6, Baris).Value.ToString & Chr(21)
                    Next

                    'pemanggilan PEMBELIAN_SP sekaligus memasukkan nilai-nilai parameternya
                    SQL = "CALL PEMBELIAN_SP ('INSERT', @no_nota, @tgl_beli, @kd_supplier, @detil); "
                    .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txt_nonota.Text
                    .Parameters.Add("@tgl_beli", MySqlDbType.Date).Value = dt_tglbeli.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                    .Parameters.Add("@kd_supplier", MySqlDbType.VarChar, 10).Value = txt_KdSupplier.Text
                    .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                    .CommandText = SQL
                    .Transaction = SQLTrans
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()

            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDInsert.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub Tampil_Data_Beli()
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDTampil As MySqlCommand = CN.CreateCommand

        If txt_nonota.Text <> "" Then
            Try
                CMDTampil.CommandText = "select * from TAMPIL_BELI_VW where nota_beli = @nota_beli"
                CMDTampil.Parameters.Add("@nota_beli", MySqlDbType.VarChar, 10).Value = txt_nonota.Text

                Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDTampil)

                ds.Clear()
                daTampil.Fill(ds, "TAMPIL_BELI_VW")
                Dim dtTampil As DataTable = ds.Tables("TAMPIL_BELI_VW")

                'menampilkan tanggal, baris ke-0 kolom ke-9
                If dtTampil.Rows.Count > 0 Then
                    dt_tglbeli.Value = dtTampil.Rows(0).ItemArray(9) 'menampilkan tanggal beli
                    txt_KdSupplier.Text = dtTampil.Rows(0).ItemArray(10) 'menampilkan kode seupplier
                    txt_NamaSupplier.Text = dtTampil.Rows(0).ItemArray(11) 'menampilkan nama supplier

                    ts_save.Enabled = False
                    lbl_Save.Enabled = False
                    ts_update.Enabled = True
                    lbl_Update.Enabled = True
                    ts_delete.Enabled = True
                    lbl_Delete.Enabled = True
                Else
                    ts_save.Enabled = True
                    lbl_Save.Enabled = True
                    ts_update.Enabled = False
                    lbl_Update.Enabled = False
                    ts_delete.Enabled = False
                    lbl_Delete.Enabled = False
                End If

                With dgv_beli
                    .DataSource = ds
                    .DataMember = "TAMPIL_BELI_VW"

                    'bagian ini mengubah atribut datagridview
                    .Columns("Judul Buku").Width = 260 'Lebar kolom Judul Buku 
                    .Columns("Judul Buku").ReadOnly = True 'kolom judul buku hanya dapat dibaca
                    .Columns("Judul Buku").Frozen = True 'Kolom kode sampai kolom judul buku dihentikan saat scroll

                    .Columns("Penerbit").ReadOnly = True 'kolom penerbit hanya dapat dibaca
                    .Columns("Penerbit").Width = 120

                    .Columns("Penulis").ReadOnly = True 'kolom penulis hanya dapat dibaca
                    .Columns("Penulis").Width = 120

                    .Columns("Kelompok").ReadOnly = True 'kolom kelompok hanya dapat dibaca
                    .Columns("Kelompok").Width = 120

                    .Columns("Harga").DefaultCellStyle.Format = "N" 'Format mata uang
                    .Columns("Harga").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Harga").Width = 100

                    .Columns("Jumlah").DefaultCellStyle.Format = "N" 'Format Angka
                    .Columns("Jumlah").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Jumlah").Width = 70

                    .Columns("Sub Total").DefaultCellStyle.Format = "N" 'Format mata uang
                    .Columns("Sub Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Sub Total").DefaultCellStyle.ForeColor = Color.Black
                    .Columns("Sub Total").DefaultCellStyle.BackColor = Color.Yellow
                    .Columns("Sub Total").ReadOnly = True 'kolom sub total hanya dapat dibaca
                    .Columns("nota_beli").Visible = False 'Menyembunyikan kolom nota jual
                    .Columns("tgl_beli").Visible = False 'Menyembunyikan kolom tanggal jual
                    .Columns("kode_supplier").Visible = False 'Menyembunyikan kolom kode supplier
                    .Columns("nama_supplier").Visible = False 'Menyembunyikan kolom nama supplier

                    Dim font As New Font(.DefaultCellStyle.Font.FontFamily, 9, FontStyle.Bold)
                    Try
                        'mengubah atribut font kolom ke-7 (sub total)
                        .Columns("Sub Total").DefaultCellStyle.Font = font
                        .ColumnHeadersDefaultCellStyle.Font = font
                    Finally
                        font.Dispose()
                    End Try
                End With

                'menampilkan penjualan total
                HitungTotal()

            Catch ex As Exception
                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                CMDTampil.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub txt_nonota_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_nonota.Leave
        Tampil_Data_Beli()
    End Sub

    Private Sub ts_update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_update.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDUpdate As MySqlCommand = CN.CreateCommand

        If txt_nonota.Text <> "" Then
            Try
                With CMDUpdate
                    Dim Detil As String = ""
                    Dim Baris, TotBaris As Integer
                    TotBaris = dgv_beli.RowCount - 2
                    Detil = ""
                    'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                    'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                    'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                    'pada kolomnya masing-masing table penjualan_detil_tb
                    For Baris = 0 To TotBaris
                        Detil &= dgv_beli.Item(0, Baris).Value.ToString & Chr(21) & dgv_beli.Item(5, Baris).Value.ToString & Chr(21) & dgv_beli.Item(6, Baris).Value.ToString & Chr(21)
                    Next

                    'pemanggilan PEMBELIAN_SP sekaligus memasukkan nilai-nilai parameternya
                    SQL = "CALL PEMBELIAN_SP ('UPDATE', @no_nota, @tgl_beli, @kd_supplier, @detil); "
                    .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txt_nonota.Text
                    .Parameters.Add("@tgl_beli", MySqlDbType.Date).Value = dt_tglbeli.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                    .Parameters.Add("@kd_supplier", MySqlDbType.VarChar, 10).Value = txt_KdSupplier.Text
                    .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                    .CommandText = SQL
                    .Transaction = SQLTrans
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()
            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDUpdate.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub ts_delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_delete.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDDelete As MySqlCommand = CN.CreateCommand

        If txt_nonota.Text <> "" Then
            If MessageBox.Show("Anda yakin data pembelian dengan no nota: " & txt_nonota.Text & " akan dihapus?", "Peringatan!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                Try
                    With CMDDelete
                        Dim Detil As String = ""
                        Dim Baris, TotBaris As Integer
                        TotBaris = dgv_beli.RowCount - 2
                        Detil = ""
                        'menggabungkan nilai pada kolom ke-0 (kode buku),ke-5(harga) 
                        'dan ke-6(jumlah) yang dibatasi oleh tanda |.
                        'gabungan string ini akan diuraikan pada MySQl untuk ditempatkan
                        'pada kolomnya masing-masing table penjualan_detil_tb
                        For Baris = 0 To TotBaris
                            Detil &= dgv_beli.Item(0, Baris).Value.ToString & Chr(21) & dgv_beli.Item(5, Baris).Value.ToString & Chr(21) & dgv_beli.Item(6, Baris).Value.ToString & Chr(21)
                        Next

                        'pemanggilan PEMBELIAN_SP sekaligus memasukkan nilai-nilai parameternya
                        SQL = "CALL PEMBELIAN_SP ('DELETE', @no_nota, @tgl_beli, @kd_supplier, @detil); "
                        .Parameters.Add("@no_nota", MySqlDbType.VarChar, 10).Value = txt_nonota.Text
                        .Parameters.Add("@tgl_beli", MySqlDbType.Date).Value = dt_tglbeli.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
                        .Parameters.Add("@kd_supplier", MySqlDbType.VarChar, 10).Value = txt_KdSupplier.Text
                        .Parameters.Add("@detil", MySqlDbType.Text).Value = Detil
                        .CommandText = SQL
                        .Transaction = SQLTrans
                        .ExecuteNonQuery()
                    End With

                    '---------------------------------------------------------
                    'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                    'melalui perintah COMMIT transaction
                    '---------------------------------------------------------
                    SQLTrans.Commit()

                    '-----------------------------------------------------
                    'memanggil method ClearForm() untuk membersihkan Form
                    '-----------------------------------------------------
                    ClearForm()
                Catch ex As MySqlException
                    '-------------------------------------------------
                    'Jika terjadi kegagalan, maka eksekusi dibatalkan
                    'melalui perintah ROLLBACK transaction
                    '-------------------------------------------------
                    SQLTrans.Rollback()

                    '----------------------------------------------------
                    'Pesan kesalahan ditampilkan melalui MessageBox.Show
                    '----------------------------------------------------
                    MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    '---------------------------------------------------
                    'melalui try...finally, maka baik gagal atau sukses.
                    'maka SQLTrans dan CMDInsert dimusnahkan
                    'sehingga kedua resource tersebut dilepas
                    '---------------------------------------------------
                    SQLTrans.Dispose()
                    CMDDelete.Dispose()
                    CN.Close()
                    CN = Nothing
                End Try
            End If
        Else
            MessageBox.Show("No Nota belum terisi!")
        End If
    End Sub

    Private Sub HitungTotal()
        'menghitung nilai total, yang diperoleh dari sub total (kolom ke-7).
        'sedangkan kolom sub total diperoleh dari perkalian kolom harga dan jumlah
        Dim i As Integer
        Dim total As Double
        total = 0
        For i = 0 To dgv_beli.RowCount - 1
            total += dgv_beli.Item(7, i).Value
        Next

        'melimpahkan nilai total ke label lbl_total,
        'sekaligus mem-format-nya ke tipe mata uang (Currency)
        lbl_total.Text = "TOTAL : " & Format(total, "C")
    End Sub

    Private Sub frmPenjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txt_nonota.AllowDrop = True
        txt_KdSupplier.AllowDrop = True

        Me.Width = 900
        Me.Height = 550
        lbl_Navigator.Enabled = False
        ts_first.Enabled = False
        ts_prev.Enabled = False
        ts_next.Enabled = False
        ts_last.Enabled = False
    End Sub

    Private Sub dgv_beli_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv_beli.CellEndEdit
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Try
            Select Case dgv_beli.CurrentCell.ColumnIndex 'pilihan cell yang sedang di-edit
                Case 0
                    Dim CMDItemBuku As MySqlCommand = CN.CreateCommand
                    SQL = "SELECT * FROM TAMPIL_ITEM_BUKU_VW WHERE kode_buku = @KodeBuku;"
                    CMDItemBuku.Parameters.Add("@KodeBuku", MySqlDbType.VarChar, 13).Value = dgv_beli.CurrentCell.Value
                    CMDItemBuku.CommandText = SQL

                    'menampilkan semua data dimana kode buku = cell kolom ke-0
                    'dari baris yang terpilih saat ini
                    Dim dr As MySqlDataReader = CMDItemBuku.ExecuteReader
                    If dr.Read Then
                        With dgv_beli.CurrentRow
                            .Cells(1).Value = dr.GetString("judul")
                            .Cells(2).Value = dr.GetString("nama_penerbit")
                            .Cells(3).Value = dr.GetString("nama_penulis")
                            .Cells(4).Value = dr.GetString("nama_kelompok")
                            '.Cells(5).Value = dr.GetDouble("harga_beli")
                        End With
                    End If
                    dr.Close()
                Case 5
                    'Menampilkan perubahan sub total setiap kali 
                    'terjadi perubahan pada kolom harga (kolom 5)
                    With dgv_beli.CurrentRow
                        If IsDBNull(.Cells(5).Value) Then .Cells(5).Value = 0
                        If IsDBNull(.Cells(6).Value) Then .Cells(6).Value = 0
                        .Cells(7).Value = .Cells(5).Value * .Cells(6).Value
                    End With
                    HitungTotal()
                Case 6
                    'Menampilkan perubahan sub total setiap kali 
                    'terjadi perubahan pada kolom jumlah (kolom 6)
                    With dgv_beli.CurrentRow
                        If IsDBNull(.Cells(5).Value) Then .Cells(5).Value = 0
                        If IsDBNull(.Cells(6).Value) Then .Cells(6).Value = 0
                        .Cells(7).Value = .Cells(5).Value * .Cells(6).Value
                    End With
                    HitungTotal()
            End Select

        Catch ex As Exception
            '----------------------------------------------------
            'Pesan kesalahan ditampilkan melalui MessageBox.Show
            '----------------------------------------------------
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try

    End Sub

    Private Sub Tampil_Supplier()
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Try
            Dim CMDItemSupplier As MySqlCommand = CN.CreateCommand
            SQL = "SELECT * FROM supplier_tb WHERE kode_supplier = @kdSupplier;"
            CMDItemSupplier.Parameters.Add("@kdSupplier", MySqlDbType.VarChar, 10).Value = txt_KdSupplier.Text
            CMDItemSupplier.CommandText = SQL

            Dim dr As MySqlDataReader = CMDItemSupplier.ExecuteReader
            If dr.Read Then txt_NamaSupplier.Text = dr.GetString("nama_supplier")
            dr.Close()
        Catch ex As Exception
            '----------------------------------------------------
            'Pesan kesalahan ditampilkan melalui MessageBox.Show
            '----------------------------------------------------
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub txt_KdSupplier_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_KdSupplier.Leave
        Tampil_Supplier()
    End Sub

    Private Sub btn_BrowseKodeBuku_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_BrowseKodeBuku.Click
        '----------------------------------------------------------
        'memanggil form frmBrowse dan menampilkan TabPage keenam, 
        'tab_Browse.SelectTab(6)
        '----------------------------------------------------------
        Dim fb As frmBrowse = New frmBrowse
        fb.MdiParent = frmMDI
        fb.Show()
        fb.tab_Browse.SelectTab(6)
    End Sub

    Private Sub txt_nonota_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txt_nonota.DragDrop
        txt_nonota.Text = e.Data.GetData(DataFormats.Text)
        Tampil_Data_Beli()
    End Sub

    Private Sub txt_nonota_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txt_nonota.DragEnter
        If (e.Data.GetDataPresent(DataFormats.Text)) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '----------------------------------------------------------
        'memanggil form frmBrowse dan menampilkan TabPage keenam, 
        'tab_Browse.SelectTab(6)
        '----------------------------------------------------------
        Dim fb As frmBrowse = New frmBrowse
        fb.MdiParent = frmMDI
        fb.Show()
        fb.tab_Browse.SelectTab(4) 'Browse Supplier
    End Sub

    Private Sub txt_KdSupplier_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txt_KdSupplier.DragDrop
        txt_KdSupplier.Text = e.Data.GetData(DataFormats.Text)
        Tampil_Supplier()
    End Sub

    Private Sub txt_KdSupplier_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txt_KdSupplier.DragEnter
        If (e.Data.GetDataPresent(DataFormats.Text)) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub mnu_BrowseBuku_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_BrowseBuku.Click
        '----------------------------------------------------------
        'memanggil form frmBrowse dan menampilkan TabPage pertama, 
        'tab_Browse.SelectTab(0)
        '----------------------------------------------------------
        Dim fb As frmBrowse = New frmBrowse
        fb.MdiParent = frmMDI
        fb.Show()
        fb.tab_Browse.SelectTab(0)
    End Sub

End Class