'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class frmCiptakanStokAwal

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        Try
            'Mematikan Tombol proses dan menampilkan tulisan proses
            lbl_proses.Visible = True
            lbl_proses.Text = "Masih Proses..."
            Button1.Enabled = False

            '------------------------------------------------------------------------------------------
            'memanggil Store Proceudre MASTER_PENERBIT_SP dari MySQL melalui perintah CALL.
            'Dan menyertakan parameternya, yang ditandai dengan @ dan diikuti oleh nama variable.
            'Dimana urutan parameter harus sama dengan urutan parameter Store Procedure MASTER_BUKU_SP
            '------------------------------------------------------------------------------------------
            With CMDInsert
                .CommandText = "CALL CIPTAKAN_STOK_AWAL_SP(@bulan, @tahun);"
                .Connection = CN
                .Transaction = SQLTrans

                '------------------------------------------------------------------------
                'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                '------------------------------------------------------------------------
                .Parameters.Add("@bulan", MySqlDbType.Int16).Value = Mid(mk_PeriodeStok.Text, 1, 2)
                .Parameters.Add("@tahun", MySqlDbType.Int32).Value = Mid(mk_PeriodeStok.Text, 4, 4)

                '----------------------------
                'Mengeksekusi Query dia atas
                '----------------------------
                .ExecuteNonQuery()
            End With

            '---------------------------------------------------------
            'Jika sukses dilaksanakan, maka perubahan dibuat permanen
            'melalui perintah COMMIT transaction
            '---------------------------------------------------------
            SQLTrans.Commit()

            'Menghidupkan Tombol proses dan menyembunyikan tulisan proses
            lbl_proses.Visible = False
            lbl_proses.Text = ""
            Button1.Enabled = True
        Catch ex As Exception
            '-------------------------------------------------
            'Jika terjadi kegagalan, maka eksekusi dibatalkan
            'melalui perintah ROLLBACK transaction
            '-------------------------------------------------
            SQLTrans.Rollback()

            '----------------------------------------------------
            'Pesan kesalahan ditampilkan melalui MessageBox.Show
            '----------------------------------------------------
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            '---------------------------------------------------
            'melalui try...finally, maka baik gagal atau sukses.
            'maka SQLTrans dan CMDInsert dimusnahkan
            'sehingga kedua resource tersebut dilepas
            '---------------------------------------------------
            SQLTrans.Dispose()
            CMDInsert.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        Try
            'Mematikan Tombol proses dan menampilkan tulisan proses
            'lbl_proses.Visible = True
            'lbl_proses.Text = "Masih Proses..."
            Button2.Enabled = False

            '------------------------------------------------------------------------------------------
            'memanggil Store Proceudre MASTER_PENERBIT_SP dari MySQL melalui perintah CALL.
            'Dan menyertakan parameternya, yang ditandai dengan @ dan diikuti oleh nama variable.
            'Dimana urutan parameter harus sama dengan urutan parameter Store Procedure MASTER_BUKU_SP
            '------------------------------------------------------------------------------------------
            With CMDInsert
                .CommandText = "CALL PINDAH_STOK_SP(@bulan, @tahun);"
                .Connection = CN
                .Transaction = SQLTrans

                '------------------------------------------------------------------------
                'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                '------------------------------------------------------------------------
                .Parameters.Add("@bulan", MySqlDbType.Int16).Value = Convert.ToInt16(Mid(mk_PindahStok1.Text, 1, 2))
                .Parameters.Add("@tahun", MySqlDbType.Int32).Value = Convert.ToInt32(Mid(mk_PindahStok1.Text, 4, 4))

                '----------------------------
                'Mengeksekusi Query dia atas
                '----------------------------
                .ExecuteNonQuery()
            End With

            '---------------------------------------------------------
            'Jika sukses dilaksanakan, maka perubahan dibuat permanen
            'melalui perintah COMMIT transaction
            '---------------------------------------------------------
            SQLTrans.Commit()

            'Menghidupkan Tombol proses dan menyembunyikan tulisan proses
            'lbl_proses.Visible = False
            'lbl_proses.Text = ""
            Button2.Enabled = True
        Catch ex As Exception
            '-------------------------------------------------
            'Jika terjadi kegagalan, maka eksekusi dibatalkan
            'melalui perintah ROLLBACK transaction
            '-------------------------------------------------
            SQLTrans.Rollback()

            '----------------------------------------------------
            'Pesan kesalahan ditampilkan melalui MessageBox.Show
            '----------------------------------------------------
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            '---------------------------------------------------
            'melalui try...finally, maka baik gagal atau sukses.
            'maka SQLTrans dan CMDInsert dimusnahkan
            'sehingga kedua resource tersebut dilepas
            '---------------------------------------------------
            SQLTrans.Dispose()
            CMDInsert.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub mk_PindahStok1_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mk_PindahStok1.Leave
        Dim Bulan1, Bulan2, Tahun1, Tahun2 As Integer
        Bulan1 = Convert.ToInt16(Mid(mk_PindahStok1.Text, 1, 2))
        Tahun1 = Convert.ToInt32(Mid(mk_PindahStok1.Text, 4, 4))

        If Len(mk_PindahStok1.Text) = 7 Then
            If Bulan1 = 12 Then
                Bulan2 = 1
                Tahun2 = Tahun1 + 1
            Else
                Bulan2 = Bulan1 + 1
                Tahun2 = Tahun1
            End If
        End If

        mk_PindahStok2.Text = Format(Bulan2, "0#") & "/" & Convert.ToString(Tahun2)
    End Sub

End Class