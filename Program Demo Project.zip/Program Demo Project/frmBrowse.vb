'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Imports System.Globalization

Public Class frmBrowse

    Private MouseIsDown As Boolean = False

    Private Sub btn_CariBuku_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariBuku.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariBuku As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            '-------------------------------------------------------------------
            'memanggil store procedure BROWSE_SP yang disertai dengan parameter
            '-------------------------------------------------------------------
            If rb_KodeBuku.Checked = True Then SQL = "CALL BROWSE_SP ('BUKU', 'KODE', @CARI)"
            If rd_judul.Checked = True Then SQL = "CALL BROWSE_SP ('BUKU', 'JUDUL', @CARI)"
            If rd_Penulis.Checked = True Then SQL = "CALL BROWSE_SP ('BUKU', 'PENULIS', @CARI)"
            If rd_Penerbit.Checked = True Then SQL = "CALL BROWSE_SP ('BUKU', 'PENERBIT', @CARI)"

            CMDCariBuku.CommandText = SQL
            CMDCariBuku.Parameters.Add("@CARI", MySqlDbType.VarChar, 100).Value = txtCariBuku.Text

            MyAdapter.SelectCommand = CMDCariBuku
            MyAdapter.Fill(MyDataset, "browse_buku_vw")
            dgv_Buku.DataSource = MyDataset
            dgv_Buku.DataMember = "browse_buku_vw"
            dgv_Buku.Columns(2).Width = 325 'Lebar kolom datagridview Judul 
            dgv_Buku.Columns(4).Width = 150 'Lebar kolom datagridview Penulis
            dgv_Buku.Columns(5).Width = 150 'Lebar kolom datagridview Penerbit

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CMDCariBuku.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_CariKelompok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariKelompok.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariKelompok As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            '-------------------------------------------------------------------
            'memanggil store procedure BROWSE_SP yang disertai dengan parameter
            '-------------------------------------------------------------------
            SQL = "CALL BROWSE_SP ('KELOMPOK', '', @CARI)"
            CMDCariKelompok.CommandText = SQL
            CMDCariKelompok.Parameters.Add("@CARI", MySqlDbType.VarChar, 100).Value = txtCariKelompok.Text

            MyAdapter.SelectCommand = CMDCariKelompok
            MyAdapter.Fill(MyDataset, "kelompok_buku_tb")
            dgv_KelompokBuku.DataSource = MyDataset
            dgv_KelompokBuku.DataMember = "kelompok_buku_tb"
            dgv_KelompokBuku.Columns(1).Width = 200 'Lebar kolom datagridview Nama Kelompok 
            dgv_KelompokBuku.Columns(2).Width = 300 'Lebar kolom datagridview Keterangan

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CMDCariKelompok.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_CariPenulis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariPenulis.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariPenulis As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            '-------------------------------------------------------------------
            'memanggil store procedure BROWSE_SP yang disertai dengan parameter
            '-------------------------------------------------------------------
            SQL = "CALL BROWSE_SP ('PENULIS', '', @CARI)"
            CMDCariPenulis.CommandText = SQL
            CMDCariPenulis.Parameters.Add("@CARI", MySqlDbType.VarChar, 100).Value = txtCariPenulis.Text

            MyAdapter.SelectCommand = CMDCariPenulis
            MyAdapter.Fill(MyDataset, "penulis_tb")
            dgv_Penulis.DataSource = MyDataset
            dgv_Penulis.DataMember = "penulis_tb"
            dgv_Penulis.Columns(1).Width = 200 'Lebar kolom datagridview Nama Penulis 

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CMDCariPenulis.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_CariPenerbit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariPenerbit.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariPenerbit As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            '-------------------------------------------------------------------
            'memanggil store procedure BROWSE_SP yang disertai dengan parameter
            '-------------------------------------------------------------------
            SQL = "CALL BROWSE_SP ('PENERBIT', '', @CARI)"
            CMDCariPenerbit.CommandText = SQL
            CMDCariPenerbit.Parameters.Add("@CARI", MySqlDbType.VarChar, 100).Value = txtCariPenerbit.Text

            MyAdapter.SelectCommand = CMDCariPenerbit
            MyAdapter.Fill(MyDataset, "penerbit_tb")
            dgv_Penerbit.DataSource = MyDataset
            dgv_Penerbit.DataMember = "penerbit_tb"
            dgv_Penerbit.Columns(1).Width = 200 'Lebar kolom datagridview Nama Penerbit 
            dgv_Penerbit.Columns(2).Width = 150 'Lebar kolom datagridview Alamt Penerbit 

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CMDCariPenerbit.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_CariSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariSupplier.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariSupplier As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            '-------------------------------------------------------------------
            'memanggil store procedure BROWSE_SP yang disertai dengan parameter
            '-------------------------------------------------------------------
            SQL = "CALL BROWSE_SP ('SUPPLIER', '', @CARI)"
            CMDCariSupplier.CommandText = SQL
            CMDCariSupplier.Parameters.Add("@CARI", MySqlDbType.VarChar, 100).Value = txtCariSupplier.Text

            MyAdapter.SelectCommand = CMDCariSupplier
            MyAdapter.Fill(MyDataset, "supplier_tb")
            dgv_Supplier.DataSource = MyDataset
            dgv_Supplier.DataMember = "supplier_tb"
            dgv_Supplier.Columns(1).Width = 200 'Lebar kolom datagridview Nama supplier 
            dgv_Supplier.Columns(2).Width = 150 'Lebar kolom datagridview Alamt supplier 

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CMDCariSupplier.Dispose()
            CN.Dispose()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_CariJual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariJual.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariJual As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            SQL = "SELECT * FROM TAMPIL_JUAL_HEADER_VW WHERE Tanggal BETWEEN @TGL_AWAL AND @TGL_AKHIR"
            CMDCariJual.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariJual

            'memformat tanggal menjadi tahun/bulan/tanggal, sesuai format tanggal database
            Dim tgl1, tgl2 As String
            tgl1 = date_TglJual1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            tgl2 = date_TglJual2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            CMDCariJual.Parameters.Add("@TGL_AWAL", MySqlDbType.Date).Value = tgl1
            CMDCariJual.Parameters.Add("@TGL_AKHIR", MySqlDbType.Date).Value = tgl2

            MyAdapter.Fill(MyDataset, "TAMPIL_JUAL_HEADER_VW")
            With dgv_PenjualanHeader
                .DataSource = MyDataset
                .DataMember = "TAMPIL_JUAL_HEADER_VW"
                .Columns("Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariJual.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_PenjualanHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dgv_PenjualanHeader.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariJualDetil As MySqlCommand = CN.CreateCommand
        Dim ds As DataSet = New DataSet

        Try
            ds.Clear()
            SQL = "SELECT * FROM TAMPIL_JUAL_DETIL_VW WHERE nota_jual=@NOTA"
            CMDCariJualDetil.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariJualDetil
            CMDCariJualDetil.Parameters.Add("@NOTA", MySqlDbType.String, 10).Value = dgv_PenjualanHeader.CurrentRow.Cells(0).Value

            Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDCariJualDetil)
            daTampil.Fill(ds, "TAMPIL_JUAL_DETIL_VW")

            With dgv_PenjualanDetil
                .DataSource = ds
                .DataMember = "TAMPIL_JUAL_DETIL_VW"
                .Columns("Judul Buku").Width = 260 'Lebar kolom Judul Buku 

                .Columns("Harga Satuan").DefaultCellStyle.Format = "N" 'Format angka
                .Columns("Harga Satuan").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Harga Satuan").Width = 100

                .Columns("Jumlah").DefaultCellStyle.Format = "N" 'Format Angka
                .Columns("Jumlah").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Jumlah").Width = 70

                .Columns("Sub Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Sub Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Sub Total").DefaultCellStyle.ForeColor = Color.Black
                .Columns("Sub Total").DefaultCellStyle.BackColor = Color.Yellow
                .Columns("Sub Total").ReadOnly = True 'kolom sub total hanya dapat dibaca

                .Columns("Kode").ReadOnly = True
                .Columns("Judul Buku").ReadOnly = True
                .Columns("Jumlah").ReadOnly = True
                .Columns("Harga Satuan").ReadOnly = True
                .Columns("Sub Total").ReadOnly = True
                .Columns("nota_jual").Visible = False
            End With
            
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariJualDetil.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_Buku_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Buku.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_Buku_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Buku.MouseMove
        If MouseIsDown Then
            dgv_Buku.DoDragDrop(dgv_Buku.Item(0, dgv_Buku.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub dgv_Penulis_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Penulis.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_Penulis_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Penulis.MouseMove
        If MouseIsDown Then
            dgv_Penulis.DoDragDrop(dgv_Penulis.Item(0, dgv_Penulis.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub frmBrowse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dgv_Buku.MultiSelect = False
        dgv_KelompokBuku.MultiSelect = False
        dgv_Penulis.MultiSelect = False
        dgv_Penerbit.MultiSelect = False
        dgv_Supplier.MultiSelect = False

        dgv_PembelianHeader.MultiSelect = False
        dgv_PembelianDetil.MultiSelect = False

        dgv_PenjualanHeader.MultiSelect = False
        dgv_PenjualanDetil.MultiSelect = False

        dgv_ReturHeader.MultiSelect = False
        dgv_ReturDetil.MultiSelect = False
    End Sub

    Private Sub dgv_KelompokBuku_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_KelompokBuku.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_KelompokBuku_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_KelompokBuku.MouseMove
        If MouseIsDown Then
            dgv_KelompokBuku.DoDragDrop(dgv_KelompokBuku.Item(0, dgv_KelompokBuku.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub dgv_Penerbit_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Penerbit.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_Penerbit_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Penerbit.MouseMove
        If MouseIsDown Then
            dgv_Penerbit.DoDragDrop(dgv_Penerbit.Item(0, dgv_Penerbit.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub dgv_PenjualanHeader_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_PenjualanHeader.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_PenjualanHeader_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_PenjualanHeader.MouseMove
        If MouseIsDown Then
            dgv_PenjualanHeader.DoDragDrop(dgv_PenjualanHeader.Item(0, dgv_PenjualanHeader.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub btn_CariPembelian_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariPembelian.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariBeli As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            SQL = "SELECT * FROM TAMPIL_BELI_HEADER_VW WHERE Tanggal BETWEEN @TGL_AWAL AND @TGL_AKHIR"
            CMDCariBeli.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariBeli

            'memformat tanggal menjadi tahun/bulan/tanggal, sesuai format tanggal database
            Dim tgl1, tgl2 As String
            tgl1 = date_TglBeli1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            tgl2 = date_TglBeli2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            CMDCariBeli.Parameters.Add("@TGL_AWAL", MySqlDbType.Date).Value = tgl1
            CMDCariBeli.Parameters.Add("@TGL_AKHIR", MySqlDbType.Date).Value = tgl2

            MyAdapter.Fill(MyDataset, "TAMPIL_BELI_HEADER_VW")
            With dgv_PembelianHeader
                .DataSource = MyDataset
                .DataMember = "TAMPIL_BELI_HEADER_VW"
                .Columns("Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Supplier").Width = 260
            End With
            
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariBeli.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_PembelianHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dgv_PembelianHeader.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariBeliDetil As MySqlCommand = CN.CreateCommand
        Dim ds As DataSet = New DataSet

        Try
            SQL = "SELECT * FROM TAMPIL_BELI_DETIL_VW WHERE nota_beli=@NOTA"
            CMDCariBeliDetil.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariBeliDetil
            CMDCariBeliDetil.Parameters.Add("@NOTA", MySqlDbType.String, 10).Value = dgv_PembelianHeader.CurrentRow.Cells(0).Value

            Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDCariBeliDetil)
            ds.Clear()
            daTampil.Fill(ds, "TAMPIL_BELI_DETIL_VW")

            With dgv_PembelianDetil
                .DataSource = ds
                .DataMember = "TAMPIL_BELI_DETIL_VW"
                .Columns("Judul Buku").Width = 260 'Lebar kolom Judul Buku 

                .Columns("Harga Satuan").DefaultCellStyle.Format = "N" 'Format angka
                .Columns("Harga Satuan").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Harga Satuan").Width = 100

                .Columns("Jumlah").DefaultCellStyle.Format = "N" 'Format Angka
                .Columns("Jumlah").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Jumlah").Width = 70

                .Columns("Sub Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Sub Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Sub Total").DefaultCellStyle.ForeColor = Color.Black
                .Columns("Sub Total").DefaultCellStyle.BackColor = Color.Yellow
                .Columns("Sub Total").ReadOnly = True 'kolom sub total hanya dapat dibaca

                .Columns("Kode").ReadOnly = True
                .Columns("Judul Buku").ReadOnly = True
                .Columns("Jumlah").ReadOnly = True
                .Columns("Harga Satuan").ReadOnly = True
                .Columns("Sub Total").ReadOnly = True
                .Columns("nota_beli").Visible = False
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariBeliDetil.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_PembelianHeader_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_PembelianHeader.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_PembelianHeader_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_PembelianHeader.MouseMove
        If MouseIsDown Then
            dgv_PembelianHeader.DoDragDrop(dgv_PembelianHeader.Item(0, dgv_PembelianHeader.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub dgv_Supplier_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Supplier.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_Supplier_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_Supplier.MouseMove
        If MouseIsDown Then
            dgv_Supplier.DoDragDrop(dgv_Supplier.Item(0, dgv_Supplier.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub

    Private Sub btn_CariRetur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CariRetur.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariRetur As MySqlCommand = CN.CreateCommand

        Try
            MyDataset.Clear()
            SQL = "SELECT * FROM TAMPIL_RETUR_HEADER_VW WHERE Tanggal BETWEEN @TGL_AWAL AND @TGL_AKHIR"
            CMDCariRetur.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariRetur

            'memformat tanggal menjadi tahun/bulan/tanggal, sesuai format tanggal database
            Dim tgl1, tgl2 As String
            tgl1 = date_Retur1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            tgl2 = date_Retur2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
            CMDCariRetur.Parameters.Add("@TGL_AWAL", MySqlDbType.Date).Value = tgl1
            CMDCariRetur.Parameters.Add("@TGL_AKHIR", MySqlDbType.Date).Value = tgl2

            MyAdapter.Fill(MyDataset, "TAMPIL_RETUR_HEADER_VW")
            With dgv_ReturHeader
                .DataSource = MyDataset
                .DataMember = "TAMPIL_RETUR_HEADER_VW"
                .Columns("Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Supplier").Width = 260
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariRetur.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_ReturHeader_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dgv_ReturHeader.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDCariReturDetil As MySqlCommand = CN.CreateCommand
        Dim ds As DataSet = New DataSet

        Try
            SQL = "SELECT * FROM TAMPIL_RETUR_DETIL_VW WHERE nota_retur=@NOTA"
            CMDCariReturDetil.CommandText = SQL
            MyAdapter.SelectCommand = CMDCariReturDetil
            CMDCariReturDetil.Parameters.Add("@NOTA", MySqlDbType.String, 10).Value = dgv_ReturHeader.CurrentRow.Cells(0).Value

            Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDCariReturDetil)
            ds.Clear()
            daTampil.Fill(ds, "TAMPIL_RETUR_DETIL_VW")

            With dgv_ReturDetil
                .DataSource = ds
                .DataMember = "TAMPIL_RETUR_DETIL_VW"
                .Columns("Judul Buku").Width = 260 'Lebar kolom Judul Buku 

                .Columns("Harga Satuan").DefaultCellStyle.Format = "N" 'Format angka
                .Columns("Harga Satuan").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Harga Satuan").Width = 100

                .Columns("Jumlah").DefaultCellStyle.Format = "N" 'Format Angka
                .Columns("Jumlah").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Jumlah").Width = 70

                .Columns("Sub Total").DefaultCellStyle.Format = "N" 'Format mata uang
                .Columns("Sub Total").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns("Sub Total").DefaultCellStyle.ForeColor = Color.Black
                .Columns("Sub Total").DefaultCellStyle.BackColor = Color.Yellow
                .Columns("Sub Total").ReadOnly = True 'kolom sub total hanya dapat dibaca

                .Columns("Kode").ReadOnly = True
                .Columns("Judul Buku").ReadOnly = True
                .Columns("Jumlah").ReadOnly = True
                .Columns("Harga Satuan").ReadOnly = True
                .Columns("Sub Total").ReadOnly = True
                .Columns("nota_retur").Visible = False
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Pencarian gagal!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CMDCariReturDetil.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub dgv_ReturHeader_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_ReturHeader.MouseDown
        MouseIsDown = True
    End Sub

    Private Sub dgv_ReturHeader_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgv_ReturHeader.MouseMove
        If MouseIsDown Then
            dgv_ReturHeader.DoDragDrop(dgv_ReturHeader.Item(0, dgv_ReturHeader.CurrentCell.RowIndex).Value, DragDropEffects.Copy)
        End If
        MouseIsDown = False
    End Sub
End Class