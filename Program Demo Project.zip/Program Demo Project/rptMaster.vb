'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class rptMaster
    Private Sub RadioButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_BUKU_VW;"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_BUKU_VW")

            Dim myreport As New rptJenisBuku
            myreport.SetDataSource(MyDataset)
            'menghidupkan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = True
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub rptMaster_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub RadioButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_BUKU_VW;"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_BUKU_VW")

            Dim myreport As New rptPenerbitBuku
            myreport.SetDataSource(MyDataset)
            'menghidupkan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = True
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_BUKU_VW WHERE tahun_terbit BETWEEN '" & txt_Tahun1.Text & "' AND '" & txt_Tahun2.Text & "';"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_BUKU_VW")

            Dim myreport As New rptTahunTerbitBuku
            myreport.SetDataSource(MyDataset)
            'mematikan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = False
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub RadioButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_BUKU_VW;"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_BUKU_VW")

            Dim myreport As New rptPenulisBuku
            myreport.SetDataSource(MyDataset)
            'menghidupkan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = True
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub txt_Tahun1_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Tahun1.Leave
        '--------------------------------------
        'memastikan bahwa inputan berupa angka
        '--------------------------------------
        Numerik_Valid(txt_Tahun1.Text, txt_Tahun1)
    End Sub

    Private Sub txt_Tahun2_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_Tahun2.Leave
        '--------------------------------------
        'memastikan bahwa inputan berupa angka
        '--------------------------------------
        Numerik_Valid(txt_Tahun2.Text, txt_Tahun2)
    End Sub

    Private Sub btnPenerbit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPenerbit.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_TAMPIL_PENERBIT_VW WHERE Penerbit LIKE '%" & txtPenerbit.Text & "%'"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_TAMPIL_PENERBIT_VW")

            Dim myreport As New rptPenerbit
            myreport.SetDataSource(MyDataset)
            'mematikan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = False
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub btnPenulis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPenulis.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_PENULIS_VW WHERE Penulis LIKE '%" & txtPenulis.Text & "%'"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_PENULIS_VW")

            Dim myreport As New rptPenulis
            myreport.SetDataSource(MyDataset)
            'mematikan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = False
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub btnSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSupplier.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_TAMPIL_SUPPLIER_VW WHERE Supplier LIKE '%" & txtSupplier.Text & "%'"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_TAMPIL_SUPPLIER_VW")

            Dim myreport As New rptSupplier
            myreport.SetDataSource(MyDataset)
            'mematikan displaygroupdirectory
            Me.CRV_Master.DisplayGroupTree = False
            Me.CRV_Master.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged

    End Sub
End Class