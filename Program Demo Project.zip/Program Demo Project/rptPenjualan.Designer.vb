<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class rptPenjualan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.txt_NoNota2 = New System.Windows.Forms.TextBox
        Me.txt_NoNota1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.dt_TglJual2 = New System.Windows.Forms.DateTimePicker
        Me.dt_TglJual1 = New System.Windows.Forms.DateTimePicker
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.dt_Buku2 = New System.Windows.Forms.DateTimePicker
        Me.dt_Buku1 = New System.Windows.Forms.DateTimePicker
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Button3 = New System.Windows.Forms.Button
        Me.txt_KodeBuku2 = New System.Windows.Forms.TextBox
        Me.txt_KodeBuku1 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Button4 = New System.Windows.Forms.Button
        Me.txt_KodeKel2 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txt_KodeKel1 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.rpt_Viewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(777, 88)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.txt_NoNota2)
        Me.TabPage1.Controls.Add(Me.txt_NoNota1)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(769, 62)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Per No. Nota"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(310, 21)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Tampilkan"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt_NoNota2
        '
        Me.txt_NoNota2.Location = New System.Drawing.Point(204, 23)
        Me.txt_NoNota2.Name = "txt_NoNota2"
        Me.txt_NoNota2.Size = New System.Drawing.Size(100, 20)
        Me.txt_NoNota2.TabIndex = 3
        '
        'txt_NoNota1
        '
        Me.txt_NoNota1.Location = New System.Drawing.Point(69, 23)
        Me.txt_NoNota1.Name = "txt_NoNota1"
        Me.txt_NoNota1.Size = New System.Drawing.Size(100, 20)
        Me.txt_NoNota1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(175, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "s/d"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "No. Nota:"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dt_TglJual2)
        Me.TabPage2.Controls.Add(Me.dt_TglJual1)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(769, 62)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Per Tanggal Nota"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dt_TglJual2
        '
        Me.dt_TglJual2.Location = New System.Drawing.Point(268, 23)
        Me.dt_TglJual2.Name = "dt_TglJual2"
        Me.dt_TglJual2.Size = New System.Drawing.Size(140, 20)
        Me.dt_TglJual2.TabIndex = 6
        '
        'dt_TglJual1
        '
        Me.dt_TglJual1.Location = New System.Drawing.Point(93, 23)
        Me.dt_TglJual1.Name = "dt_TglJual1"
        Me.dt_TglJual1.Size = New System.Drawing.Size(140, 20)
        Me.dt_TglJual1.TabIndex = 5
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(414, 20)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Tampilkan"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(239, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(23, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "s/d"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Tgl. Penjualan:"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.dt_Buku2)
        Me.TabPage3.Controls.Add(Me.dt_Buku1)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.Button3)
        Me.TabPage3.Controls.Add(Me.txt_KodeBuku2)
        Me.TabPage3.Controls.Add(Me.txt_KodeBuku1)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(769, 62)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Per Buku"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'dt_Buku2
        '
        Me.dt_Buku2.Location = New System.Drawing.Point(273, 32)
        Me.dt_Buku2.Name = "dt_Buku2"
        Me.dt_Buku2.Size = New System.Drawing.Size(140, 20)
        Me.dt_Buku2.TabIndex = 5
        '
        'dt_Buku1
        '
        Me.dt_Buku1.Location = New System.Drawing.Point(98, 32)
        Me.dt_Buku1.Name = "dt_Buku1"
        Me.dt_Buku1.Size = New System.Drawing.Size(140, 20)
        Me.dt_Buku1.TabIndex = 4
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(244, 34)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(23, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "s/d"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 34)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 13)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "Tgl. Penjualan:"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(419, 6)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 46)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Tampilkan"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'txt_KodeBuku2
        '
        Me.txt_KodeBuku2.Location = New System.Drawing.Point(273, 6)
        Me.txt_KodeBuku2.Name = "txt_KodeBuku2"
        Me.txt_KodeBuku2.Size = New System.Drawing.Size(140, 20)
        Me.txt_KodeBuku2.TabIndex = 3
        '
        'txt_KodeBuku1
        '
        Me.txt_KodeBuku1.Location = New System.Drawing.Point(98, 6)
        Me.txt_KodeBuku1.Name = "txt_KodeBuku1"
        Me.txt_KodeBuku1.Size = New System.Drawing.Size(140, 20)
        Me.txt_KodeBuku1.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(244, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(23, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "s/d"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Kode Buku:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Button4)
        Me.TabPage4.Controls.Add(Me.txt_KodeKel2)
        Me.TabPage4.Controls.Add(Me.Label8)
        Me.TabPage4.Controls.Add(Me.txt_KodeKel1)
        Me.TabPage4.Controls.Add(Me.Label7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(769, 62)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Per Jenis Buku"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(343, 18)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Tampilkan"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'txt_KodeKel2
        '
        Me.txt_KodeKel2.Location = New System.Drawing.Point(237, 20)
        Me.txt_KodeKel2.Name = "txt_KodeKel2"
        Me.txt_KodeKel2.Size = New System.Drawing.Size(100, 20)
        Me.txt_KodeKel2.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(208, 23)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(23, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "s/d"
        '
        'txt_KodeKel1
        '
        Me.txt_KodeKel1.Location = New System.Drawing.Point(102, 20)
        Me.txt_KodeKel1.Name = "txt_KodeKel1"
        Me.txt_KodeKel1.Size = New System.Drawing.Size(100, 20)
        Me.txt_KodeKel1.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(85, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Kelompok Buku:"
        '
        'rpt_Viewer
        '
        Me.rpt_Viewer.ActiveViewIndex = -1
        Me.rpt_Viewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.rpt_Viewer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rpt_Viewer.Location = New System.Drawing.Point(0, 88)
        Me.rpt_Viewer.Name = "rpt_Viewer"
        Me.rpt_Viewer.SelectionFormula = ""
        Me.rpt_Viewer.Size = New System.Drawing.Size(777, 421)
        Me.rpt_Viewer.TabIndex = 1
        Me.rpt_Viewer.ViewTimeSelectionFormula = ""
        '
        'rptPenjualan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 509)
        Me.Controls.Add(Me.rpt_Viewer)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "rptPenjualan"
        Me.Text = "Laporan Penjualan"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents rpt_Viewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txt_NoNota2 As System.Windows.Forms.TextBox
    Friend WithEvents txt_NoNota1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents txt_KodeBuku1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents txt_KodeKel2 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txt_KodeKel1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dt_TglJual2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dt_TglJual1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dt_Buku2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dt_Buku1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_KodeBuku2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
