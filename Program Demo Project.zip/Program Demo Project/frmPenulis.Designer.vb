<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPenulis
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.lbl_Navigator = New System.Windows.Forms.ToolStripLabel
        Me.ts_first = New System.Windows.Forms.ToolStripButton
        Me.ts_prev = New System.Windows.Forms.ToolStripButton
        Me.ts_next = New System.Windows.Forms.ToolStripButton
        Me.ts_last = New System.Windows.Forms.ToolStripButton
        Me.separator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_addnew = New System.Windows.Forms.ToolStripButton
        Me.lbl_AddNew = New System.Windows.Forms.ToolStripLabel
        Me.ts_save = New System.Windows.Forms.ToolStripButton
        Me.lbl_Save = New System.Windows.Forms.ToolStripLabel
        Me.ts_update = New System.Windows.Forms.ToolStripButton
        Me.lbl_Update = New System.Windows.Forms.ToolStripLabel
        Me.ts_delete = New System.Windows.Forms.ToolStripButton
        Me.lbl_Delete = New System.Windows.Forms.ToolStripLabel
        Me.separator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_browse = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnu_BrowsePenulis = New System.Windows.Forms.ToolStripMenuItem
        Me.lbl_Browse = New System.Windows.Forms.ToolStripLabel
        Me.separator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_print = New System.Windows.Forms.ToolStripButton
        Me.lbl_Cetak = New System.Windows.Forms.ToolStripLabel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtTentangPenulis = New System.Windows.Forms.TextBox
        Me.lblTentangPenulis = New System.Windows.Forms.Label
        Me.btn_BrowseKodePenulis = New System.Windows.Forms.Button
        Me.txtWebsitePenulis = New System.Windows.Forms.TextBox
        Me.txtEmailPenulis = New System.Windows.Forms.TextBox
        Me.txtNamaPenulis = New System.Windows.Forms.TextBox
        Me.txtKodePenuliss = New System.Windows.Forms.TextBox
        Me.lblWebsite = New System.Windows.Forms.Label
        Me.lblEmail = New System.Windows.Forms.Label
        Me.lblNama = New System.Windows.Forms.Label
        Me.lblKode = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_Navigator, Me.ts_first, Me.ts_prev, Me.ts_next, Me.ts_last, Me.separator1, Me.ts_addnew, Me.lbl_AddNew, Me.ts_save, Me.lbl_Save, Me.ts_update, Me.lbl_Update, Me.ts_delete, Me.lbl_Delete, Me.separator2, Me.ts_browse, Me.lbl_Browse, Me.separator3, Me.ts_print, Me.lbl_Cetak})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(582, 25)
        Me.ToolStrip1.TabIndex = 28
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lbl_Navigator
        '
        Me.lbl_Navigator.Name = "lbl_Navigator"
        Me.lbl_Navigator.Size = New System.Drawing.Size(62, 22)
        Me.lbl_Navigator.Text = "Navigator:"
        '
        'ts_first
        '
        Me.ts_first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_first.Image = Global.PenjualanBuku.My.Resources.Resources._38
        Me.ts_first.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_first.Name = "ts_first"
        Me.ts_first.Size = New System.Drawing.Size(23, 22)
        Me.ts_first.Text = "Record Awal"
        '
        'ts_prev
        '
        Me.ts_prev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_prev.Image = Global.PenjualanBuku.My.Resources.Resources._36
        Me.ts_prev.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_prev.Name = "ts_prev"
        Me.ts_prev.Size = New System.Drawing.Size(23, 22)
        Me.ts_prev.Text = "Record Sebelum"
        '
        'ts_next
        '
        Me.ts_next.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_next.Image = Global.PenjualanBuku.My.Resources.Resources._35
        Me.ts_next.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_next.Name = "ts_next"
        Me.ts_next.Size = New System.Drawing.Size(23, 22)
        Me.ts_next.Text = "Record Setelah"
        '
        'ts_last
        '
        Me.ts_last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_last.Image = Global.PenjualanBuku.My.Resources.Resources._37
        Me.ts_last.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_last.Name = "ts_last"
        Me.ts_last.Size = New System.Drawing.Size(23, 22)
        Me.ts_last.Text = "Record Akhir "
        '
        'separator1
        '
        Me.separator1.Name = "separator1"
        Me.separator1.Size = New System.Drawing.Size(6, 25)
        '
        'ts_addnew
        '
        Me.ts_addnew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_addnew.Image = Global.PenjualanBuku.My.Resources.Resources._03
        Me.ts_addnew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_addnew.Name = "ts_addnew"
        Me.ts_addnew.Size = New System.Drawing.Size(23, 22)
        Me.ts_addnew.Text = "Tambah Data"
        '
        'lbl_AddNew
        '
        Me.lbl_AddNew.Name = "lbl_AddNew"
        Me.lbl_AddNew.Size = New System.Drawing.Size(56, 22)
        Me.lbl_AddNew.Text = "Add New"
        '
        'ts_save
        '
        Me.ts_save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_save.Image = Global.PenjualanBuku.My.Resources.Resources._461
        Me.ts_save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_save.Name = "ts_save"
        Me.ts_save.Size = New System.Drawing.Size(23, 22)
        Me.ts_save.Text = "Simpan Data"
        '
        'lbl_Save
        '
        Me.lbl_Save.Name = "lbl_Save"
        Me.lbl_Save.Size = New System.Drawing.Size(31, 22)
        Me.lbl_Save.Text = "Save"
        '
        'ts_update
        '
        Me.ts_update.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_update.Image = Global.PenjualanBuku.My.Resources.Resources._21
        Me.ts_update.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_update.Name = "ts_update"
        Me.ts_update.Size = New System.Drawing.Size(23, 22)
        Me.ts_update.Text = "Ubah Data"
        '
        'lbl_Update
        '
        Me.lbl_Update.Name = "lbl_Update"
        Me.lbl_Update.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Update.Text = "Update"
        '
        'ts_delete
        '
        Me.ts_delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_delete.Image = Global.PenjualanBuku.My.Resources.Resources._01
        Me.ts_delete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_delete.Name = "ts_delete"
        Me.ts_delete.Size = New System.Drawing.Size(23, 22)
        Me.ts_delete.Text = "Hapus Data"
        '
        'lbl_Delete
        '
        Me.lbl_Delete.Name = "lbl_Delete"
        Me.lbl_Delete.Size = New System.Drawing.Size(40, 22)
        Me.lbl_Delete.Text = "Delete"
        '
        'separator2
        '
        Me.separator2.Name = "separator2"
        Me.separator2.Size = New System.Drawing.Size(6, 25)
        '
        'ts_browse
        '
        Me.ts_browse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_browse.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_BrowsePenulis})
        Me.ts_browse.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.ts_browse.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_browse.Name = "ts_browse"
        Me.ts_browse.Size = New System.Drawing.Size(29, 22)
        Me.ts_browse.Text = "Browse"
        '
        'mnu_BrowsePenulis
        '
        Me.mnu_BrowsePenulis.Name = "mnu_BrowsePenulis"
        Me.mnu_BrowsePenulis.Size = New System.Drawing.Size(159, 22)
        Me.mnu_BrowsePenulis.Text = "Browse Penerbit"
        '
        'lbl_Browse
        '
        Me.lbl_Browse.Name = "lbl_Browse"
        Me.lbl_Browse.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Browse.Text = "Browse"
        '
        'separator3
        '
        Me.separator3.Name = "separator3"
        Me.separator3.Size = New System.Drawing.Size(6, 25)
        '
        'ts_print
        '
        Me.ts_print.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_print.Image = Global.PenjualanBuku.My.Resources.Resources._12
        Me.ts_print.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_print.Name = "ts_print"
        Me.ts_print.Size = New System.Drawing.Size(23, 22)
        Me.ts_print.Text = "Cetak"
        '
        'lbl_Cetak
        '
        Me.lbl_Cetak.Name = "lbl_Cetak"
        Me.lbl_Cetak.Size = New System.Drawing.Size(37, 22)
        Me.lbl_Cetak.Text = "Cetak"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtTentangPenulis)
        Me.GroupBox1.Controls.Add(Me.lblTentangPenulis)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodePenulis)
        Me.GroupBox1.Controls.Add(Me.txtWebsitePenulis)
        Me.GroupBox1.Controls.Add(Me.txtEmailPenulis)
        Me.GroupBox1.Controls.Add(Me.txtNamaPenulis)
        Me.GroupBox1.Controls.Add(Me.txtKodePenuliss)
        Me.GroupBox1.Controls.Add(Me.lblWebsite)
        Me.GroupBox1.Controls.Add(Me.lblEmail)
        Me.GroupBox1.Controls.Add(Me.lblNama)
        Me.GroupBox1.Controls.Add(Me.lblKode)
        Me.GroupBox1.Location = New System.Drawing.Point(5, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(570, 217)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Penulis"
        '
        'txtTentangPenulis
        '
        Me.txtTentangPenulis.Location = New System.Drawing.Point(121, 126)
        Me.txtTentangPenulis.Multiline = True
        Me.txtTentangPenulis.Name = "txtTentangPenulis"
        Me.txtTentangPenulis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTentangPenulis.Size = New System.Drawing.Size(331, 80)
        Me.txtTentangPenulis.TabIndex = 5
        '
        'lblTentangPenulis
        '
        Me.lblTentangPenulis.AutoSize = True
        Me.lblTentangPenulis.Location = New System.Drawing.Point(21, 161)
        Me.lblTentangPenulis.Name = "lblTentangPenulis"
        Me.lblTentangPenulis.Size = New System.Drawing.Size(84, 13)
        Me.lblTentangPenulis.TabIndex = 44
        Me.lblTentangPenulis.Text = "Tentang Penulis"
        '
        'btn_BrowseKodePenulis
        '
        Me.btn_BrowseKodePenulis.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodePenulis.Location = New System.Drawing.Point(427, 22)
        Me.btn_BrowseKodePenulis.Name = "btn_BrowseKodePenulis"
        Me.btn_BrowseKodePenulis.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodePenulis.TabIndex = 1
        Me.btn_BrowseKodePenulis.UseVisualStyleBackColor = True
        '
        'txtWebsitePenulis
        '
        Me.txtWebsitePenulis.Location = New System.Drawing.Point(121, 100)
        Me.txtWebsitePenulis.Name = "txtWebsitePenulis"
        Me.txtWebsitePenulis.Size = New System.Drawing.Size(331, 20)
        Me.txtWebsitePenulis.TabIndex = 4
        '
        'txtEmailPenulis
        '
        Me.txtEmailPenulis.Location = New System.Drawing.Point(121, 74)
        Me.txtEmailPenulis.Name = "txtEmailPenulis"
        Me.txtEmailPenulis.Size = New System.Drawing.Size(331, 20)
        Me.txtEmailPenulis.TabIndex = 3
        '
        'txtNamaPenulis
        '
        Me.txtNamaPenulis.Location = New System.Drawing.Point(121, 47)
        Me.txtNamaPenulis.Name = "txtNamaPenulis"
        Me.txtNamaPenulis.Size = New System.Drawing.Size(331, 20)
        Me.txtNamaPenulis.TabIndex = 2
        '
        'txtKodePenuliss
        '
        Me.txtKodePenuliss.Location = New System.Drawing.Point(121, 22)
        Me.txtKodePenuliss.Name = "txtKodePenuliss"
        Me.txtKodePenuliss.Size = New System.Drawing.Size(300, 20)
        Me.txtKodePenuliss.TabIndex = 0
        '
        'lblWebsite
        '
        Me.lblWebsite.AutoSize = True
        Me.lblWebsite.Location = New System.Drawing.Point(21, 103)
        Me.lblWebsite.Name = "lblWebsite"
        Me.lblWebsite.Size = New System.Drawing.Size(46, 13)
        Me.lblWebsite.TabIndex = 27
        Me.lblWebsite.Text = "Website"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(21, 77)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(32, 13)
        Me.lblEmail.TabIndex = 25
        Me.lblEmail.Text = "Email"
        '
        'lblNama
        '
        Me.lblNama.AutoSize = True
        Me.lblNama.Location = New System.Drawing.Point(21, 50)
        Me.lblNama.Name = "lblNama"
        Me.lblNama.Size = New System.Drawing.Size(35, 13)
        Me.lblNama.TabIndex = 24
        Me.lblNama.Text = "Nama"
        '
        'lblKode
        '
        Me.lblKode.AutoSize = True
        Me.lblKode.Location = New System.Drawing.Point(21, 27)
        Me.lblKode.Name = "lblKode"
        Me.lblKode.Size = New System.Drawing.Size(32, 13)
        Me.lblKode.TabIndex = 22
        Me.lblKode.Text = "Kode"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 250)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(582, 22)
        Me.StatusStrip1.TabIndex = 30
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'frmPenulis
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(582, 272)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "frmPenulis"
        Me.Text = "Master Penulis"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents lbl_Navigator As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_first As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_prev As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_next As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_last As System.Windows.Forms.ToolStripButton
    Friend WithEvents separator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_addnew As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_AddNew As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_save As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Save As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_update As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Update As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_delete As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Delete As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_browse As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnu_BrowsePenulis As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbl_Browse As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_print As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Cetak As System.Windows.Forms.ToolStripLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTentangPenulis As System.Windows.Forms.TextBox
    Friend WithEvents lblTentangPenulis As System.Windows.Forms.Label
    Friend WithEvents btn_BrowseKodePenulis As System.Windows.Forms.Button
    Friend WithEvents txtWebsitePenulis As System.Windows.Forms.TextBox
    Friend WithEvents txtEmailPenulis As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaPenulis As System.Windows.Forms.TextBox
    Friend WithEvents txtKodePenuliss As System.Windows.Forms.TextBox
    Friend WithEvents lblWebsite As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblNama As System.Windows.Forms.Label
    Friend WithEvents lblKode As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
End Class
