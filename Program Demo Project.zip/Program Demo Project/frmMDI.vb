'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class frmMDI

    Private Sub frmMDI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'form berlaku sebagai MDI (form parent)
        Me.IsMdiContainer = True
        'saat form dibuka dalam kondisi terbuka penuh
        Me.WindowState = FormWindowState.Maximized
        'pemberian judul form
        Me.Text = "Program Penjualan Buku"
        'User database yang aktif saat ini
        Me.StatusStrip1.Items(0).Text = "Login: "
        'mengaktifkan tanggal dan waktu
        Me.Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'Status tanggal dan waktu
        Me.StatusStrip1.Items(1).Text = Now()
    End Sub

    Private Sub MasterBukuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterBukuToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fb As frmBuku = New frmBuku
        fb.MdiParent = Me
        fb.Show()
    End Sub

    Private Sub MasterPenulisToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterPenulisToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fp As frmPenulis = New frmPenulis
        fp.MdiParent = Me
        fp.Show()
    End Sub

    Private Sub MasterPenerbitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterPenerbitToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fp As frmPenerbit = New frmPenerbit
        fp.MdiParent = Me
        fp.Show()
    End Sub

    Private Sub MasterSupplierToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MasterSupplierToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fs As frmSupplier = New frmSupplier
        fs.MdiParent = Me
        fs.Show()
    End Sub

    Private Sub frmMDI_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        frmLogin.Close()
    End Sub

    Private Sub KelompokBukuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KelompokBukuToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fk As frmKelompokBuku = New frmKelompokBuku
        fk.MdiParent = Me
        fk.Show()
    End Sub

    Private Sub PenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenjualanToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fp As frmPenjualan = New frmPenjualan
        fp.MdiParent = Me
        fp.Show()
    End Sub

    Private Sub TransaksiPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransaksiPembelianToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fp As frmPembelian = New frmPembelian
        fp.MdiParent = Me
        fp.Show()
    End Sub

    Private Sub TransaksiReturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransaksiReturToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim fr As frmRetur = New frmRetur
        fr.MdiParent = Me
        fr.Show()
    End Sub

    Private Sub LaporanMasterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanMasterToolStripMenuItem.Click
        'Pemanggilan form child/anak frmBuku.vb dari form MDI
        Dim rptMaster As rptMaster = New rptMaster
        rptMaster.MdiParent = Me
        rptMaster.Show()
    End Sub

    Private Sub LaporanPenjualanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanPenjualanToolStripMenuItem.Click
        Dim fpenjualan As rptPenjualan = New rptPenjualan
        fpenjualan.MdiParent = Me
        fpenjualan.Show()
    End Sub

    Private Sub PosisiStokToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PosisiStokToolStripMenuItem.Click
        Dim fstok As frmStok = New frmStok
        fstok.MdiParent = Me
        fstok.Show()
    End Sub

    Private Sub LaporanPembelianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanPembelianToolStripMenuItem.Click
        Dim frptpembelian As rptPembelian = New rptPembelian
        frptpembelian.MdiParent = Me
        frptpembelian.Show()
    End Sub

    Private Sub LaporanReturToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaporanReturToolStripMenuItem.Click
        MessageBox.Show("Cara pembuatan laporan Retur kurang labih sama dengan contoh sebelumnya")
    End Sub

    Private Sub StokAwalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StokAwalToolStripMenuItem.Click
        Dim fstokawal As frmCiptakanStokAwal = New frmCiptakanStokAwal
        fstokawal.MdiParent = Me
        fstokawal.Show()
    End Sub

    Private Sub InputkanStokAwalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InputkanStokAwalToolStripMenuItem.Click
        Dim fInputStok As frmStok = New frmStok
        fInputStok.MdiParent = Me
        fInputStok.Show()
    End Sub
End Class