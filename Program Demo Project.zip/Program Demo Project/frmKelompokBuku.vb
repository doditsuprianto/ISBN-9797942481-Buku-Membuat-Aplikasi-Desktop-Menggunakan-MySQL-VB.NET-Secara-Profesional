'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class frmKelompokBuku
    Private bMgr As BindingManagerBase
    Private da As MySqlDataAdapter = New MySqlDataAdapter()
    Private ds As DataSet = New DataSet()
    Private dtNavigator As DataTable

    Private Sub ts_first_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_first.MouseMove
        '---------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_first 
        'saat mouse mendekati icon ts_first pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi paling awal"
    End Sub

    Private Sub ts_prev_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_prev.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_prev 
        'saat mouse mendekati icon ts_prev pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi sebelumnya"
    End Sub

    Private Sub ts_next_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_next.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_next 
        'saat mouse mendekati icon ts_next pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi setelahnya"
    End Sub

    Private Sub ts_last_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_last.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_last 
        'saat mouse mendekati icon ts_last pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menampilkan baris record diposisi paling akhir"
    End Sub

    Private Sub ts_first_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_first.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_first pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_prev_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles ts_prev.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_prev pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_next_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_next.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_next pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_last_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_last.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_last pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_addnew_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_addnew.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai  StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_addnew pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_addnew_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_addnew.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_addnew 
        'saat mouse mendekati icon ts_addnew pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menambahkan data buku baru"
    End Sub

    Private Sub ts_save_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_save.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_save pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_save_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_save.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_save 
        'saat mouse mendekati icon ts_save pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menyimpan data buku baru"
    End Sub

    Private Sub ts_update_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_update.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_update pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_update_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_update.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_update 
        'saat mouse mendekati icon ts_update pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Mengubah data buku yang sudah ada"
    End Sub

    Private Sub ts_delete_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_delete.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_delete pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_delete_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_delete.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_delete 
        'saat mouse mendekati icon ts_delete pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Menghapus data buku yang sudah ada"
    End Sub

    Private Sub ts_print_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_print.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_print pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_print_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_print.MouseMove
        '--------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_print 
        'saat mouse mendekati icon ts_print pada ToolStrip1
        '--------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Fasilitas pelaporan yang berhubungan dengan data buku"
    End Sub

    Private Sub ts_browse_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_browse.MouseLeave
        '---------------------------------------------------------------
        'memberi nilai StatusStrip1 index pertama dengan string kosong 
        'saat kursor mouse meninggalkan icon ts_browse pada ToolStrip1
        '---------------------------------------------------------------
        StatusStrip1.Items(0).Text = ""
    End Sub

    Private Sub ts_browse_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ts_browse.MouseMove
        '----------------------------------------------------------------
        'memberikan penjelasan khusus tentang fungsi dari icon ts_browse 
        'saat mouse mendekati icon ts_browse pada ToolStrip1
        '----------------------------------------------------------------
        StatusStrip1.Items(0).Text = "Mencari data dengan fasilitas browsing data grid"
    End Sub

    Private Sub ts_first_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_first.Click
        '--------------------------------------------------------------
        'menempatkan pointer record pada posisi pertama (record ke-0),
        'serta menampilkan datanya ke form melalui metode Databinding
        'saat icon ts_first di klik.
        '--------------------------------------------------------------
        bMgr.Position = 0
        ts_first.Enabled = False
        ts_prev.Enabled = False
        ts_next.Enabled = True
        ts_last.Enabled = True
    End Sub

    Private Sub ts_prev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_prev.Click
        '---------------------------------------------------------------------
        'menempatkan pointer pada posisi sebelum record yang aktif saat ini,
        'serta menampilkan datanya ke form melalui metode Databinding
        'saat icon ts_prev di klik.
        '---------------------------------------------------------------------
        bMgr.Position -= 1

        '----------------------------------------------------------------------
        'jika record diposisi awal, maka icon ts_first dan ts_prev tidak aktif,
        'sedangkan icon ts_next dan ts_last aktif.
        '----------------------------------------------------------------------
        If bMgr.Position = 0 Then
            ts_first.Enabled = False
            ts_prev.Enabled = False
            ts_next.Enabled = True
            ts_last.Enabled = True
        End If

        '----------------------------------------------------------------
        'jika pointer record berada pada posisi yang bukan diawal, 
        'maka icon ts_first, ts_prev, ts_next dan ts_last semuanya aktif.
        '----------------------------------------------------------------
        If bMgr.Position > 0 Then
            ts_first.Enabled = True
            ts_prev.Enabled = True
            ts_next.Enabled = True
            ts_last.Enabled = True
        End If
    End Sub

    Private Sub ts_next_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_next.Click
        '---------------------------------------------------------------------
        'menempatkan pointer pada posisi setelah record yang aktif saat ini,
        'serta menampilkan datanya ke form melalui metode Databinding
        'saat icon ts_next di klik.
        '---------------------------------------------------------------------
        bMgr.Position += 1

        '---------------------------------------------------------------------
        'jika record diposisi terakhir, maka icon ts_first dan ts_prev aktif,
        'sedangkan icon ts_next dan ts_last tidak aktif.
        '---------------------------------------------------------------------
        If bMgr.Position = dtNavigator.Rows.Count - 1 Then
            ts_first.Enabled = True
            ts_prev.Enabled = True
            ts_next.Enabled = False
            ts_last.Enabled = False
        End If

        '-----------------------------------------------------------------
        'jika pointer record berada pada posisi yang bukan diakhir, 
        'maka icon ts_first, ts_prev, ts_next dan ts_last semuanya aktif.
        '-----------------------------------------------------------------
        If bMgr.Position < dtNavigator.Rows.Count - 1 Then
            ts_first.Enabled = True
            ts_prev.Enabled = True
            ts_next.Enabled = True
            ts_last.Enabled = True
        End If
    End Sub

    Private Sub ts_last_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_last.Click
        '----------------------------------------------------------------------
        'menempatkan pointer pada posisi paling akhir, serta menampilkan 
        'datanya ke form melalui metode Databinding saat icon ts_last di klik.
        '----------------------------------------------------------------------
        bMgr.Position = dtNavigator.Rows.Count - 1
        ts_first.Enabled = True
        ts_prev.Enabled = True
        ts_next.Enabled = False
        ts_last.Enabled = False
    End Sub

    Private Sub ts_addnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_addnew.Click
        '-----------------------------
        'memanggil method ClearForm()
        '-----------------------------
        ClearForm()

        '------------------------------------------------
        'mengaktifkan icon ts_save, ts_update, ts_delete
        'dan label lbl_Save, lbl_Update, lbl_Delete
        '------------------------------------------------
        ts_save.Enabled = True
        ts_update.Enabled = True
        ts_delete.Enabled = True
        lbl_Save.Enabled = True
        lbl_Update.Enabled = True
        lbl_Delete.Enabled = True
    End Sub

    Private Sub ClearForm()
        '------------------------------------------------------
        'Membersihkan nilai yang masih ada pada object form
        'dengan string kosong dan image picture di set nothing
        '------------------------------------------------------
        txtKodeKelompok.Text = ""
        txtNamaKelompok.Text = ""
        txtKeteranganKelompok.Text = ""

        '-------------------------------------------
        'Menempatkan cursor keyboard ke txtKodeBuku
        '-------------------------------------------
        txtKodeKelompok.Focus()
    End Sub

    Private Sub ts_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_save.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDInsert As MySqlCommand = CN.CreateCommand

        If txtKodeKelompok.Text <> "" Then
            Try
                '------------------------------------------------------------------------------------------
                'memanggil Store Proceudre MASTER_KELOMPOK_BUKU_SP dari MySQL melalui perintah CALL.
                'Dan menyertakan parameternya, yang ditandai dengan @ dan diikuti oleh nama variable.
                'Dimana urutan parameter harus sama dengan urutan parameter Store Procedure MASTER_BUKU_SP
                '------------------------------------------------------------------------------------------
                SQL = "CALL MASTER_KELOMPOK_BUKU_SP('INSERT', @kode_kelompok, @nama_kelompok, @keterangan);"
                With CMDInsert
                    .CommandText = SQL
                    .Connection = CN
                    .Transaction = SQLTrans

                    '------------------------------------------------------------------------
                    'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                    '------------------------------------------------------------------------
                    .Parameters.Add("@kode_kelompok", MySqlDbType.String, 10).Value = txtKodeKelompok.Text
                    .Parameters.Add("@nama_kelompok", MySqlDbType.VarChar, 30).Value = txtNamaKelompok.Text
                    .Parameters.Add("@keterangan", MySqlDbType.TinyText).Value = txtKeteranganKelompok.Text

                    '----------------------------
                    'Mengeksekusi Query dia atas
                    '----------------------------
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()

            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDInsert.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub ts_update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_update.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDUpdate As MySqlCommand = CN.CreateCommand

        If txtKodeKelompok.Text <> "" Then
            Try
                '------------------------------------------------------------------------------------------
                'memanggil Store Proceudre MASTER_KELOMPOK_BUKU_SP dari MySQL melalui perintah CALL.
                'Dan menyertakan parameternya, yang ditandai dengan @ dan diikuti oleh nama variable.
                'Dimana urutan parameter harus sama dengan urutan parameter Store Procedure MASTER_BUKU_SP
                '------------------------------------------------------------------------------------------
                SQL = "CALL MASTER_KELOMPOK_BUKU_SP('UPDATE', @kode_kelompok, @nama_kelompok, @keterangan);"
                With CMDUpdate
                    .CommandText = SQL
                    .Connection = CN
                    .Transaction = SQLTrans

                    '------------------------------------------------------------------------
                    'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                    '------------------------------------------------------------------------
                    .Parameters.Add("@kode_kelompok", MySqlDbType.String, 10).Value = txtKodeKelompok.Text
                    .Parameters.Add("@nama_kelompok", MySqlDbType.VarChar, 30).Value = txtNamaKelompok.Text
                    .Parameters.Add("@keterangan", MySqlDbType.TinyText).Value = txtKeteranganKelompok.Text

                    '----------------------------
                    'Mengeksekusi Query dia atas
                    '----------------------------
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

                '-----------------------------------------------------
                'memanggil method ClearForm() untuk membersihkan Form
                '-----------------------------------------------------
                ClearForm()

            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDUpdate.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub ts_delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ts_delete.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDDelete As MySqlCommand = CN.CreateCommand

        If txtKodeKelompok.Text <> "" Then
            '-------------------------------------------------------------------------
            'Windows pop-up yang bertujuan mengingatkan kita, apakah data benar-benar 
            'akan dihapus. Jika ya, maka proses penghapusan dilanjutkan.
            '-------------------------------------------------------------------------
            If MessageBox.Show("Anda yakin data buku dengan kode " & txtKodeKelompok.Text & " akan dihapus?", "Peringatan!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                Try
                    SQL = "CALL MASTER_KELOMPOK_BUKU_SP('DELETE', @kode_kelompok, '', '');"
                    With CMDDelete
                        .CommandText = SQL
                        .Transaction = SQLTrans
                        .Parameters.Add("@kode_kelompok", MySqlDbType.String, 10).Value = txtKodeKelompok.Text
                        .ExecuteNonQuery()
                    End With

                    '---------------------------------------------------------
                    'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                    'melalui perintah COMMIT transaction
                    '---------------------------------------------------------
                    SQLTrans.Commit()

                    '-----------------------------------------------------
                    'memanggil method ClearForm() untuk membersihkan Form
                    '-----------------------------------------------------
                    ClearForm()

                Catch ex As MySqlException
                    '-------------------------------------------------
                    'membatalkan eksekusi dan memberi pesan kesalahan
                    'jika terjadi kegagalan eksekusi
                    '-------------------------------------------------
                    SQLTrans.Rollback()
                    MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Finally
                    '------------------------------------------------
                    'membebaskan semua resource yang telah digunakan,
                    'baik sukses maupun gagal.
                    '------------------------------------------------
                    SQLTrans.Dispose()
                    CMDDelete.Dispose()
                    CN.Close()
                    CN = Nothing
                End Try
            End If
        End If
    End Sub

    Private Sub Tampil_Kelompok_Buku()
        '-------------------------------------------------------------
        'menampilkan data saat cursor keyboard keluar dari txtKodeBuku
        '-------------------------------------------------------------

        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim DataReader As MySqlDataReader = Nothing
        Dim CMDTampilData As MySqlCommand = CN.CreateCommand()

        Try
            If txtKodeKelompok.Text <> "" Then
                SQL = "SELECT * FROM kelompok_buku_tb WHERE kode_kelompok='" & txtKodeKelompok.Text & "'"
                CMDTampilData.CommandText = SQL
                DataReader = CMDTampilData.ExecuteReader()

                If DataReader.Read() Then
                    '--------------------------------------------------------
                    'memberi nilai pada TextBox sesuai nama kolom DataReader
                    'yang diperoleh dari view TAMPIL_BUKU_VW
                    '--------------------------------------------------------
                    txtNamaKelompok.Text = DataReader("nama_kelompok").ToString
                    txtKeteranganKelompok.Text = DataReader("keterangan").ToString

                    ts_save.Enabled = False
                    lbl_Save.Enabled = False
                    ts_update.Enabled = True
                    lbl_Update.Enabled = True
                    ts_delete.Enabled = True
                    lbl_Delete.Enabled = True
                Else
                    ts_save.Enabled = True
                    lbl_Save.Enabled = True
                    ts_update.Enabled = False
                    lbl_Update.Enabled = False
                    ts_delete.Enabled = False
                    lbl_Delete.Enabled = False
                End If
            End If

        Catch ex As MySqlException
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            '-----------------------------------------------
            'membebaskan semua resource yang telah terpakai
            '-----------------------------------------------
            'DataReader.Close()
            CMDTampilData.Dispose()
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub txtKodeKelompok_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtKodeKelompok.Leave
        Tampil_Kelompok_Buku()
    End Sub

    Private Sub frmKelompokBuku_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtKodeKelompok.AllowDrop = True
        ToolStripStatusLabel1.Text = ""
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Try
            '---------------------------------------------------
            'melimpahkan semua record kelompok_buku_tb ke DataSet
            '---------------------------------------------------
            da = New MySqlDataAdapter("SELECT * FROM kelompok_buku_tb;", CN)
            da.Fill(ds, "kelompok_buku_tb")
            dtNavigator = ds.Tables("kelompok_buku_tb")

            '---------------------------------------------------------
            'membuat DataBinding masing-masing kolom untuk direkatkan 
            'pada object textbox yang sesuai
            '---------------------------------------------------------
            txtKodeKelompok.DataBindings.Add("text", ds, "kelompok_buku_tb.kode_kelompok")
            txtNamaKelompok.DataBindings.Add("text", ds, "kelompok_buku_tb.nama_kelompok")
            txtKeteranganKelompok.DataBindings.Add("text", ds, "kelompok_buku_tb.keterangan")

            bMgr = MyBase.BindingContext(ds, "kelompok_buku_tb")

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub btn_BrowseKodeSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_BrowseKodeSupplier.Click
        '----------------------------------------------------------
        'memanggil form frmBrowse dan menampilkan TabPage keempat, 
        'tab_Browse.SelectTab(3)
        '----------------------------------------------------------
        Dim fb As frmBrowse = New frmBrowse
        fb.MdiParent = frmMDI
        fb.Show()
        fb.tab_Browse.SelectTab(1)
    End Sub

    Private Sub mnu_BrowseSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_BrowseSupplier.Click
        '----------------------------------------------------------
        'memanggil form frmBrowse dan menampilkan TabPage keempat, 
        'tab_Browse.SelectTab(3)
        '----------------------------------------------------------
        Dim fb As frmBrowse = New frmBrowse
        fb.MdiParent = frmMDI
        fb.Show()
        fb.tab_Browse.SelectTab(1)
    End Sub

    Private Sub txtKodeKelompok_DragDrop(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtKodeKelompok.DragDrop
        txtKodeKelompok.Text = e.Data.GetData(DataFormats.Text)
        Tampil_Kelompok_Buku()
    End Sub

    Private Sub txtKodeKelompok_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles txtKodeKelompok.DragEnter
        If (e.Data.GetDataPresent(DataFormats.Text)) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub
End Class