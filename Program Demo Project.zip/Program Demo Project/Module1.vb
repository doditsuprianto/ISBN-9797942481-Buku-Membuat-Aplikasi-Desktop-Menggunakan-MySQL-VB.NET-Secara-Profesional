'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Imports System.Text.RegularExpressions
Imports System.IO
Imports System.Drawing.Bitmap

Module Module1
    Public db, user, pwd As String
    Public myConnectionString As String

    Public CN As New MySqlConnection 'Deklarasi variable object Connection ke MySQl
    Public CMD As New MySqlCommand 'Deklarasi variable object Command
    Public MyAdapter As New MySqlDataAdapter() 'Deklarasi variable object adapter reader
    Public MyDataset As New DataSet() 'Deklarasi variable object dataset
    Public SQL As String 'Deklarasi variable string global untuk tampungan script SQL
    Public brw As String

    Public strImgName As String
    Public imageBytes As Byte = Nothing
    Public FileSize As UInt32
    Public rawData() As Byte
    Public fs As FileStream

    Public Sub Alphabet_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input alphabet saja
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim alphabetPattern As String = "^[a-zA-Z]+$"

        If Regex.IsMatch(Karakter.ToString, alphabetPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Web_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input email
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim webPattern As String = "^https?://([\w-]+\.)+[\w-]+(/ [\w-./?%=]*)?$"

        If Regex.IsMatch(Karakter.ToString, webPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Email_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input email
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim emailPattern As String = "^([0-9a-zA-Z]+[-._+&])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$"

        If Regex.IsMatch(Karakter.ToString, emailPattern) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

    Public Sub Numerik_Valid(ByVal Karakter As String, ByVal tb As Object)
        '-------------------------------------------
        'pengecekan keabsahan input numerik
        'melalui pola pencocokan Regular Expression
        '-------------------------------------------
        Dim numDouble As String = "[-+]?([0-9]*\.)?[0-9]+([eE][-+]?[0-9]+)?"

        If Regex.IsMatch(Karakter.ToString, numDouble) = True Then
            tb.BackColor = Color.White
        Else
            tb.BackColor = Color.Gold
            Beep()
            MessageBox.Show("Inputan tidak valid, mohon dicek ulang!", "Terjadi Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tb.Focus()
        End If
    End Sub

End Module
