<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBrowse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tab_Browse = New System.Windows.Forms.TabControl
        Me.tp_Buku = New System.Windows.Forms.TabPage
        Me.dgv_Buku = New System.Windows.Forms.DataGridView
        Me.gb_Buku = New System.Windows.Forms.GroupBox
        Me.rd_Penerbit = New System.Windows.Forms.RadioButton
        Me.rd_Penulis = New System.Windows.Forms.RadioButton
        Me.rd_judul = New System.Windows.Forms.RadioButton
        Me.rb_KodeBuku = New System.Windows.Forms.RadioButton
        Me.btn_CariBuku = New System.Windows.Forms.Button
        Me.txtCariBuku = New System.Windows.Forms.TextBox
        Me.tp_KelompokBuku = New System.Windows.Forms.TabPage
        Me.dgv_KelompokBuku = New System.Windows.Forms.DataGridView
        Me.gb_KelompokBuku = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btn_CariKelompok = New System.Windows.Forms.Button
        Me.txtCariKelompok = New System.Windows.Forms.TextBox
        Me.tp_Penulis = New System.Windows.Forms.TabPage
        Me.dgv_Penulis = New System.Windows.Forms.DataGridView
        Me.gb_Penulis = New System.Windows.Forms.GroupBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btn_CariPenulis = New System.Windows.Forms.Button
        Me.txtCariPenulis = New System.Windows.Forms.TextBox
        Me.tp_Penerbit = New System.Windows.Forms.TabPage
        Me.dgv_Penerbit = New System.Windows.Forms.DataGridView
        Me.gb_Penerbit = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btn_CariPenerbit = New System.Windows.Forms.Button
        Me.txtCariPenerbit = New System.Windows.Forms.TextBox
        Me.tp_Supplier = New System.Windows.Forms.TabPage
        Me.dgv_Supplier = New System.Windows.Forms.DataGridView
        Me.gb_Supplier = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.btn_CariSupplier = New System.Windows.Forms.Button
        Me.txtCariSupplier = New System.Windows.Forms.TextBox
        Me.tp_penjualan = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.dgv_PenjualanDetil = New System.Windows.Forms.DataGridView
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dgv_PenjualanHeader = New System.Windows.Forms.DataGridView
        Me.gb_Penjualan = New System.Windows.Forms.GroupBox
        Me.btn_CariJual = New System.Windows.Forms.Button
        Me.date_TglJual2 = New System.Windows.Forms.DateTimePicker
        Me.date_TglJual1 = New System.Windows.Forms.DateTimePicker
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.tp_Pembelian = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.dgv_PembelianDetil = New System.Windows.Forms.DataGridView
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.dgv_PembelianHeader = New System.Windows.Forms.DataGridView
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.btn_CariPembelian = New System.Windows.Forms.Button
        Me.date_TglBeli2 = New System.Windows.Forms.DateTimePicker
        Me.date_TglBeli1 = New System.Windows.Forms.DateTimePicker
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.tp_Retur = New System.Windows.Forms.TabPage
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.dgv_ReturDetil = New System.Windows.Forms.DataGridView
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.dgv_ReturHeader = New System.Windows.Forms.DataGridView
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.btn_CariRetur = New System.Windows.Forms.Button
        Me.date_Retur2 = New System.Windows.Forms.DateTimePicker
        Me.date_Retur1 = New System.Windows.Forms.DateTimePicker
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.tab_Browse.SuspendLayout()
        Me.tp_Buku.SuspendLayout()
        CType(Me.dgv_Buku, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Buku.SuspendLayout()
        Me.tp_KelompokBuku.SuspendLayout()
        CType(Me.dgv_KelompokBuku, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_KelompokBuku.SuspendLayout()
        Me.tp_Penulis.SuspendLayout()
        CType(Me.dgv_Penulis, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Penulis.SuspendLayout()
        Me.tp_Penerbit.SuspendLayout()
        CType(Me.dgv_Penerbit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Penerbit.SuspendLayout()
        Me.tp_Supplier.SuspendLayout()
        CType(Me.dgv_Supplier, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Supplier.SuspendLayout()
        Me.tp_penjualan.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgv_PenjualanDetil, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv_PenjualanHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Penjualan.SuspendLayout()
        Me.tp_Pembelian.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgv_PembelianDetil, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.dgv_PembelianHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.tp_Retur.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.dgv_ReturDetil, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.dgv_ReturHeader, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'tab_Browse
        '
        Me.tab_Browse.Controls.Add(Me.tp_Buku)
        Me.tab_Browse.Controls.Add(Me.tp_KelompokBuku)
        Me.tab_Browse.Controls.Add(Me.tp_Penulis)
        Me.tab_Browse.Controls.Add(Me.tp_Penerbit)
        Me.tab_Browse.Controls.Add(Me.tp_Supplier)
        Me.tab_Browse.Controls.Add(Me.tp_penjualan)
        Me.tab_Browse.Controls.Add(Me.tp_Pembelian)
        Me.tab_Browse.Controls.Add(Me.tp_Retur)
        Me.tab_Browse.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tab_Browse.Location = New System.Drawing.Point(0, 0)
        Me.tab_Browse.Name = "tab_Browse"
        Me.tab_Browse.SelectedIndex = 0
        Me.tab_Browse.Size = New System.Drawing.Size(649, 426)
        Me.tab_Browse.TabIndex = 0
        '
        'tp_Buku
        '
        Me.tp_Buku.Controls.Add(Me.dgv_Buku)
        Me.tp_Buku.Controls.Add(Me.gb_Buku)
        Me.tp_Buku.Location = New System.Drawing.Point(4, 22)
        Me.tp_Buku.Name = "tp_Buku"
        Me.tp_Buku.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Buku.Size = New System.Drawing.Size(641, 400)
        Me.tp_Buku.TabIndex = 0
        Me.tp_Buku.Text = "Buku"
        Me.tp_Buku.UseVisualStyleBackColor = True
        '
        'dgv_Buku
        '
        Me.dgv_Buku.AllowUserToAddRows = False
        Me.dgv_Buku.AllowUserToDeleteRows = False
        Me.dgv_Buku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Buku.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_Buku.Location = New System.Drawing.Point(3, 62)
        Me.dgv_Buku.MultiSelect = False
        Me.dgv_Buku.Name = "dgv_Buku"
        Me.dgv_Buku.ReadOnly = True
        Me.dgv_Buku.Size = New System.Drawing.Size(635, 335)
        Me.dgv_Buku.TabIndex = 1
        '
        'gb_Buku
        '
        Me.gb_Buku.Controls.Add(Me.rd_Penerbit)
        Me.gb_Buku.Controls.Add(Me.rd_Penulis)
        Me.gb_Buku.Controls.Add(Me.rd_judul)
        Me.gb_Buku.Controls.Add(Me.rb_KodeBuku)
        Me.gb_Buku.Controls.Add(Me.btn_CariBuku)
        Me.gb_Buku.Controls.Add(Me.txtCariBuku)
        Me.gb_Buku.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_Buku.Location = New System.Drawing.Point(3, 3)
        Me.gb_Buku.Name = "gb_Buku"
        Me.gb_Buku.Size = New System.Drawing.Size(635, 59)
        Me.gb_Buku.TabIndex = 0
        Me.gb_Buku.TabStop = False
        Me.gb_Buku.Text = "Pencarian"
        '
        'rd_Penerbit
        '
        Me.rd_Penerbit.AutoSize = True
        Me.rd_Penerbit.Location = New System.Drawing.Point(220, 25)
        Me.rd_Penerbit.Name = "rd_Penerbit"
        Me.rd_Penerbit.Size = New System.Drawing.Size(64, 17)
        Me.rd_Penerbit.TabIndex = 7
        Me.rd_Penerbit.Text = "Penerbit"
        Me.rd_Penerbit.UseVisualStyleBackColor = True
        '
        'rd_Penulis
        '
        Me.rd_Penulis.AutoSize = True
        Me.rd_Penulis.Location = New System.Drawing.Point(155, 25)
        Me.rd_Penulis.Name = "rd_Penulis"
        Me.rd_Penulis.Size = New System.Drawing.Size(59, 17)
        Me.rd_Penulis.TabIndex = 6
        Me.rd_Penulis.Text = "Penulis"
        Me.rd_Penulis.UseVisualStyleBackColor = True
        '
        'rd_judul
        '
        Me.rd_judul.AutoSize = True
        Me.rd_judul.Location = New System.Drawing.Point(99, 25)
        Me.rd_judul.Name = "rd_judul"
        Me.rd_judul.Size = New System.Drawing.Size(50, 17)
        Me.rd_judul.TabIndex = 5
        Me.rd_judul.Text = "Judul"
        Me.rd_judul.UseVisualStyleBackColor = True
        '
        'rb_KodeBuku
        '
        Me.rb_KodeBuku.AutoSize = True
        Me.rb_KodeBuku.Location = New System.Drawing.Point(15, 25)
        Me.rb_KodeBuku.Name = "rb_KodeBuku"
        Me.rb_KodeBuku.Size = New System.Drawing.Size(78, 17)
        Me.rb_KodeBuku.TabIndex = 4
        Me.rb_KodeBuku.Text = "Kode Buku"
        Me.rb_KodeBuku.UseVisualStyleBackColor = True
        '
        'btn_CariBuku
        '
        Me.btn_CariBuku.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariBuku.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariBuku.Location = New System.Drawing.Point(581, 20)
        Me.btn_CariBuku.Name = "btn_CariBuku"
        Me.btn_CariBuku.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariBuku.TabIndex = 3
        Me.btn_CariBuku.Text = "Cari"
        Me.btn_CariBuku.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariBuku.UseVisualStyleBackColor = True
        '
        'txtCariBuku
        '
        Me.txtCariBuku.Location = New System.Drawing.Point(290, 24)
        Me.txtCariBuku.Name = "txtCariBuku"
        Me.txtCariBuku.Size = New System.Drawing.Size(285, 20)
        Me.txtCariBuku.TabIndex = 2
        '
        'tp_KelompokBuku
        '
        Me.tp_KelompokBuku.Controls.Add(Me.dgv_KelompokBuku)
        Me.tp_KelompokBuku.Controls.Add(Me.gb_KelompokBuku)
        Me.tp_KelompokBuku.Location = New System.Drawing.Point(4, 22)
        Me.tp_KelompokBuku.Name = "tp_KelompokBuku"
        Me.tp_KelompokBuku.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_KelompokBuku.Size = New System.Drawing.Size(641, 400)
        Me.tp_KelompokBuku.TabIndex = 1
        Me.tp_KelompokBuku.Text = "Kelompok Buku"
        Me.tp_KelompokBuku.UseVisualStyleBackColor = True
        '
        'dgv_KelompokBuku
        '
        Me.dgv_KelompokBuku.AllowUserToAddRows = False
        Me.dgv_KelompokBuku.AllowUserToDeleteRows = False
        Me.dgv_KelompokBuku.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_KelompokBuku.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_KelompokBuku.Location = New System.Drawing.Point(3, 57)
        Me.dgv_KelompokBuku.Name = "dgv_KelompokBuku"
        Me.dgv_KelompokBuku.ReadOnly = True
        Me.dgv_KelompokBuku.Size = New System.Drawing.Size(635, 340)
        Me.dgv_KelompokBuku.TabIndex = 3
        '
        'gb_KelompokBuku
        '
        Me.gb_KelompokBuku.Controls.Add(Me.Label1)
        Me.gb_KelompokBuku.Controls.Add(Me.btn_CariKelompok)
        Me.gb_KelompokBuku.Controls.Add(Me.txtCariKelompok)
        Me.gb_KelompokBuku.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_KelompokBuku.Location = New System.Drawing.Point(3, 3)
        Me.gb_KelompokBuku.Name = "gb_KelompokBuku"
        Me.gb_KelompokBuku.Size = New System.Drawing.Size(635, 54)
        Me.gb_KelompokBuku.TabIndex = 2
        Me.gb_KelompokBuku.TabStop = False
        Me.gb_KelompokBuku.Text = "Pencarian"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Kelompok Buku:"
        '
        'btn_CariKelompok
        '
        Me.btn_CariKelompok.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariKelompok.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariKelompok.Location = New System.Drawing.Point(388, 15)
        Me.btn_CariKelompok.Name = "btn_CariKelompok"
        Me.btn_CariKelompok.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariKelompok.TabIndex = 5
        Me.btn_CariKelompok.Text = "Cari"
        Me.btn_CariKelompok.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariKelompok.UseVisualStyleBackColor = True
        '
        'txtCariKelompok
        '
        Me.txtCariKelompok.Location = New System.Drawing.Point(97, 19)
        Me.txtCariKelompok.Name = "txtCariKelompok"
        Me.txtCariKelompok.Size = New System.Drawing.Size(285, 20)
        Me.txtCariKelompok.TabIndex = 4
        '
        'tp_Penulis
        '
        Me.tp_Penulis.Controls.Add(Me.dgv_Penulis)
        Me.tp_Penulis.Controls.Add(Me.gb_Penulis)
        Me.tp_Penulis.Location = New System.Drawing.Point(4, 22)
        Me.tp_Penulis.Name = "tp_Penulis"
        Me.tp_Penulis.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Penulis.Size = New System.Drawing.Size(641, 400)
        Me.tp_Penulis.TabIndex = 2
        Me.tp_Penulis.Text = "Penulis"
        Me.tp_Penulis.UseVisualStyleBackColor = True
        '
        'dgv_Penulis
        '
        Me.dgv_Penulis.AllowUserToAddRows = False
        Me.dgv_Penulis.AllowUserToDeleteRows = False
        Me.dgv_Penulis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Penulis.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_Penulis.Location = New System.Drawing.Point(3, 57)
        Me.dgv_Penulis.Name = "dgv_Penulis"
        Me.dgv_Penulis.ReadOnly = True
        Me.dgv_Penulis.Size = New System.Drawing.Size(635, 340)
        Me.dgv_Penulis.TabIndex = 3
        '
        'gb_Penulis
        '
        Me.gb_Penulis.Controls.Add(Me.Label2)
        Me.gb_Penulis.Controls.Add(Me.btn_CariPenulis)
        Me.gb_Penulis.Controls.Add(Me.txtCariPenulis)
        Me.gb_Penulis.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_Penulis.Location = New System.Drawing.Point(3, 3)
        Me.gb_Penulis.Name = "gb_Penulis"
        Me.gb_Penulis.Size = New System.Drawing.Size(635, 54)
        Me.gb_Penulis.TabIndex = 2
        Me.gb_Penulis.TabStop = False
        Me.gb_Penulis.Text = "Pencarian"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Penulis :"
        '
        'btn_CariPenulis
        '
        Me.btn_CariPenulis.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariPenulis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariPenulis.Location = New System.Drawing.Point(352, 15)
        Me.btn_CariPenulis.Name = "btn_CariPenulis"
        Me.btn_CariPenulis.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariPenulis.TabIndex = 8
        Me.btn_CariPenulis.Text = "Cari"
        Me.btn_CariPenulis.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariPenulis.UseVisualStyleBackColor = True
        '
        'txtCariPenulis
        '
        Me.txtCariPenulis.Location = New System.Drawing.Point(61, 19)
        Me.txtCariPenulis.Name = "txtCariPenulis"
        Me.txtCariPenulis.Size = New System.Drawing.Size(285, 20)
        Me.txtCariPenulis.TabIndex = 7
        '
        'tp_Penerbit
        '
        Me.tp_Penerbit.Controls.Add(Me.dgv_Penerbit)
        Me.tp_Penerbit.Controls.Add(Me.gb_Penerbit)
        Me.tp_Penerbit.Location = New System.Drawing.Point(4, 22)
        Me.tp_Penerbit.Name = "tp_Penerbit"
        Me.tp_Penerbit.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Penerbit.Size = New System.Drawing.Size(641, 400)
        Me.tp_Penerbit.TabIndex = 3
        Me.tp_Penerbit.Text = "Penerbit"
        Me.tp_Penerbit.UseVisualStyleBackColor = True
        '
        'dgv_Penerbit
        '
        Me.dgv_Penerbit.AllowUserToAddRows = False
        Me.dgv_Penerbit.AllowUserToDeleteRows = False
        Me.dgv_Penerbit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Penerbit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_Penerbit.Location = New System.Drawing.Point(3, 57)
        Me.dgv_Penerbit.Name = "dgv_Penerbit"
        Me.dgv_Penerbit.ReadOnly = True
        Me.dgv_Penerbit.Size = New System.Drawing.Size(635, 340)
        Me.dgv_Penerbit.TabIndex = 3
        '
        'gb_Penerbit
        '
        Me.gb_Penerbit.Controls.Add(Me.Label3)
        Me.gb_Penerbit.Controls.Add(Me.btn_CariPenerbit)
        Me.gb_Penerbit.Controls.Add(Me.txtCariPenerbit)
        Me.gb_Penerbit.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_Penerbit.Location = New System.Drawing.Point(3, 3)
        Me.gb_Penerbit.Name = "gb_Penerbit"
        Me.gb_Penerbit.Size = New System.Drawing.Size(635, 54)
        Me.gb_Penerbit.TabIndex = 2
        Me.gb_Penerbit.TabStop = False
        Me.gb_Penerbit.Text = "Pencarian"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Penerbit"
        '
        'btn_CariPenerbit
        '
        Me.btn_CariPenerbit.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariPenerbit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariPenerbit.Location = New System.Drawing.Point(351, 15)
        Me.btn_CariPenerbit.Name = "btn_CariPenerbit"
        Me.btn_CariPenerbit.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariPenerbit.TabIndex = 8
        Me.btn_CariPenerbit.Text = "Cari"
        Me.btn_CariPenerbit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariPenerbit.UseVisualStyleBackColor = True
        '
        'txtCariPenerbit
        '
        Me.txtCariPenerbit.Location = New System.Drawing.Point(60, 19)
        Me.txtCariPenerbit.Name = "txtCariPenerbit"
        Me.txtCariPenerbit.Size = New System.Drawing.Size(285, 20)
        Me.txtCariPenerbit.TabIndex = 7
        '
        'tp_Supplier
        '
        Me.tp_Supplier.Controls.Add(Me.dgv_Supplier)
        Me.tp_Supplier.Controls.Add(Me.gb_Supplier)
        Me.tp_Supplier.Location = New System.Drawing.Point(4, 22)
        Me.tp_Supplier.Name = "tp_Supplier"
        Me.tp_Supplier.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Supplier.Size = New System.Drawing.Size(641, 400)
        Me.tp_Supplier.TabIndex = 4
        Me.tp_Supplier.Text = "Supplier"
        Me.tp_Supplier.UseVisualStyleBackColor = True
        '
        'dgv_Supplier
        '
        Me.dgv_Supplier.AllowUserToAddRows = False
        Me.dgv_Supplier.AllowUserToDeleteRows = False
        Me.dgv_Supplier.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Supplier.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_Supplier.Location = New System.Drawing.Point(3, 57)
        Me.dgv_Supplier.Name = "dgv_Supplier"
        Me.dgv_Supplier.ReadOnly = True
        Me.dgv_Supplier.Size = New System.Drawing.Size(635, 340)
        Me.dgv_Supplier.TabIndex = 3
        '
        'gb_Supplier
        '
        Me.gb_Supplier.Controls.Add(Me.Label4)
        Me.gb_Supplier.Controls.Add(Me.btn_CariSupplier)
        Me.gb_Supplier.Controls.Add(Me.txtCariSupplier)
        Me.gb_Supplier.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_Supplier.Location = New System.Drawing.Point(3, 3)
        Me.gb_Supplier.Name = "gb_Supplier"
        Me.gb_Supplier.Size = New System.Drawing.Size(635, 54)
        Me.gb_Supplier.TabIndex = 2
        Me.gb_Supplier.TabStop = False
        Me.gb_Supplier.Text = "Pencarian"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Supplier:"
        '
        'btn_CariSupplier
        '
        Me.btn_CariSupplier.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariSupplier.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariSupplier.Location = New System.Drawing.Point(353, 15)
        Me.btn_CariSupplier.Name = "btn_CariSupplier"
        Me.btn_CariSupplier.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariSupplier.TabIndex = 11
        Me.btn_CariSupplier.Text = "Cari"
        Me.btn_CariSupplier.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariSupplier.UseVisualStyleBackColor = True
        '
        'txtCariSupplier
        '
        Me.txtCariSupplier.Location = New System.Drawing.Point(62, 19)
        Me.txtCariSupplier.Name = "txtCariSupplier"
        Me.txtCariSupplier.Size = New System.Drawing.Size(285, 20)
        Me.txtCariSupplier.TabIndex = 10
        '
        'tp_penjualan
        '
        Me.tp_penjualan.Controls.Add(Me.GroupBox2)
        Me.tp_penjualan.Controls.Add(Me.GroupBox1)
        Me.tp_penjualan.Controls.Add(Me.gb_Penjualan)
        Me.tp_penjualan.Location = New System.Drawing.Point(4, 22)
        Me.tp_penjualan.Name = "tp_penjualan"
        Me.tp_penjualan.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_penjualan.Size = New System.Drawing.Size(641, 400)
        Me.tp_penjualan.TabIndex = 5
        Me.tp_penjualan.Text = "Penjualan"
        Me.tp_penjualan.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dgv_PenjualanDetil)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(3, 189)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(635, 208)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Detil Penjualan"
        '
        'dgv_PenjualanDetil
        '
        Me.dgv_PenjualanDetil.AllowUserToAddRows = False
        Me.dgv_PenjualanDetil.AllowUserToDeleteRows = False
        Me.dgv_PenjualanDetil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_PenjualanDetil.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_PenjualanDetil.Location = New System.Drawing.Point(3, 16)
        Me.dgv_PenjualanDetil.Name = "dgv_PenjualanDetil"
        Me.dgv_PenjualanDetil.ReadOnly = True
        Me.dgv_PenjualanDetil.Size = New System.Drawing.Size(629, 189)
        Me.dgv_PenjualanDetil.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dgv_PenjualanHeader)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(3, 57)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(635, 132)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Nota Penjualan"
        '
        'dgv_PenjualanHeader
        '
        Me.dgv_PenjualanHeader.AllowUserToAddRows = False
        Me.dgv_PenjualanHeader.AllowUserToDeleteRows = False
        Me.dgv_PenjualanHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_PenjualanHeader.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_PenjualanHeader.Location = New System.Drawing.Point(3, 16)
        Me.dgv_PenjualanHeader.Name = "dgv_PenjualanHeader"
        Me.dgv_PenjualanHeader.ReadOnly = True
        Me.dgv_PenjualanHeader.Size = New System.Drawing.Size(629, 113)
        Me.dgv_PenjualanHeader.TabIndex = 0
        '
        'gb_Penjualan
        '
        Me.gb_Penjualan.Controls.Add(Me.btn_CariJual)
        Me.gb_Penjualan.Controls.Add(Me.date_TglJual2)
        Me.gb_Penjualan.Controls.Add(Me.date_TglJual1)
        Me.gb_Penjualan.Controls.Add(Me.Label6)
        Me.gb_Penjualan.Controls.Add(Me.Label5)
        Me.gb_Penjualan.Dock = System.Windows.Forms.DockStyle.Top
        Me.gb_Penjualan.Location = New System.Drawing.Point(3, 3)
        Me.gb_Penjualan.Name = "gb_Penjualan"
        Me.gb_Penjualan.Size = New System.Drawing.Size(635, 54)
        Me.gb_Penjualan.TabIndex = 2
        Me.gb_Penjualan.TabStop = False
        Me.gb_Penjualan.Text = "Pencarian"
        '
        'btn_CariJual
        '
        Me.btn_CariJual.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariJual.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariJual.Location = New System.Drawing.Point(350, 19)
        Me.btn_CariJual.Name = "btn_CariJual"
        Me.btn_CariJual.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariJual.TabIndex = 12
        Me.btn_CariJual.Text = "Cari"
        Me.btn_CariJual.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariJual.UseVisualStyleBackColor = True
        '
        'date_TglJual2
        '
        Me.date_TglJual2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_TglJual2.Location = New System.Drawing.Point(237, 23)
        Me.date_TglJual2.Name = "date_TglJual2"
        Me.date_TglJual2.Size = New System.Drawing.Size(107, 20)
        Me.date_TglJual2.TabIndex = 3
        '
        'date_TglJual1
        '
        Me.date_TglJual1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_TglJual1.Location = New System.Drawing.Point(95, 23)
        Me.date_TglJual1.Name = "date_TglJual1"
        Me.date_TglJual1.Size = New System.Drawing.Size(107, 20)
        Me.date_TglJual1.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(208, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(23, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "s/d"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Tanggal Jual:"
        '
        'tp_Pembelian
        '
        Me.tp_Pembelian.Controls.Add(Me.GroupBox3)
        Me.tp_Pembelian.Controls.Add(Me.GroupBox4)
        Me.tp_Pembelian.Controls.Add(Me.GroupBox5)
        Me.tp_Pembelian.Location = New System.Drawing.Point(4, 22)
        Me.tp_Pembelian.Name = "tp_Pembelian"
        Me.tp_Pembelian.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Pembelian.Size = New System.Drawing.Size(641, 400)
        Me.tp_Pembelian.TabIndex = 6
        Me.tp_Pembelian.Text = "Pembelian"
        Me.tp_Pembelian.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dgv_PembelianDetil)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox3.Location = New System.Drawing.Point(3, 189)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(635, 208)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Detil Pembelian"
        '
        'dgv_PembelianDetil
        '
        Me.dgv_PembelianDetil.AllowUserToAddRows = False
        Me.dgv_PembelianDetil.AllowUserToDeleteRows = False
        Me.dgv_PembelianDetil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_PembelianDetil.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_PembelianDetil.Location = New System.Drawing.Point(3, 16)
        Me.dgv_PembelianDetil.Name = "dgv_PembelianDetil"
        Me.dgv_PembelianDetil.ReadOnly = True
        Me.dgv_PembelianDetil.Size = New System.Drawing.Size(629, 189)
        Me.dgv_PembelianDetil.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.dgv_PembelianHeader)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox4.Location = New System.Drawing.Point(3, 57)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(635, 132)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Nota Pembelian"
        '
        'dgv_PembelianHeader
        '
        Me.dgv_PembelianHeader.AllowUserToAddRows = False
        Me.dgv_PembelianHeader.AllowUserToDeleteRows = False
        Me.dgv_PembelianHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_PembelianHeader.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_PembelianHeader.Location = New System.Drawing.Point(3, 16)
        Me.dgv_PembelianHeader.Name = "dgv_PembelianHeader"
        Me.dgv_PembelianHeader.ReadOnly = True
        Me.dgv_PembelianHeader.Size = New System.Drawing.Size(629, 113)
        Me.dgv_PembelianHeader.TabIndex = 0
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btn_CariPembelian)
        Me.GroupBox5.Controls.Add(Me.date_TglBeli2)
        Me.GroupBox5.Controls.Add(Me.date_TglBeli1)
        Me.GroupBox5.Controls.Add(Me.Label7)
        Me.GroupBox5.Controls.Add(Me.Label8)
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox5.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(635, 54)
        Me.GroupBox5.TabIndex = 5
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Pencarian"
        '
        'btn_CariPembelian
        '
        Me.btn_CariPembelian.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariPembelian.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariPembelian.Location = New System.Drawing.Point(352, 19)
        Me.btn_CariPembelian.Name = "btn_CariPembelian"
        Me.btn_CariPembelian.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariPembelian.TabIndex = 12
        Me.btn_CariPembelian.Text = "Cari"
        Me.btn_CariPembelian.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariPembelian.UseVisualStyleBackColor = True
        '
        'date_TglBeli2
        '
        Me.date_TglBeli2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_TglBeli2.Location = New System.Drawing.Point(238, 23)
        Me.date_TglBeli2.Name = "date_TglBeli2"
        Me.date_TglBeli2.Size = New System.Drawing.Size(108, 20)
        Me.date_TglBeli2.TabIndex = 3
        '
        'date_TglBeli1
        '
        Me.date_TglBeli1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_TglBeli1.Location = New System.Drawing.Point(95, 23)
        Me.date_TglBeli1.Name = "date_TglBeli1"
        Me.date_TglBeli1.Size = New System.Drawing.Size(108, 20)
        Me.date_TglBeli1.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(209, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(23, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "s/d"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(17, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(66, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Tanggal Beli"
        '
        'tp_Retur
        '
        Me.tp_Retur.Controls.Add(Me.GroupBox6)
        Me.tp_Retur.Controls.Add(Me.GroupBox7)
        Me.tp_Retur.Controls.Add(Me.GroupBox8)
        Me.tp_Retur.Location = New System.Drawing.Point(4, 22)
        Me.tp_Retur.Name = "tp_Retur"
        Me.tp_Retur.Padding = New System.Windows.Forms.Padding(3)
        Me.tp_Retur.Size = New System.Drawing.Size(641, 400)
        Me.tp_Retur.TabIndex = 7
        Me.tp_Retur.Text = "Retur"
        Me.tp_Retur.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.dgv_ReturDetil)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox6.Location = New System.Drawing.Point(3, 189)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(635, 208)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Detil Retur"
        '
        'dgv_ReturDetil
        '
        Me.dgv_ReturDetil.AllowUserToAddRows = False
        Me.dgv_ReturDetil.AllowUserToDeleteRows = False
        Me.dgv_ReturDetil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_ReturDetil.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_ReturDetil.Location = New System.Drawing.Point(3, 16)
        Me.dgv_ReturDetil.Name = "dgv_ReturDetil"
        Me.dgv_ReturDetil.ReadOnly = True
        Me.dgv_ReturDetil.Size = New System.Drawing.Size(629, 189)
        Me.dgv_ReturDetil.TabIndex = 0
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.dgv_ReturHeader)
        Me.GroupBox7.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox7.Location = New System.Drawing.Point(3, 57)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(635, 132)
        Me.GroupBox7.TabIndex = 6
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Nota Retur"
        '
        'dgv_ReturHeader
        '
        Me.dgv_ReturHeader.AllowUserToAddRows = False
        Me.dgv_ReturHeader.AllowUserToDeleteRows = False
        Me.dgv_ReturHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_ReturHeader.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_ReturHeader.Location = New System.Drawing.Point(3, 16)
        Me.dgv_ReturHeader.Name = "dgv_ReturHeader"
        Me.dgv_ReturHeader.ReadOnly = True
        Me.dgv_ReturHeader.Size = New System.Drawing.Size(629, 113)
        Me.dgv_ReturHeader.TabIndex = 0
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.btn_CariRetur)
        Me.GroupBox8.Controls.Add(Me.date_Retur2)
        Me.GroupBox8.Controls.Add(Me.date_Retur1)
        Me.GroupBox8.Controls.Add(Me.Label9)
        Me.GroupBox8.Controls.Add(Me.Label10)
        Me.GroupBox8.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox8.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(635, 54)
        Me.GroupBox8.TabIndex = 5
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Pencarian"
        '
        'btn_CariRetur
        '
        Me.btn_CariRetur.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.btn_CariRetur.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_CariRetur.Location = New System.Drawing.Point(351, 19)
        Me.btn_CariRetur.Name = "btn_CariRetur"
        Me.btn_CariRetur.Size = New System.Drawing.Size(48, 27)
        Me.btn_CariRetur.TabIndex = 12
        Me.btn_CariRetur.Text = "Cari"
        Me.btn_CariRetur.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_CariRetur.UseVisualStyleBackColor = True
        '
        'date_Retur2
        '
        Me.date_Retur2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_Retur2.Location = New System.Drawing.Point(240, 23)
        Me.date_Retur2.Name = "date_Retur2"
        Me.date_Retur2.Size = New System.Drawing.Size(105, 20)
        Me.date_Retur2.TabIndex = 3
        '
        'date_Retur1
        '
        Me.date_Retur1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.date_Retur1.Location = New System.Drawing.Point(98, 23)
        Me.date_Retur1.Name = "date_Retur1"
        Me.date_Retur1.Size = New System.Drawing.Size(105, 20)
        Me.date_Retur1.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(211, 26)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(23, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "s/d"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(17, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Tanggal Retur"
        '
        'frmBrowse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(649, 426)
        Me.Controls.Add(Me.tab_Browse)
        Me.Name = "frmBrowse"
        Me.Text = "Browse"
        Me.tab_Browse.ResumeLayout(False)
        Me.tp_Buku.ResumeLayout(False)
        CType(Me.dgv_Buku, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Buku.ResumeLayout(False)
        Me.gb_Buku.PerformLayout()
        Me.tp_KelompokBuku.ResumeLayout(False)
        CType(Me.dgv_KelompokBuku, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_KelompokBuku.ResumeLayout(False)
        Me.gb_KelompokBuku.PerformLayout()
        Me.tp_Penulis.ResumeLayout(False)
        CType(Me.dgv_Penulis, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Penulis.ResumeLayout(False)
        Me.gb_Penulis.PerformLayout()
        Me.tp_Penerbit.ResumeLayout(False)
        CType(Me.dgv_Penerbit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Penerbit.ResumeLayout(False)
        Me.gb_Penerbit.PerformLayout()
        Me.tp_Supplier.ResumeLayout(False)
        CType(Me.dgv_Supplier, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Supplier.ResumeLayout(False)
        Me.gb_Supplier.PerformLayout()
        Me.tp_penjualan.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.dgv_PenjualanDetil, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv_PenjualanHeader, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Penjualan.ResumeLayout(False)
        Me.gb_Penjualan.PerformLayout()
        Me.tp_Pembelian.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.dgv_PembelianDetil, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.dgv_PembelianHeader, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.tp_Retur.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.dgv_ReturDetil, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.dgv_ReturHeader, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tab_Browse As System.Windows.Forms.TabControl
    Friend WithEvents tp_Buku As System.Windows.Forms.TabPage
    Friend WithEvents tp_KelompokBuku As System.Windows.Forms.TabPage
    Friend WithEvents tp_Penulis As System.Windows.Forms.TabPage
    Friend WithEvents tp_Penerbit As System.Windows.Forms.TabPage
    Friend WithEvents tp_Supplier As System.Windows.Forms.TabPage
    Friend WithEvents tp_penjualan As System.Windows.Forms.TabPage
    Friend WithEvents tp_Pembelian As System.Windows.Forms.TabPage
    Friend WithEvents tp_Retur As System.Windows.Forms.TabPage
    Friend WithEvents gb_Buku As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_Buku As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_KelompokBuku As System.Windows.Forms.DataGridView
    Friend WithEvents gb_KelompokBuku As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_Penulis As System.Windows.Forms.DataGridView
    Friend WithEvents gb_Penulis As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_Penerbit As System.Windows.Forms.DataGridView
    Friend WithEvents gb_Penerbit As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_Supplier As System.Windows.Forms.DataGridView
    Friend WithEvents gb_Supplier As System.Windows.Forms.GroupBox
    Friend WithEvents gb_Penjualan As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CariBuku As System.Windows.Forms.Button
    Friend WithEvents txtCariBuku As System.Windows.Forms.TextBox
    Friend WithEvents rd_Penerbit As System.Windows.Forms.RadioButton
    Friend WithEvents rd_Penulis As System.Windows.Forms.RadioButton
    Friend WithEvents rd_judul As System.Windows.Forms.RadioButton
    Friend WithEvents rb_KodeBuku As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btn_CariKelompok As System.Windows.Forms.Button
    Friend WithEvents txtCariKelompok As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btn_CariPenulis As System.Windows.Forms.Button
    Friend WithEvents txtCariPenulis As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btn_CariPenerbit As System.Windows.Forms.Button
    Friend WithEvents txtCariPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btn_CariSupplier As System.Windows.Forms.Button
    Friend WithEvents txtCariSupplier As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents date_TglJual2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents date_TglJual1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents btn_CariJual As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_PenjualanDetil As System.Windows.Forms.DataGridView
    Friend WithEvents dgv_PenjualanHeader As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_PembelianDetil As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_PembelianHeader As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CariPembelian As System.Windows.Forms.Button
    Friend WithEvents date_TglBeli2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents date_TglBeli1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_ReturDetil As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv_ReturHeader As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CariRetur As System.Windows.Forms.Button
    Friend WithEvents date_Retur2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents date_Retur1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
