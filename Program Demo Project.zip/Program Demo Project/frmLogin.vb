'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class frmLogin

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'memposisikan form login di tengah layar
        Me.StartPosition = FormStartPosition.CenterScreen
        'masking password dengan karakter *
        txtPassword.PasswordChar = "*"
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        'jika tombol batal ditekan akan keluar dari form
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            db = txtDatabase.Text
            user = txtUser.Text
            pwd = txtPassword.Text

            myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
            CN = New MySqlConnection(myConnectionString)
            CN.Open()
            Me.Hide()
            'jika koneksi sukses maka form MDI ditampilkan
            frmMDI.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
