'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Public Class frmStok

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ds As DataSet = New DataSet

        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim CMDTampil As MySqlCommand = CN.CreateCommand

        If mk_BlnThn.Text <> "" Then
            Try
                CMDTampil.CommandText = "SELECT * FROM SHOW_STOK_VW WHERE tahun=@tahun AND bulan=@bulan;"
                CMDTampil.Parameters.Add("@bulan", MySqlDbType.VarChar, 10).Value = Mid(mk_BlnThn.Text, 1, 2)
                CMDTampil.Parameters.Add("@tahun", MySqlDbType.VarChar, 10).Value = Mid(mk_BlnThn.Text, 4, 4)

                Dim daTampil As MySqlDataAdapter = New MySqlDataAdapter(CMDTampil)

                ds.Clear()
                daTampil.Fill(ds, "SHOW_STOK_VW")
                Dim dtTampil As DataTable = ds.Tables("SHOW_STOK_VW")

                With dgv_Stok
                    .DataSource = ds
                    .DataMember = "SHOW_STOK_VW"

                    'bagian ini mengubah atribut datagridview
                    .Columns("Judul Buku").Width = 300 'Lebar kolom Judul Buku 
                    .Columns("Judul Buku").ReadOnly = True 'kolom judul buku hanya dapat dibaca
                    .Columns("Judul Buku").Frozen = True 'Kolom kode sampai kolom judul buku dihentikan saat scroll

                    .Columns("Kelompok").ReadOnly = True 'kolom penerbit hanya dapat dibaca
                    .Columns("Kode Buku").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Stok Awal").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Stok Awal").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Stok Awal").Width = 100

                    .Columns("Beli").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Beli").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Beli").Width = 90
                    .Columns("Beli").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Jual").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Jual").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Jual").Width = 90
                    .Columns("Jual").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Retur").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Retur").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Retur").Width = 90
                    .Columns("Retur").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Stok Akhir").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Stok Akhir").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Stok Akhir").Width = 100
                    .Columns("Stok Akhir").ReadOnly = True 'kolom penerbit hanya dapat dibaca
                    .Columns("Stok Akhir").DefaultCellStyle.ForeColor = Color.Black
                    .Columns("Stok Akhir").DefaultCellStyle.BackColor = Color.Yellow

                    .Columns("Nilai Stok Awal").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Nilai Stok Awal").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Nilai Stok Awal").Width = 100
                    .Columns("Nilai Stok Awal").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Nilai Beli").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Nilai Beli").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Nilai Beli").Width = 90
                    .Columns("Nilai Beli").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Nilai Jual").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Nilai Jual").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Nilai Jual").Width = 90
                    .Columns("Nilai Jual").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Nilai Retur").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Nilai Retur").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Nilai Retur").Width = 90
                    .Columns("Nilai Retur").ReadOnly = True 'kolom penerbit hanya dapat dibaca

                    .Columns("Nilai Stok Akhir").DefaultCellStyle.Format = "N" 'Format angka
                    .Columns("Nilai Stok Akhir").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns("Nilai Stok Akhir").Width = 100
                    .Columns("Nilai Stok Akhir").ReadOnly = True 'kolom penerbit hanya dapat dibaca
                    .Columns("Nilai Stok Akhir").DefaultCellStyle.ForeColor = Color.Black
                    .Columns("Nilai Stok Akhir").DefaultCellStyle.BackColor = Color.Yellow
                    '----------

                    .Columns("tahun").Visible = False 'kolom penerbit hanya dapat dibaca
                    .Columns("bulan").Visible = False 'kolom penerbit hanya dapat dibaca

                    Dim font As New Font(.DefaultCellStyle.Font.FontFamily, 9, FontStyle.Bold)
                    Try
                        'mengubah atribut font kolom ke-7 (Stok Akhir)
                        .Columns("Stok Akhir").DefaultCellStyle.Font = font
                        .Columns("Nilai Stok Akhir").DefaultCellStyle.Font = font
                        .ColumnHeadersDefaultCellStyle.Font = font
                    Finally
                        font.Dispose()
                    End Try
                End With

            Catch ex As Exception
                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                CMDTampil.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

    Private Sub dgv_Stok_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv_Stok.CellEndEdit
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        '-----------------------------------------
        'Deklarasi object transaction dan command
        '-----------------------------------------
        Dim SQLTrans As MySqlTransaction = CN.BeginTransaction
        Dim CMDUpdateStokAwal As MySqlCommand = CN.CreateCommand

        If dgv_Stok.CurrentCell.ColumnIndex = 3 Then
            Try
                '------------------------------------------------------------------------------------------
                'memanggil Store Proceudre MASTER_BUKU_SP dari MySQL melalui perintah CALL.
                'Dan menyertakan parameternya, yang ditandai dengan @ dan diikuti oleh nama variable.
                'Dimana urutan parameter harus sama dengan urutan parameter Store Procedure MASTER_BUKU_SP
                '------------------------------------------------------------------------------------------
                SQL = "UPDATE stok_buku_tb SET stok_awal = @stok_awal "
                SQL = SQL & "WHERE tahun=@tahun AND bulan=@bulan AND kode_buku=@kode_buku;"
                With CMDUpdateStokAwal
                    .CommandText = SQL
                    .Connection = CN
                    .Transaction = SQLTrans

                    '------------------------------------------------------------------------
                    'Penentuan parameter sekaligus memberi nilai terhadap parameter tersebut
                    '------------------------------------------------------------------------
                    .Parameters.Add("@stok_awal", MySqlDbType.Int32).Value = dgv_Stok.CurrentRow.Cells("Stok Awal").Value
                    .Parameters.Add("@tahun", MySqlDbType.Int32).Value = Mid(mk_BlnThn.Text, 4, 4)
                    .Parameters.Add("@bulan", MySqlDbType.Int16).Value = Mid(mk_BlnThn.Text, 1, 2)
                    .Parameters.Add("@kode_buku", MySqlDbType.String, 13).Value = dgv_Stok.CurrentRow.Cells("Kode Buku").Value

                    '----------------------------
                    'Mengeksekusi Query dia atas
                    '----------------------------
                    .ExecuteNonQuery()
                End With

                '---------------------------------------------------------
                'Jika sukses dilaksanakan, maka perubahan dibuat permanen
                'melalui perintah COMMIT transaction
                '---------------------------------------------------------
                SQLTrans.Commit()

            Catch ex As MySqlException
                '-------------------------------------------------
                'Jika terjadi kegagalan, maka eksekusi dibatalkan
                'melalui perintah ROLLBACK transaction
                '-------------------------------------------------
                SQLTrans.Rollback()

                '----------------------------------------------------
                'Pesan kesalahan ditampilkan melalui MessageBox.Show
                '----------------------------------------------------
                MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                '---------------------------------------------------
                'melalui try...finally, maka baik gagal atau sukses.
                'maka SQLTrans dan CMDInsert dimusnahkan
                'sehingga kedua resource tersebut dilepas
                '---------------------------------------------------
                SQLTrans.Dispose()
                CMDUpdateStokAwal.Dispose()
                CN.Close()
                CN = Nothing
            End Try
        End If
    End Sub

End Class