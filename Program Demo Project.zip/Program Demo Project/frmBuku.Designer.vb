<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuku
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.lbl_Navigator = New System.Windows.Forms.ToolStripLabel
        Me.ts_first = New System.Windows.Forms.ToolStripButton
        Me.ts_prev = New System.Windows.Forms.ToolStripButton
        Me.ts_next = New System.Windows.Forms.ToolStripButton
        Me.ts_last = New System.Windows.Forms.ToolStripButton
        Me.separator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_addnew = New System.Windows.Forms.ToolStripButton
        Me.lbl_AddNew = New System.Windows.Forms.ToolStripLabel
        Me.ts_save = New System.Windows.Forms.ToolStripButton
        Me.lbl_Save = New System.Windows.Forms.ToolStripLabel
        Me.ts_update = New System.Windows.Forms.ToolStripButton
        Me.lbl_Update = New System.Windows.Forms.ToolStripLabel
        Me.ts_delete = New System.Windows.Forms.ToolStripButton
        Me.lbl_Delete = New System.Windows.Forms.ToolStripLabel
        Me.separator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_browse = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnu_BrowseBuku = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_BrowsePenulis = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_BrowseKelompok = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_BrowsePenerbit = New System.Windows.Forms.ToolStripMenuItem
        Me.lbl_Browse = New System.Windows.Forms.ToolStripLabel
        Me.separator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_print = New System.Windows.Forms.ToolStripButton
        Me.lbl_Cetak = New System.Windows.Forms.ToolStripLabel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btn_Loadfoto = New System.Windows.Forms.Button
        Me.txtJmlHalaman = New System.Windows.Forms.TextBox
        Me.lblJmlHalaman = New System.Windows.Forms.Label
        Me.txtTahunTerbit = New System.Windows.Forms.TextBox
        Me.lblTahunTerbit = New System.Windows.Forms.Label
        Me.txtHarga = New System.Windows.Forms.TextBox
        Me.lblHarga = New System.Windows.Forms.Label
        Me.btn_BrowseKodePenerbit = New System.Windows.Forms.Button
        Me.btn_BrowseKodeKelompok = New System.Windows.Forms.Button
        Me.btn_BrowseKodePenulis = New System.Windows.Forms.Button
        Me.txtSinopsis = New System.Windows.Forms.TextBox
        Me.lblSinopsis = New System.Windows.Forms.Label
        Me.btn_BrowseKodeBuku = New System.Windows.Forms.Button
        Me.txtNamaPenerbit = New System.Windows.Forms.TextBox
        Me.txtKodePenerbit = New System.Windows.Forms.TextBox
        Me.txtNamaKelompok = New System.Windows.Forms.TextBox
        Me.txtKodeKelompok = New System.Windows.Forms.TextBox
        Me.txtNamaPenulis = New System.Windows.Forms.TextBox
        Me.txtKodePenulis = New System.Windows.Forms.TextBox
        Me.txtJudul = New System.Windows.Forms.TextBox
        Me.txtISBN = New System.Windows.Forms.TextBox
        Me.txtKodeBuku = New System.Windows.Forms.TextBox
        Me.lblKelompok = New System.Windows.Forms.Label
        Me.lblPenerbit = New System.Windows.Forms.Label
        Me.lblPenulis = New System.Windows.Forms.Label
        Me.lblJudul = New System.Windows.Forms.Label
        Me.lblISBN = New System.Windows.Forms.Label
        Me.lblKode = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_Navigator, Me.ts_first, Me.ts_prev, Me.ts_next, Me.ts_last, Me.separator1, Me.ts_addnew, Me.lbl_AddNew, Me.ts_save, Me.lbl_Save, Me.ts_update, Me.lbl_Update, Me.ts_delete, Me.lbl_Delete, Me.separator2, Me.ts_browse, Me.lbl_Browse, Me.separator3, Me.ts_print, Me.lbl_Cetak})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(605, 25)
        Me.ToolStrip1.TabIndex = 27
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lbl_Navigator
        '
        Me.lbl_Navigator.Name = "lbl_Navigator"
        Me.lbl_Navigator.Size = New System.Drawing.Size(62, 22)
        Me.lbl_Navigator.Text = "Navigator:"
        '
        'ts_first
        '
        Me.ts_first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_first.Image = Global.PenjualanBuku.My.Resources.Resources._38
        Me.ts_first.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_first.Name = "ts_first"
        Me.ts_first.Size = New System.Drawing.Size(23, 22)
        Me.ts_first.Text = "Record Awal"
        '
        'ts_prev
        '
        Me.ts_prev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_prev.Image = Global.PenjualanBuku.My.Resources.Resources._36
        Me.ts_prev.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_prev.Name = "ts_prev"
        Me.ts_prev.Size = New System.Drawing.Size(23, 22)
        Me.ts_prev.Text = "Record Sebelum"
        '
        'ts_next
        '
        Me.ts_next.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_next.Image = Global.PenjualanBuku.My.Resources.Resources._35
        Me.ts_next.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_next.Name = "ts_next"
        Me.ts_next.Size = New System.Drawing.Size(23, 22)
        Me.ts_next.Text = "Record Setelah"
        '
        'ts_last
        '
        Me.ts_last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_last.Image = Global.PenjualanBuku.My.Resources.Resources._37
        Me.ts_last.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_last.Name = "ts_last"
        Me.ts_last.Size = New System.Drawing.Size(23, 22)
        Me.ts_last.Text = "Record Akhir "
        '
        'separator1
        '
        Me.separator1.Name = "separator1"
        Me.separator1.Size = New System.Drawing.Size(6, 25)
        '
        'ts_addnew
        '
        Me.ts_addnew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_addnew.Image = Global.PenjualanBuku.My.Resources.Resources._03
        Me.ts_addnew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_addnew.Name = "ts_addnew"
        Me.ts_addnew.Size = New System.Drawing.Size(23, 22)
        Me.ts_addnew.Text = "Tambah Data"
        '
        'lbl_AddNew
        '
        Me.lbl_AddNew.Name = "lbl_AddNew"
        Me.lbl_AddNew.Size = New System.Drawing.Size(56, 22)
        Me.lbl_AddNew.Text = "Add New"
        '
        'ts_save
        '
        Me.ts_save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_save.Image = Global.PenjualanBuku.My.Resources.Resources._461
        Me.ts_save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_save.Name = "ts_save"
        Me.ts_save.Size = New System.Drawing.Size(23, 22)
        Me.ts_save.Text = "Simpan Data"
        '
        'lbl_Save
        '
        Me.lbl_Save.Name = "lbl_Save"
        Me.lbl_Save.Size = New System.Drawing.Size(31, 22)
        Me.lbl_Save.Text = "Save"
        '
        'ts_update
        '
        Me.ts_update.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_update.Image = Global.PenjualanBuku.My.Resources.Resources._21
        Me.ts_update.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_update.Name = "ts_update"
        Me.ts_update.Size = New System.Drawing.Size(23, 22)
        Me.ts_update.Text = "Ubah Data"
        '
        'lbl_Update
        '
        Me.lbl_Update.Name = "lbl_Update"
        Me.lbl_Update.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Update.Text = "Update"
        '
        'ts_delete
        '
        Me.ts_delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_delete.Image = Global.PenjualanBuku.My.Resources.Resources._01
        Me.ts_delete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_delete.Name = "ts_delete"
        Me.ts_delete.Size = New System.Drawing.Size(23, 22)
        Me.ts_delete.Text = "Hapus Data"
        '
        'lbl_Delete
        '
        Me.lbl_Delete.Name = "lbl_Delete"
        Me.lbl_Delete.Size = New System.Drawing.Size(40, 22)
        Me.lbl_Delete.Text = "Delete"
        '
        'separator2
        '
        Me.separator2.Name = "separator2"
        Me.separator2.Size = New System.Drawing.Size(6, 25)
        '
        'ts_browse
        '
        Me.ts_browse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_browse.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_BrowseBuku, Me.mnu_BrowsePenulis, Me.mnu_BrowseKelompok, Me.mnu_BrowsePenerbit})
        Me.ts_browse.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.ts_browse.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_browse.Name = "ts_browse"
        Me.ts_browse.Size = New System.Drawing.Size(29, 22)
        Me.ts_browse.Text = "Browse"
        '
        'mnu_BrowseBuku
        '
        Me.mnu_BrowseBuku.Name = "mnu_BrowseBuku"
        Me.mnu_BrowseBuku.Size = New System.Drawing.Size(169, 22)
        Me.mnu_BrowseBuku.Text = "Browse Buku"
        '
        'mnu_BrowsePenulis
        '
        Me.mnu_BrowsePenulis.Name = "mnu_BrowsePenulis"
        Me.mnu_BrowsePenulis.Size = New System.Drawing.Size(169, 22)
        Me.mnu_BrowsePenulis.Text = "Browse Penulis"
        '
        'mnu_BrowseKelompok
        '
        Me.mnu_BrowseKelompok.Name = "mnu_BrowseKelompok"
        Me.mnu_BrowseKelompok.Size = New System.Drawing.Size(169, 22)
        Me.mnu_BrowseKelompok.Text = "Browse Kelompok"
        '
        'mnu_BrowsePenerbit
        '
        Me.mnu_BrowsePenerbit.Name = "mnu_BrowsePenerbit"
        Me.mnu_BrowsePenerbit.Size = New System.Drawing.Size(169, 22)
        Me.mnu_BrowsePenerbit.Text = "Browse Penerbit"
        '
        'lbl_Browse
        '
        Me.lbl_Browse.Name = "lbl_Browse"
        Me.lbl_Browse.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Browse.Text = "Browse"
        '
        'separator3
        '
        Me.separator3.Name = "separator3"
        Me.separator3.Size = New System.Drawing.Size(6, 25)
        '
        'ts_print
        '
        Me.ts_print.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_print.Image = Global.PenjualanBuku.My.Resources.Resources._12
        Me.ts_print.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_print.Name = "ts_print"
        Me.ts_print.Size = New System.Drawing.Size(23, 22)
        Me.ts_print.Text = "Cetak"
        '
        'lbl_Cetak
        '
        Me.lbl_Cetak.Name = "lbl_Cetak"
        Me.lbl_Cetak.Size = New System.Drawing.Size(37, 22)
        Me.lbl_Cetak.Text = "Cetak"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.btn_Loadfoto)
        Me.GroupBox1.Controls.Add(Me.txtJmlHalaman)
        Me.GroupBox1.Controls.Add(Me.lblJmlHalaman)
        Me.GroupBox1.Controls.Add(Me.txtTahunTerbit)
        Me.GroupBox1.Controls.Add(Me.lblTahunTerbit)
        Me.GroupBox1.Controls.Add(Me.txtHarga)
        Me.GroupBox1.Controls.Add(Me.lblHarga)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodePenerbit)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodeKelompok)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodePenulis)
        Me.GroupBox1.Controls.Add(Me.txtSinopsis)
        Me.GroupBox1.Controls.Add(Me.lblSinopsis)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodeBuku)
        Me.GroupBox1.Controls.Add(Me.txtNamaPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtKodePenerbit)
        Me.GroupBox1.Controls.Add(Me.txtNamaKelompok)
        Me.GroupBox1.Controls.Add(Me.txtKodeKelompok)
        Me.GroupBox1.Controls.Add(Me.txtNamaPenulis)
        Me.GroupBox1.Controls.Add(Me.txtKodePenulis)
        Me.GroupBox1.Controls.Add(Me.txtJudul)
        Me.GroupBox1.Controls.Add(Me.txtISBN)
        Me.GroupBox1.Controls.Add(Me.txtKodeBuku)
        Me.GroupBox1.Controls.Add(Me.lblKelompok)
        Me.GroupBox1.Controls.Add(Me.lblPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblPenulis)
        Me.GroupBox1.Controls.Add(Me.lblJudul)
        Me.GroupBox1.Controls.Add(Me.lblISBN)
        Me.GroupBox1.Controls.Add(Me.lblKode)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(598, 287)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Buku"
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(420, 52)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(172, 219)
        Me.PictureBox1.TabIndex = 61
        Me.PictureBox1.TabStop = False
        '
        'btn_Loadfoto
        '
        Me.btn_Loadfoto.Image = Global.PenjualanBuku.My.Resources.Resources._08
        Me.btn_Loadfoto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Loadfoto.Location = New System.Drawing.Point(450, 18)
        Me.btn_Loadfoto.Name = "btn_Loadfoto"
        Me.btn_Loadfoto.Size = New System.Drawing.Size(115, 30)
        Me.btn_Loadfoto.TabIndex = 60
        Me.btn_Loadfoto.Text = "Load Foto Produk"
        Me.btn_Loadfoto.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btn_Loadfoto.UseVisualStyleBackColor = True
        '
        'txtJmlHalaman
        '
        Me.txtJmlHalaman.Location = New System.Drawing.Point(99, 200)
        Me.txtJmlHalaman.Name = "txtJmlHalaman"
        Me.txtJmlHalaman.Size = New System.Drawing.Size(314, 20)
        Me.txtJmlHalaman.TabIndex = 12
        '
        'lblJmlHalaman
        '
        Me.lblJmlHalaman.AutoSize = True
        Me.lblJmlHalaman.Location = New System.Drawing.Point(19, 203)
        Me.lblJmlHalaman.Name = "lblJmlHalaman"
        Me.lblJmlHalaman.Size = New System.Drawing.Size(70, 13)
        Me.lblJmlHalaman.TabIndex = 59
        Me.lblJmlHalaman.Text = "Jml. Halaman"
        '
        'txtTahunTerbit
        '
        Me.txtTahunTerbit.Location = New System.Drawing.Point(99, 174)
        Me.txtTahunTerbit.Name = "txtTahunTerbit"
        Me.txtTahunTerbit.Size = New System.Drawing.Size(314, 20)
        Me.txtTahunTerbit.TabIndex = 11
        '
        'lblTahunTerbit
        '
        Me.lblTahunTerbit.AutoSize = True
        Me.lblTahunTerbit.Location = New System.Drawing.Point(19, 177)
        Me.lblTahunTerbit.Name = "lblTahunTerbit"
        Me.lblTahunTerbit.Size = New System.Drawing.Size(68, 13)
        Me.lblTahunTerbit.TabIndex = 57
        Me.lblTahunTerbit.Text = "Tahun Terbit"
        '
        'txtHarga
        '
        Me.txtHarga.Location = New System.Drawing.Point(99, 148)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(314, 20)
        Me.txtHarga.TabIndex = 10
        '
        'lblHarga
        '
        Me.lblHarga.AutoSize = True
        Me.lblHarga.Location = New System.Drawing.Point(19, 151)
        Me.lblHarga.Name = "lblHarga"
        Me.lblHarga.Size = New System.Drawing.Size(58, 13)
        Me.lblHarga.TabIndex = 55
        Me.lblHarga.Text = "Harga Jual"
        '
        'btn_BrowseKodePenerbit
        '
        Me.btn_BrowseKodePenerbit.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodePenerbit.Location = New System.Drawing.Point(197, 121)
        Me.btn_BrowseKodePenerbit.Name = "btn_BrowseKodePenerbit"
        Me.btn_BrowseKodePenerbit.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodePenerbit.TabIndex = 9
        Me.btn_BrowseKodePenerbit.UseVisualStyleBackColor = True
        '
        'btn_BrowseKodeKelompok
        '
        Me.btn_BrowseKodeKelompok.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodeKelompok.Location = New System.Drawing.Point(197, 94)
        Me.btn_BrowseKodeKelompok.Name = "btn_BrowseKodeKelompok"
        Me.btn_BrowseKodeKelompok.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodeKelompok.TabIndex = 7
        Me.btn_BrowseKodeKelompok.UseVisualStyleBackColor = True
        '
        'btn_BrowseKodePenulis
        '
        Me.btn_BrowseKodePenulis.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodePenulis.Location = New System.Drawing.Point(197, 70)
        Me.btn_BrowseKodePenulis.Name = "btn_BrowseKodePenulis"
        Me.btn_BrowseKodePenulis.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodePenulis.TabIndex = 5
        Me.btn_BrowseKodePenulis.UseVisualStyleBackColor = True
        '
        'txtSinopsis
        '
        Me.txtSinopsis.Location = New System.Drawing.Point(99, 226)
        Me.txtSinopsis.Multiline = True
        Me.txtSinopsis.Name = "txtSinopsis"
        Me.txtSinopsis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSinopsis.Size = New System.Drawing.Size(314, 45)
        Me.txtSinopsis.TabIndex = 13
        '
        'lblSinopsis
        '
        Me.lblSinopsis.AutoSize = True
        Me.lblSinopsis.Location = New System.Drawing.Point(19, 239)
        Me.lblSinopsis.Name = "lblSinopsis"
        Me.lblSinopsis.Size = New System.Drawing.Size(46, 13)
        Me.lblSinopsis.TabIndex = 44
        Me.lblSinopsis.Text = "Sinopsis"
        '
        'btn_BrowseKodeBuku
        '
        Me.btn_BrowseKodeBuku.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodeBuku.Location = New System.Drawing.Point(242, 17)
        Me.btn_BrowseKodeBuku.Name = "btn_BrowseKodeBuku"
        Me.btn_BrowseKodeBuku.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodeBuku.TabIndex = 1
        Me.btn_BrowseKodeBuku.UseVisualStyleBackColor = True
        '
        'txtNamaPenerbit
        '
        Me.txtNamaPenerbit.Enabled = False
        Me.txtNamaPenerbit.Location = New System.Drawing.Point(228, 124)
        Me.txtNamaPenerbit.Name = "txtNamaPenerbit"
        Me.txtNamaPenerbit.Size = New System.Drawing.Size(185, 20)
        Me.txtNamaPenerbit.TabIndex = 40
        '
        'txtKodePenerbit
        '
        Me.txtKodePenerbit.Location = New System.Drawing.Point(99, 123)
        Me.txtKodePenerbit.Name = "txtKodePenerbit"
        Me.txtKodePenerbit.Size = New System.Drawing.Size(96, 20)
        Me.txtKodePenerbit.TabIndex = 8
        '
        'txtNamaKelompok
        '
        Me.txtNamaKelompok.Enabled = False
        Me.txtNamaKelompok.Location = New System.Drawing.Point(228, 98)
        Me.txtNamaKelompok.Name = "txtNamaKelompok"
        Me.txtNamaKelompok.Size = New System.Drawing.Size(185, 20)
        Me.txtNamaKelompok.TabIndex = 37
        '
        'txtKodeKelompok
        '
        Me.txtKodeKelompok.Location = New System.Drawing.Point(99, 97)
        Me.txtKodeKelompok.Name = "txtKodeKelompok"
        Me.txtKodeKelompok.Size = New System.Drawing.Size(96, 20)
        Me.txtKodeKelompok.TabIndex = 6
        '
        'txtNamaPenulis
        '
        Me.txtNamaPenulis.Enabled = False
        Me.txtNamaPenulis.Location = New System.Drawing.Point(228, 71)
        Me.txtNamaPenulis.Name = "txtNamaPenulis"
        Me.txtNamaPenulis.Size = New System.Drawing.Size(185, 20)
        Me.txtNamaPenulis.TabIndex = 33
        '
        'txtKodePenulis
        '
        Me.txtKodePenulis.Location = New System.Drawing.Point(99, 71)
        Me.txtKodePenulis.Name = "txtKodePenulis"
        Me.txtKodePenulis.Size = New System.Drawing.Size(96, 20)
        Me.txtKodePenulis.TabIndex = 4
        '
        'txtJudul
        '
        Me.txtJudul.Location = New System.Drawing.Point(99, 44)
        Me.txtJudul.Name = "txtJudul"
        Me.txtJudul.Size = New System.Drawing.Size(314, 20)
        Me.txtJudul.TabIndex = 3
        '
        'txtISBN
        '
        Me.txtISBN.Location = New System.Drawing.Point(311, 18)
        Me.txtISBN.Name = "txtISBN"
        Me.txtISBN.Size = New System.Drawing.Size(102, 20)
        Me.txtISBN.TabIndex = 2
        '
        'txtKodeBuku
        '
        Me.txtKodeBuku.Location = New System.Drawing.Point(99, 19)
        Me.txtKodeBuku.Name = "txtKodeBuku"
        Me.txtKodeBuku.Size = New System.Drawing.Size(137, 20)
        Me.txtKodeBuku.TabIndex = 0
        '
        'lblKelompok
        '
        Me.lblKelompok.AutoSize = True
        Me.lblKelompok.Location = New System.Drawing.Point(18, 102)
        Me.lblKelompok.Name = "lblKelompok"
        Me.lblKelompok.Size = New System.Drawing.Size(54, 13)
        Me.lblKelompok.TabIndex = 27
        Me.lblKelompok.Text = "Kelompok"
        '
        'lblPenerbit
        '
        Me.lblPenerbit.AutoSize = True
        Me.lblPenerbit.Location = New System.Drawing.Point(18, 128)
        Me.lblPenerbit.Name = "lblPenerbit"
        Me.lblPenerbit.Size = New System.Drawing.Size(46, 13)
        Me.lblPenerbit.TabIndex = 26
        Me.lblPenerbit.Text = "Penerbit"
        '
        'lblPenulis
        '
        Me.lblPenulis.AutoSize = True
        Me.lblPenulis.Location = New System.Drawing.Point(18, 74)
        Me.lblPenulis.Name = "lblPenulis"
        Me.lblPenulis.Size = New System.Drawing.Size(41, 13)
        Me.lblPenulis.TabIndex = 25
        Me.lblPenulis.Text = "Penulis"
        '
        'lblJudul
        '
        Me.lblJudul.AutoSize = True
        Me.lblJudul.Location = New System.Drawing.Point(18, 47)
        Me.lblJudul.Name = "lblJudul"
        Me.lblJudul.Size = New System.Drawing.Size(32, 13)
        Me.lblJudul.TabIndex = 24
        Me.lblJudul.Text = "Judul"
        '
        'lblISBN
        '
        Me.lblISBN.AutoSize = True
        Me.lblISBN.Location = New System.Drawing.Point(273, 22)
        Me.lblISBN.Name = "lblISBN"
        Me.lblISBN.Size = New System.Drawing.Size(32, 13)
        Me.lblISBN.TabIndex = 23
        Me.lblISBN.Text = "ISBN"
        '
        'lblKode
        '
        Me.lblKode.AutoSize = True
        Me.lblKode.Location = New System.Drawing.Point(18, 22)
        Me.lblKode.Name = "lblKode"
        Me.lblKode.Size = New System.Drawing.Size(32, 13)
        Me.lblKode.TabIndex = 22
        Me.lblKode.Text = "Kode"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 318)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(605, 22)
        Me.StatusStrip1.TabIndex = 28
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'frmBuku
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(605, 340)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmBuku"
        Me.Text = "Master Buku"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents lbl_Navigator As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_first As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_prev As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_next As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_last As System.Windows.Forms.ToolStripButton
    Friend WithEvents separator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_addnew As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_AddNew As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_save As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Save As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_update As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Update As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_delete As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Delete As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_browse As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnu_BrowseBuku As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_BrowsePenulis As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_BrowseKelompok As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_BrowsePenerbit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbl_Browse As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_print As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Cetak As System.Windows.Forms.ToolStripLabel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSinopsis As System.Windows.Forms.TextBox
    Friend WithEvents lblSinopsis As System.Windows.Forms.Label
    Friend WithEvents btn_BrowseKodeBuku As System.Windows.Forms.Button
    Friend WithEvents txtNamaPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtKodePenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaKelompok As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeKelompok As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaPenulis As System.Windows.Forms.TextBox
    Friend WithEvents txtKodePenulis As System.Windows.Forms.TextBox
    Friend WithEvents txtJudul As System.Windows.Forms.TextBox
    Friend WithEvents txtISBN As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeBuku As System.Windows.Forms.TextBox
    Friend WithEvents lblKelompok As System.Windows.Forms.Label
    Friend WithEvents lblPenerbit As System.Windows.Forms.Label
    Friend WithEvents lblPenulis As System.Windows.Forms.Label
    Friend WithEvents lblJudul As System.Windows.Forms.Label
    Friend WithEvents lblISBN As System.Windows.Forms.Label
    Friend WithEvents lblKode As System.Windows.Forms.Label
    Friend WithEvents btn_BrowseKodePenerbit As System.Windows.Forms.Button
    Friend WithEvents btn_BrowseKodeKelompok As System.Windows.Forms.Button
    Friend WithEvents btn_BrowseKodePenulis As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txtJmlHalaman As System.Windows.Forms.TextBox
    Friend WithEvents lblJmlHalaman As System.Windows.Forms.Label
    Friend WithEvents txtTahunTerbit As System.Windows.Forms.TextBox
    Friend WithEvents lblTahunTerbit As System.Windows.Forms.Label
    Friend WithEvents txtHarga As System.Windows.Forms.TextBox
    Friend WithEvents lblHarga As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Loadfoto As System.Windows.Forms.Button
End Class
