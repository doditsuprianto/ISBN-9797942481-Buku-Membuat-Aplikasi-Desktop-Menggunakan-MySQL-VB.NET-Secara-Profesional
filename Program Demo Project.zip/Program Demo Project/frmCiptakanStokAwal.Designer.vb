<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCiptakanStokAwal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.mk_PeriodeStok = New System.Windows.Forms.MaskedTextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.lbl_proses = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.mk_PindahStok2 = New System.Windows.Forms.MaskedTextBox
        Me.mk_PindahStok1 = New System.Windows.Forms.MaskedTextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Periode Stok:"
        '
        'mk_PeriodeStok
        '
        Me.mk_PeriodeStok.Location = New System.Drawing.Point(83, 32)
        Me.mk_PeriodeStok.Mask = "00/0000"
        Me.mk_PeriodeStok.Name = "mk_PeriodeStok"
        Me.mk_PeriodeStok.Size = New System.Drawing.Size(50, 20)
        Me.mk_PeriodeStok.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(144, 30)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Proses"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(9, 70)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(305, 37)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Text = "Menciptakan stok awal hanya perlu dilakukan satu kali saja saat program aplikasi " & _
            "digunakan  pertamakali."
        '
        'lbl_proses
        '
        Me.lbl_proses.AutoSize = True
        Me.lbl_proses.Location = New System.Drawing.Point(225, 35)
        Me.lbl_proses.Name = "lbl_proses"
        Me.lbl_proses.Size = New System.Drawing.Size(39, 13)
        Me.lbl_proses.TabIndex = 5
        Me.lbl_proses.Text = "Label2"
        Me.lbl_proses.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.lbl_proses)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.mk_PeriodeStok)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(387, 130)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Menciptakan Stok Awal"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.mk_PindahStok2)
        Me.GroupBox2.Controls.Add(Me.mk_PindahStok1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(0, 130)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(387, 92)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Memindah Stok Akhir Bulan Ini Menjadi Stok Awal Bulan Depan"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(206, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Pindah Stok"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'mk_PindahStok2
        '
        Me.mk_PindahStok2.Location = New System.Drawing.Point(150, 56)
        Me.mk_PindahStok2.Mask = "00/0000"
        Me.mk_PindahStok2.Name = "mk_PindahStok2"
        Me.mk_PindahStok2.ReadOnly = True
        Me.mk_PindahStok2.Size = New System.Drawing.Size(50, 20)
        Me.mk_PindahStok2.TabIndex = 3
        '
        'mk_PindahStok1
        '
        Me.mk_PindahStok1.Location = New System.Drawing.Point(150, 30)
        Me.mk_PindahStok1.Mask = "00/0000"
        Me.mk_PindahStok1.Name = "mk_PindahStok1"
        Me.mk_PindahStok1.Size = New System.Drawing.Size(50, 20)
        Me.mk_PindahStok1.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(137, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Menjadi Stok Awal Periode:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Periode Stok Akhir:"
        '
        'frmCiptakanStokAwal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(387, 222)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmCiptakanStokAwal"
        Me.Text = "Ciptakan Stok"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents mk_PeriodeStok As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_proses As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents mk_PindahStok2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents mk_PindahStok1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
