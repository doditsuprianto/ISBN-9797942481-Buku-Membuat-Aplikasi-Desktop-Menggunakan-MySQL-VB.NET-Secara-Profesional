<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPenerbit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtWebsitePenerbit = New System.Windows.Forms.TextBox
        Me.txtEmailPenerbit = New System.Windows.Forms.TextBox
        Me.txtTelpPenerbit = New System.Windows.Forms.TextBox
        Me.txtKodePosPenerbit = New System.Windows.Forms.TextBox
        Me.lblTelpPenerbit = New System.Windows.Forms.Label
        Me.lblKodePosPenerbit = New System.Windows.Forms.Label
        Me.lblKotaPenerbit = New System.Windows.Forms.Label
        Me.lblAlamatPenerbit = New System.Windows.Forms.Label
        Me.btn_BrowseKodePenerbit = New System.Windows.Forms.Button
        Me.txtKotaPenerbit = New System.Windows.Forms.TextBox
        Me.txtAlamatPenerbit = New System.Windows.Forms.TextBox
        Me.txtNamaPenerbit = New System.Windows.Forms.TextBox
        Me.txtKodePenerbit = New System.Windows.Forms.TextBox
        Me.lblWebsitePenerbit = New System.Windows.Forms.Label
        Me.lblEmailPenerbit = New System.Windows.Forms.Label
        Me.lblNamaPenerbit = New System.Windows.Forms.Label
        Me.lblKodePenerbit = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.lbl_Navigator = New System.Windows.Forms.ToolStripLabel
        Me.ts_first = New System.Windows.Forms.ToolStripButton
        Me.ts_prev = New System.Windows.Forms.ToolStripButton
        Me.ts_next = New System.Windows.Forms.ToolStripButton
        Me.ts_last = New System.Windows.Forms.ToolStripButton
        Me.separator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_addnew = New System.Windows.Forms.ToolStripButton
        Me.lbl_AddNew = New System.Windows.Forms.ToolStripLabel
        Me.ts_save = New System.Windows.Forms.ToolStripButton
        Me.lbl_Save = New System.Windows.Forms.ToolStripLabel
        Me.ts_update = New System.Windows.Forms.ToolStripButton
        Me.lbl_Update = New System.Windows.Forms.ToolStripLabel
        Me.ts_delete = New System.Windows.Forms.ToolStripButton
        Me.lbl_Delete = New System.Windows.Forms.ToolStripLabel
        Me.separator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_browse = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnu_BrowsePenerbit = New System.Windows.Forms.ToolStripMenuItem
        Me.lbl_Browse = New System.Windows.Forms.ToolStripLabel
        Me.separator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_print = New System.Windows.Forms.ToolStripButton
        Me.lbl_Cetak = New System.Windows.Forms.ToolStripLabel
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtWebsitePenerbit)
        Me.GroupBox1.Controls.Add(Me.txtEmailPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtTelpPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtKodePosPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblTelpPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblKodePosPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblKotaPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblAlamatPenerbit)
        Me.GroupBox1.Controls.Add(Me.btn_BrowseKodePenerbit)
        Me.GroupBox1.Controls.Add(Me.txtKotaPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtAlamatPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtNamaPenerbit)
        Me.GroupBox1.Controls.Add(Me.txtKodePenerbit)
        Me.GroupBox1.Controls.Add(Me.lblWebsitePenerbit)
        Me.GroupBox1.Controls.Add(Me.lblEmailPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblNamaPenerbit)
        Me.GroupBox1.Controls.Add(Me.lblKodePenerbit)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 28)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(569, 234)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Penerbit"
        '
        'txtWebsitePenerbit
        '
        Me.txtWebsitePenerbit.Location = New System.Drawing.Point(81, 202)
        Me.txtWebsitePenerbit.Name = "txtWebsitePenerbit"
        Me.txtWebsitePenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtWebsitePenerbit.TabIndex = 8
        '
        'txtEmailPenerbit
        '
        Me.txtEmailPenerbit.Location = New System.Drawing.Point(81, 176)
        Me.txtEmailPenerbit.Name = "txtEmailPenerbit"
        Me.txtEmailPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtEmailPenerbit.TabIndex = 7
        '
        'txtTelpPenerbit
        '
        Me.txtTelpPenerbit.Location = New System.Drawing.Point(81, 150)
        Me.txtTelpPenerbit.Name = "txtTelpPenerbit"
        Me.txtTelpPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtTelpPenerbit.TabIndex = 6
        '
        'txtKodePosPenerbit
        '
        Me.txtKodePosPenerbit.Location = New System.Drawing.Point(81, 124)
        Me.txtKodePosPenerbit.Name = "txtKodePosPenerbit"
        Me.txtKodePosPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtKodePosPenerbit.TabIndex = 5
        '
        'lblTelpPenerbit
        '
        Me.lblTelpPenerbit.AutoSize = True
        Me.lblTelpPenerbit.Location = New System.Drawing.Point(21, 155)
        Me.lblTelpPenerbit.Name = "lblTelpPenerbit"
        Me.lblTelpPenerbit.Size = New System.Drawing.Size(31, 13)
        Me.lblTelpPenerbit.TabIndex = 47
        Me.lblTelpPenerbit.Text = "Telp."
        '
        'lblKodePosPenerbit
        '
        Me.lblKodePosPenerbit.AutoSize = True
        Me.lblKodePosPenerbit.Location = New System.Drawing.Point(21, 129)
        Me.lblKodePosPenerbit.Name = "lblKodePosPenerbit"
        Me.lblKodePosPenerbit.Size = New System.Drawing.Size(53, 13)
        Me.lblKodePosPenerbit.TabIndex = 46
        Me.lblKodePosPenerbit.Text = "Kode Pos"
        '
        'lblKotaPenerbit
        '
        Me.lblKotaPenerbit.AutoSize = True
        Me.lblKotaPenerbit.Location = New System.Drawing.Point(21, 103)
        Me.lblKotaPenerbit.Name = "lblKotaPenerbit"
        Me.lblKotaPenerbit.Size = New System.Drawing.Size(29, 13)
        Me.lblKotaPenerbit.TabIndex = 45
        Me.lblKotaPenerbit.Text = "Kota"
        '
        'lblAlamatPenerbit
        '
        Me.lblAlamatPenerbit.AutoSize = True
        Me.lblAlamatPenerbit.Location = New System.Drawing.Point(21, 77)
        Me.lblAlamatPenerbit.Name = "lblAlamatPenerbit"
        Me.lblAlamatPenerbit.Size = New System.Drawing.Size(39, 13)
        Me.lblAlamatPenerbit.TabIndex = 44
        Me.lblAlamatPenerbit.Text = "Alamat"
        '
        'btn_BrowseKodePenerbit
        '
        Me.btn_BrowseKodePenerbit.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodePenerbit.Location = New System.Drawing.Point(387, 16)
        Me.btn_BrowseKodePenerbit.Name = "btn_BrowseKodePenerbit"
        Me.btn_BrowseKodePenerbit.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodePenerbit.TabIndex = 1
        Me.btn_BrowseKodePenerbit.UseVisualStyleBackColor = True
        '
        'txtKotaPenerbit
        '
        Me.txtKotaPenerbit.Location = New System.Drawing.Point(81, 98)
        Me.txtKotaPenerbit.Name = "txtKotaPenerbit"
        Me.txtKotaPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtKotaPenerbit.TabIndex = 4
        '
        'txtAlamatPenerbit
        '
        Me.txtAlamatPenerbit.Location = New System.Drawing.Point(81, 72)
        Me.txtAlamatPenerbit.Name = "txtAlamatPenerbit"
        Me.txtAlamatPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtAlamatPenerbit.TabIndex = 3
        '
        'txtNamaPenerbit
        '
        Me.txtNamaPenerbit.Location = New System.Drawing.Point(81, 45)
        Me.txtNamaPenerbit.Name = "txtNamaPenerbit"
        Me.txtNamaPenerbit.Size = New System.Drawing.Size(331, 20)
        Me.txtNamaPenerbit.TabIndex = 2
        '
        'txtKodePenerbit
        '
        Me.txtKodePenerbit.Location = New System.Drawing.Point(81, 20)
        Me.txtKodePenerbit.Name = "txtKodePenerbit"
        Me.txtKodePenerbit.Size = New System.Drawing.Size(300, 20)
        Me.txtKodePenerbit.TabIndex = 0
        '
        'lblWebsitePenerbit
        '
        Me.lblWebsitePenerbit.AutoSize = True
        Me.lblWebsitePenerbit.Location = New System.Drawing.Point(21, 207)
        Me.lblWebsitePenerbit.Name = "lblWebsitePenerbit"
        Me.lblWebsitePenerbit.Size = New System.Drawing.Size(46, 13)
        Me.lblWebsitePenerbit.TabIndex = 27
        Me.lblWebsitePenerbit.Text = "Website"
        '
        'lblEmailPenerbit
        '
        Me.lblEmailPenerbit.AutoSize = True
        Me.lblEmailPenerbit.Location = New System.Drawing.Point(21, 181)
        Me.lblEmailPenerbit.Name = "lblEmailPenerbit"
        Me.lblEmailPenerbit.Size = New System.Drawing.Size(32, 13)
        Me.lblEmailPenerbit.TabIndex = 25
        Me.lblEmailPenerbit.Text = "Email"
        '
        'lblNamaPenerbit
        '
        Me.lblNamaPenerbit.AutoSize = True
        Me.lblNamaPenerbit.Location = New System.Drawing.Point(21, 50)
        Me.lblNamaPenerbit.Name = "lblNamaPenerbit"
        Me.lblNamaPenerbit.Size = New System.Drawing.Size(35, 13)
        Me.lblNamaPenerbit.TabIndex = 24
        Me.lblNamaPenerbit.Text = "Nama"
        '
        'lblKodePenerbit
        '
        Me.lblKodePenerbit.AutoSize = True
        Me.lblKodePenerbit.Location = New System.Drawing.Point(21, 27)
        Me.lblKodePenerbit.Name = "lblKodePenerbit"
        Me.lblKodePenerbit.Size = New System.Drawing.Size(32, 13)
        Me.lblKodePenerbit.TabIndex = 22
        Me.lblKodePenerbit.Text = "Kode"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 268)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(581, 22)
        Me.StatusStrip1.TabIndex = 31
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_Navigator, Me.ts_first, Me.ts_prev, Me.ts_next, Me.ts_last, Me.separator1, Me.ts_addnew, Me.lbl_AddNew, Me.ts_save, Me.lbl_Save, Me.ts_update, Me.lbl_Update, Me.ts_delete, Me.lbl_Delete, Me.separator2, Me.ts_browse, Me.lbl_Browse, Me.separator3, Me.ts_print, Me.lbl_Cetak})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(581, 25)
        Me.ToolStrip1.TabIndex = 32
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lbl_Navigator
        '
        Me.lbl_Navigator.Name = "lbl_Navigator"
        Me.lbl_Navigator.Size = New System.Drawing.Size(62, 22)
        Me.lbl_Navigator.Text = "Navigator:"
        '
        'ts_first
        '
        Me.ts_first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_first.Image = Global.PenjualanBuku.My.Resources.Resources._38
        Me.ts_first.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_first.Name = "ts_first"
        Me.ts_first.Size = New System.Drawing.Size(23, 22)
        Me.ts_first.Text = "Record Awal"
        '
        'ts_prev
        '
        Me.ts_prev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_prev.Image = Global.PenjualanBuku.My.Resources.Resources._36
        Me.ts_prev.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_prev.Name = "ts_prev"
        Me.ts_prev.Size = New System.Drawing.Size(23, 22)
        Me.ts_prev.Text = "Record Sebelum"
        '
        'ts_next
        '
        Me.ts_next.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_next.Image = Global.PenjualanBuku.My.Resources.Resources._35
        Me.ts_next.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_next.Name = "ts_next"
        Me.ts_next.Size = New System.Drawing.Size(23, 22)
        Me.ts_next.Text = "Record Setelah"
        '
        'ts_last
        '
        Me.ts_last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_last.Image = Global.PenjualanBuku.My.Resources.Resources._37
        Me.ts_last.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_last.Name = "ts_last"
        Me.ts_last.Size = New System.Drawing.Size(23, 22)
        Me.ts_last.Text = "Record Akhir "
        '
        'separator1
        '
        Me.separator1.Name = "separator1"
        Me.separator1.Size = New System.Drawing.Size(6, 25)
        '
        'ts_addnew
        '
        Me.ts_addnew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_addnew.Image = Global.PenjualanBuku.My.Resources.Resources._03
        Me.ts_addnew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_addnew.Name = "ts_addnew"
        Me.ts_addnew.Size = New System.Drawing.Size(23, 22)
        Me.ts_addnew.Text = "Tambah Data"
        '
        'lbl_AddNew
        '
        Me.lbl_AddNew.Name = "lbl_AddNew"
        Me.lbl_AddNew.Size = New System.Drawing.Size(56, 22)
        Me.lbl_AddNew.Text = "Add New"
        '
        'ts_save
        '
        Me.ts_save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_save.Image = Global.PenjualanBuku.My.Resources.Resources._461
        Me.ts_save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_save.Name = "ts_save"
        Me.ts_save.Size = New System.Drawing.Size(23, 22)
        Me.ts_save.Text = "Simpan Data"
        '
        'lbl_Save
        '
        Me.lbl_Save.Name = "lbl_Save"
        Me.lbl_Save.Size = New System.Drawing.Size(31, 22)
        Me.lbl_Save.Text = "Save"
        '
        'ts_update
        '
        Me.ts_update.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_update.Image = Global.PenjualanBuku.My.Resources.Resources._21
        Me.ts_update.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_update.Name = "ts_update"
        Me.ts_update.Size = New System.Drawing.Size(23, 22)
        Me.ts_update.Text = "Ubah Data"
        '
        'lbl_Update
        '
        Me.lbl_Update.Name = "lbl_Update"
        Me.lbl_Update.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Update.Text = "Update"
        '
        'ts_delete
        '
        Me.ts_delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_delete.Image = Global.PenjualanBuku.My.Resources.Resources._01
        Me.ts_delete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_delete.Name = "ts_delete"
        Me.ts_delete.Size = New System.Drawing.Size(23, 22)
        Me.ts_delete.Text = "Hapus Data"
        '
        'lbl_Delete
        '
        Me.lbl_Delete.Name = "lbl_Delete"
        Me.lbl_Delete.Size = New System.Drawing.Size(40, 22)
        Me.lbl_Delete.Text = "Delete"
        '
        'separator2
        '
        Me.separator2.Name = "separator2"
        Me.separator2.Size = New System.Drawing.Size(6, 25)
        '
        'ts_browse
        '
        Me.ts_browse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_browse.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_BrowsePenerbit})
        Me.ts_browse.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.ts_browse.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_browse.Name = "ts_browse"
        Me.ts_browse.Size = New System.Drawing.Size(29, 22)
        Me.ts_browse.Text = "Browse"
        '
        'mnu_BrowsePenerbit
        '
        Me.mnu_BrowsePenerbit.Name = "mnu_BrowsePenerbit"
        Me.mnu_BrowsePenerbit.Size = New System.Drawing.Size(159, 22)
        Me.mnu_BrowsePenerbit.Text = "Browse Penerbit"
        '
        'lbl_Browse
        '
        Me.lbl_Browse.Name = "lbl_Browse"
        Me.lbl_Browse.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Browse.Text = "Browse"
        '
        'separator3
        '
        Me.separator3.Name = "separator3"
        Me.separator3.Size = New System.Drawing.Size(6, 25)
        '
        'ts_print
        '
        Me.ts_print.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_print.Image = Global.PenjualanBuku.My.Resources.Resources._12
        Me.ts_print.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_print.Name = "ts_print"
        Me.ts_print.Size = New System.Drawing.Size(23, 22)
        Me.ts_print.Text = "Cetak"
        '
        'lbl_Cetak
        '
        Me.lbl_Cetak.Name = "lbl_Cetak"
        Me.lbl_Cetak.Size = New System.Drawing.Size(37, 22)
        Me.lbl_Cetak.Text = "Cetak"
        '
        'frmPenerbit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 290)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmPenerbit"
        Me.Text = "Master Penerbit"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblAlamatPenerbit As System.Windows.Forms.Label
    Friend WithEvents btn_BrowseKodePenerbit As System.Windows.Forms.Button
    Friend WithEvents txtKotaPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtAlamatPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtKodePenerbit As System.Windows.Forms.TextBox
    Friend WithEvents lblWebsitePenerbit As System.Windows.Forms.Label
    Friend WithEvents lblEmailPenerbit As System.Windows.Forms.Label
    Friend WithEvents lblNamaPenerbit As System.Windows.Forms.Label
    Friend WithEvents lblKodePenerbit As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents txtWebsitePenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtEmailPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtTelpPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents txtKodePosPenerbit As System.Windows.Forms.TextBox
    Friend WithEvents lblTelpPenerbit As System.Windows.Forms.Label
    Friend WithEvents lblKodePosPenerbit As System.Windows.Forms.Label
    Friend WithEvents lblKotaPenerbit As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents lbl_Navigator As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_first As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_prev As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_next As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_last As System.Windows.Forms.ToolStripButton
    Friend WithEvents separator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_addnew As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_AddNew As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_save As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Save As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_update As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Update As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_delete As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Delete As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_browse As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnu_BrowsePenerbit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbl_Browse As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_print As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Cetak As System.Windows.Forms.ToolStripLabel
End Class
