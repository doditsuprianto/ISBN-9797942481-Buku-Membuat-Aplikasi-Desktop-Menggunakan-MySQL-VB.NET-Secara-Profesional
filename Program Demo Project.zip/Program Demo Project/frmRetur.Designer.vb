<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRetur
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnl_navigation = New System.Windows.Forms.Panel
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.lbl_Navigator = New System.Windows.Forms.ToolStripLabel
        Me.ts_first = New System.Windows.Forms.ToolStripButton
        Me.ts_prev = New System.Windows.Forms.ToolStripButton
        Me.ts_next = New System.Windows.Forms.ToolStripButton
        Me.ts_last = New System.Windows.Forms.ToolStripButton
        Me.separator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_addnew = New System.Windows.Forms.ToolStripButton
        Me.lbl_AddNew = New System.Windows.Forms.ToolStripLabel
        Me.ts_save = New System.Windows.Forms.ToolStripButton
        Me.lbl_Save = New System.Windows.Forms.ToolStripLabel
        Me.ts_update = New System.Windows.Forms.ToolStripButton
        Me.lbl_Update = New System.Windows.Forms.ToolStripLabel
        Me.ts_delete = New System.Windows.Forms.ToolStripButton
        Me.lbl_Delete = New System.Windows.Forms.ToolStripLabel
        Me.separator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_browse = New System.Windows.Forms.ToolStripDropDownButton
        Me.mnu_BrowsePenjualan = New System.Windows.Forms.ToolStripMenuItem
        Me.mnu_BrowseBuku = New System.Windows.Forms.ToolStripMenuItem
        Me.lbl_Browse = New System.Windows.Forms.ToolStripLabel
        Me.separator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ts_print = New System.Windows.Forms.ToolStripButton
        Me.lbl_Cetak = New System.Windows.Forms.ToolStripLabel
        Me.pnl_header = New System.Windows.Forms.SplitContainer
        Me.txt_NamaSupplier = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.txt_KdSupplier = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btn_BrowseKodeBuku = New System.Windows.Forms.Button
        Me.dt_tglretur = New System.Windows.Forms.DateTimePicker
        Me.txt_nonota = New System.Windows.Forms.TextBox
        Me.lbl_tgljual = New System.Windows.Forms.Label
        Me.lbl_nota = New System.Windows.Forms.Label
        Me.lbl_total = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.pnl_content = New System.Windows.Forms.Panel
        Me.dgv_retur = New System.Windows.Forms.DataGridView
        Me.pnl_navigation.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.pnl_header.Panel1.SuspendLayout()
        Me.pnl_header.Panel2.SuspendLayout()
        Me.pnl_header.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.pnl_content.SuspendLayout()
        CType(Me.dgv_retur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnl_navigation
        '
        Me.pnl_navigation.Controls.Add(Me.ToolStrip1)
        Me.pnl_navigation.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_navigation.Location = New System.Drawing.Point(0, 0)
        Me.pnl_navigation.Name = "pnl_navigation"
        Me.pnl_navigation.Size = New System.Drawing.Size(682, 33)
        Me.pnl_navigation.TabIndex = 34
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_Navigator, Me.ts_first, Me.ts_prev, Me.ts_next, Me.ts_last, Me.separator1, Me.ts_addnew, Me.lbl_AddNew, Me.ts_save, Me.lbl_Save, Me.ts_update, Me.lbl_Update, Me.ts_delete, Me.lbl_Delete, Me.separator2, Me.ts_browse, Me.lbl_Browse, Me.separator3, Me.ts_print, Me.lbl_Cetak})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(682, 25)
        Me.ToolStrip1.TabIndex = 28
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'lbl_Navigator
        '
        Me.lbl_Navigator.Name = "lbl_Navigator"
        Me.lbl_Navigator.Size = New System.Drawing.Size(62, 22)
        Me.lbl_Navigator.Text = "Navigator:"
        '
        'ts_first
        '
        Me.ts_first.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_first.Image = Global.PenjualanBuku.My.Resources.Resources._38
        Me.ts_first.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_first.Name = "ts_first"
        Me.ts_first.Size = New System.Drawing.Size(23, 22)
        Me.ts_first.Text = "Record Awal"
        '
        'ts_prev
        '
        Me.ts_prev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_prev.Image = Global.PenjualanBuku.My.Resources.Resources._36
        Me.ts_prev.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_prev.Name = "ts_prev"
        Me.ts_prev.Size = New System.Drawing.Size(23, 22)
        Me.ts_prev.Text = "Record Sebelum"
        '
        'ts_next
        '
        Me.ts_next.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_next.Image = Global.PenjualanBuku.My.Resources.Resources._35
        Me.ts_next.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_next.Name = "ts_next"
        Me.ts_next.Size = New System.Drawing.Size(23, 22)
        Me.ts_next.Text = "Record Setelah"
        '
        'ts_last
        '
        Me.ts_last.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_last.Image = Global.PenjualanBuku.My.Resources.Resources._37
        Me.ts_last.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_last.Name = "ts_last"
        Me.ts_last.Size = New System.Drawing.Size(23, 22)
        Me.ts_last.Text = "Record Akhir "
        '
        'separator1
        '
        Me.separator1.Name = "separator1"
        Me.separator1.Size = New System.Drawing.Size(6, 25)
        '
        'ts_addnew
        '
        Me.ts_addnew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_addnew.Image = Global.PenjualanBuku.My.Resources.Resources._03
        Me.ts_addnew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_addnew.Name = "ts_addnew"
        Me.ts_addnew.Size = New System.Drawing.Size(23, 22)
        Me.ts_addnew.Text = "Tambah Data"
        '
        'lbl_AddNew
        '
        Me.lbl_AddNew.Name = "lbl_AddNew"
        Me.lbl_AddNew.Size = New System.Drawing.Size(56, 22)
        Me.lbl_AddNew.Text = "Add New"
        '
        'ts_save
        '
        Me.ts_save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_save.Image = Global.PenjualanBuku.My.Resources.Resources._461
        Me.ts_save.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_save.Name = "ts_save"
        Me.ts_save.Size = New System.Drawing.Size(23, 22)
        Me.ts_save.Text = "Simpan Data"
        '
        'lbl_Save
        '
        Me.lbl_Save.Name = "lbl_Save"
        Me.lbl_Save.Size = New System.Drawing.Size(31, 22)
        Me.lbl_Save.Text = "Save"
        '
        'ts_update
        '
        Me.ts_update.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_update.Image = Global.PenjualanBuku.My.Resources.Resources._21
        Me.ts_update.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_update.Name = "ts_update"
        Me.ts_update.Size = New System.Drawing.Size(23, 22)
        Me.ts_update.Text = "Ubah Data"
        '
        'lbl_Update
        '
        Me.lbl_Update.Name = "lbl_Update"
        Me.lbl_Update.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Update.Text = "Update"
        '
        'ts_delete
        '
        Me.ts_delete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_delete.Image = Global.PenjualanBuku.My.Resources.Resources._01
        Me.ts_delete.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_delete.Name = "ts_delete"
        Me.ts_delete.Size = New System.Drawing.Size(23, 22)
        Me.ts_delete.Text = "Hapus Data"
        '
        'lbl_Delete
        '
        Me.lbl_Delete.Name = "lbl_Delete"
        Me.lbl_Delete.Size = New System.Drawing.Size(40, 22)
        Me.lbl_Delete.Text = "Delete"
        '
        'separator2
        '
        Me.separator2.Name = "separator2"
        Me.separator2.Size = New System.Drawing.Size(6, 25)
        '
        'ts_browse
        '
        Me.ts_browse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_browse.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_BrowsePenjualan, Me.mnu_BrowseBuku})
        Me.ts_browse.Image = Global.PenjualanBuku.My.Resources.Resources._49
        Me.ts_browse.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_browse.Name = "ts_browse"
        Me.ts_browse.Size = New System.Drawing.Size(29, 22)
        Me.ts_browse.Text = "Browse"
        '
        'mnu_BrowsePenjualan
        '
        Me.mnu_BrowsePenjualan.Name = "mnu_BrowsePenjualan"
        Me.mnu_BrowsePenjualan.Size = New System.Drawing.Size(167, 22)
        Me.mnu_BrowsePenjualan.Text = "Browse Penjualan"
        '
        'mnu_BrowseBuku
        '
        Me.mnu_BrowseBuku.Name = "mnu_BrowseBuku"
        Me.mnu_BrowseBuku.Size = New System.Drawing.Size(167, 22)
        Me.mnu_BrowseBuku.Text = "Browse Buku"
        '
        'lbl_Browse
        '
        Me.lbl_Browse.Name = "lbl_Browse"
        Me.lbl_Browse.Size = New System.Drawing.Size(45, 22)
        Me.lbl_Browse.Text = "Browse"
        '
        'separator3
        '
        Me.separator3.Name = "separator3"
        Me.separator3.Size = New System.Drawing.Size(6, 25)
        '
        'ts_print
        '
        Me.ts_print.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ts_print.Image = Global.PenjualanBuku.My.Resources.Resources._12
        Me.ts_print.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ts_print.Name = "ts_print"
        Me.ts_print.Size = New System.Drawing.Size(23, 22)
        Me.ts_print.Text = "Cetak"
        '
        'lbl_Cetak
        '
        Me.lbl_Cetak.Name = "lbl_Cetak"
        Me.lbl_Cetak.Size = New System.Drawing.Size(37, 22)
        Me.lbl_Cetak.Text = "Cetak"
        '
        'pnl_header
        '
        Me.pnl_header.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_header.Location = New System.Drawing.Point(0, 33)
        Me.pnl_header.Name = "pnl_header"
        '
        'pnl_header.Panel1
        '
        Me.pnl_header.Panel1.Controls.Add(Me.txt_NamaSupplier)
        Me.pnl_header.Panel1.Controls.Add(Me.Button1)
        Me.pnl_header.Panel1.Controls.Add(Me.txt_KdSupplier)
        Me.pnl_header.Panel1.Controls.Add(Me.Label1)
        Me.pnl_header.Panel1.Controls.Add(Me.btn_BrowseKodeBuku)
        Me.pnl_header.Panel1.Controls.Add(Me.dt_tglretur)
        Me.pnl_header.Panel1.Controls.Add(Me.txt_nonota)
        Me.pnl_header.Panel1.Controls.Add(Me.lbl_tgljual)
        Me.pnl_header.Panel1.Controls.Add(Me.lbl_nota)
        '
        'pnl_header.Panel2
        '
        Me.pnl_header.Panel2.Controls.Add(Me.lbl_total)
        Me.pnl_header.Size = New System.Drawing.Size(682, 71)
        Me.pnl_header.SplitterDistance = 410
        Me.pnl_header.TabIndex = 36
        '
        'txt_NamaSupplier
        '
        Me.txt_NamaSupplier.Enabled = False
        Me.txt_NamaSupplier.Location = New System.Drawing.Point(211, 40)
        Me.txt_NamaSupplier.Name = "txt_NamaSupplier"
        Me.txt_NamaSupplier.Size = New System.Drawing.Size(190, 20)
        Me.txt_NamaSupplier.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.Button1.Location = New System.Drawing.Point(177, 38)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(25, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt_KdSupplier
        '
        Me.txt_KdSupplier.Location = New System.Drawing.Point(64, 40)
        Me.txt_KdSupplier.Name = "txt_KdSupplier"
        Me.txt_KdSupplier.Size = New System.Drawing.Size(112, 20)
        Me.txt_KdSupplier.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Supplier:"
        '
        'btn_BrowseKodeBuku
        '
        Me.btn_BrowseKodeBuku.Image = Global.PenjualanBuku.My.Resources.Resources._491
        Me.btn_BrowseKodeBuku.Location = New System.Drawing.Point(177, 11)
        Me.btn_BrowseKodeBuku.Name = "btn_BrowseKodeBuku"
        Me.btn_BrowseKodeBuku.Size = New System.Drawing.Size(25, 23)
        Me.btn_BrowseKodeBuku.TabIndex = 1
        Me.btn_BrowseKodeBuku.UseVisualStyleBackColor = True
        '
        'dt_tglretur
        '
        Me.dt_tglretur.Location = New System.Drawing.Point(255, 13)
        Me.dt_tglretur.Name = "dt_tglretur"
        Me.dt_tglretur.Size = New System.Drawing.Size(146, 20)
        Me.dt_tglretur.TabIndex = 2
        '
        'txt_nonota
        '
        Me.txt_nonota.Location = New System.Drawing.Point(64, 13)
        Me.txt_nonota.Name = "txt_nonota"
        Me.txt_nonota.Size = New System.Drawing.Size(112, 20)
        Me.txt_nonota.TabIndex = 0
        '
        'lbl_tgljual
        '
        Me.lbl_tgljual.AutoSize = True
        Me.lbl_tgljual.Location = New System.Drawing.Point(205, 16)
        Me.lbl_tgljual.Name = "lbl_tgljual"
        Me.lbl_tgljual.Size = New System.Drawing.Size(49, 13)
        Me.lbl_tgljual.TabIndex = 1
        Me.lbl_tgljual.Text = "Tanggal:"
        '
        'lbl_nota
        '
        Me.lbl_nota.AutoSize = True
        Me.lbl_nota.Location = New System.Drawing.Point(13, 16)
        Me.lbl_nota.Name = "lbl_nota"
        Me.lbl_nota.Size = New System.Drawing.Size(53, 13)
        Me.lbl_nota.TabIndex = 0
        Me.lbl_nota.Text = "No. Nota:"
        '
        'lbl_total
        '
        Me.lbl_total.AutoSize = True
        Me.lbl_total.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_total.Location = New System.Drawing.Point(3, 18)
        Me.lbl_total.Name = "lbl_total"
        Me.lbl_total.Size = New System.Drawing.Size(134, 37)
        Me.lbl_total.TabIndex = 1
        Me.lbl_total.Text = "TOTAL:"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 402)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(682, 22)
        Me.StatusStrip1.TabIndex = 37
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'pnl_content
        '
        Me.pnl_content.Controls.Add(Me.dgv_retur)
        Me.pnl_content.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnl_content.Location = New System.Drawing.Point(0, 104)
        Me.pnl_content.Name = "pnl_content"
        Me.pnl_content.Size = New System.Drawing.Size(682, 298)
        Me.pnl_content.TabIndex = 38
        '
        'dgv_retur
        '
        Me.dgv_retur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_retur.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgv_retur.Location = New System.Drawing.Point(0, 0)
        Me.dgv_retur.Name = "dgv_retur"
        Me.dgv_retur.Size = New System.Drawing.Size(682, 298)
        Me.dgv_retur.TabIndex = 0
        '
        'frmRetur
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 424)
        Me.Controls.Add(Me.pnl_content)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.pnl_header)
        Me.Controls.Add(Me.pnl_navigation)
        Me.Name = "frmRetur"
        Me.Text = "Transaksi Retur"
        Me.pnl_navigation.ResumeLayout(False)
        Me.pnl_navigation.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.pnl_header.Panel1.ResumeLayout(False)
        Me.pnl_header.Panel1.PerformLayout()
        Me.pnl_header.Panel2.ResumeLayout(False)
        Me.pnl_header.Panel2.PerformLayout()
        Me.pnl_header.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.pnl_content.ResumeLayout(False)
        CType(Me.dgv_retur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnl_navigation As System.Windows.Forms.Panel
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents lbl_Navigator As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_first As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_prev As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_next As System.Windows.Forms.ToolStripButton
    Friend WithEvents ts_last As System.Windows.Forms.ToolStripButton
    Friend WithEvents separator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_addnew As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_AddNew As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_save As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Save As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_update As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Update As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ts_delete As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Delete As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_browse As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents mnu_BrowsePenjualan As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_BrowseBuku As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbl_Browse As System.Windows.Forms.ToolStripLabel
    Friend WithEvents separator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ts_print As System.Windows.Forms.ToolStripButton
    Friend WithEvents lbl_Cetak As System.Windows.Forms.ToolStripLabel
    Friend WithEvents pnl_header As System.Windows.Forms.SplitContainer
    Friend WithEvents txt_NamaSupplier As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txt_KdSupplier As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btn_BrowseKodeBuku As System.Windows.Forms.Button
    Friend WithEvents dt_tglretur As System.Windows.Forms.DateTimePicker
    Friend WithEvents txt_nonota As System.Windows.Forms.TextBox
    Friend WithEvents lbl_tgljual As System.Windows.Forms.Label
    Friend WithEvents lbl_nota As System.Windows.Forms.Label
    Friend WithEvents lbl_total As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents pnl_content As System.Windows.Forms.Panel
    Friend WithEvents dgv_retur As System.Windows.Forms.DataGridView
End Class
