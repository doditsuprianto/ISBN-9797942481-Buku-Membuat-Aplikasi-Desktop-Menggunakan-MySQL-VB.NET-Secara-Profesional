'|------------------------------------------------------------------------------------------|
'|Project  : Program Database Penjualan Buku dengan VB 2005 dan Database MySQL              |
'|           sebagai software bonus pelengkap buku.                                         |
'|Dibuat   : Juni - Juli 2009                                                               |
'|Author   : Dodit Suprianto                                                                | 
'|Email    : d0dit@yahoo.com, meozit@yahoo.com                                              |
'|Website  : http://doditsuprianto.com, http://meozit.com, http://video-training.net84.net  |
'|Facebook : http://facebook.com/dodit.suprianto                                            |
'|------------------------------------------------------------------------------------------|

Imports System.Globalization

Public Class rptPembelian

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_TAMPIL_PEMBELIAN_VW "
        SQL &= "WHERE nota_beli BETWEEN '" & txt_NoNota1.Text & "' AND '" & txt_NoNota2.Text & "'"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_TAMPIL_PEMBELIAN_VW")

            Dim myreport As New rptPembelianPerNota
            myreport.SetDataSource(MyDataset)
            Me.rpt_Viewer.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim tgl1, tgl2 As String
        'memformat tanggal menjadi tahun/bulan/tanggal, sesuai format tanggal database
        tgl1 = dt_TglJual1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
        tgl2 = dt_TglJual2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_TAMPIL_PEMBELIAN_VW "
        SQL &= "WHERE tgl_beli BETWEEN '" & tgl1 & "' AND '" & tgl2 & "';"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_TAMPIL_PEMBELIAN_VW")

            Dim myreport As New rptPembelianPerTgl
            myreport.SetDataSource(MyDataset)
            Me.rpt_Viewer.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '-------------------------------------------------------------
        'menciptakan connection string dan object koneksi ke database
        '-------------------------------------------------------------
        myConnectionString = "Database='" & db & "';Data Source=localhost;User Id='" & user & "';Password='" & pwd & "'"
        CN = New MySqlConnection(myConnectionString)
        CN.Open()

        Dim tgl1, tgl2 As String
        'memformat tanggal menjadi tahun/bulan/tanggal, sesuai format tanggal database
        tgl1 = dt_Buku1.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)
        tgl2 = dt_Buku2.Value.ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo)

        MyDataset.Clear()
        SQL = "SELECT * FROM RPT_TAMPIL_PEMBELIAN_VW "
        SQL &= "WHERE tgl_beli BETWEEN '" & tgl1 & "' AND '" & tgl2 & "' "
        SQL &= "AND kode_buku BETWEEN '" & txt_KodeBuku1.Text & "' AND '" & txt_KodeBuku2.Text & "';"

        Try
            CMD = New MySqlCommand(SQL, CN)
            MyAdapter.SelectCommand = CMD
            MyAdapter.Fill(MyDataset, "RPT_TAMPIL_PEMBELIAN_VW")

            Dim myreport As New rptPembelianPerBuku
            myreport.SetDataSource(MyDataset)
            Me.rpt_Viewer.ReportSource = myreport
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Terjadi Kegagagalan!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            CN.Close()
            CN = Nothing
        End Try
    End Sub
End Class